/*
* 语言文件 en：英文
* */
export const lang_en = {
    '手机登录': 'english',
};
