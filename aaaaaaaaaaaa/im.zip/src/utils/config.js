/**
 *  项目的配置文件
 */
import { getQueryVariable } from '@/utils/common'
let isId

if (getQueryVariable('adminId')) isId = 'admin'
if (getQueryVariable('storeId')) isId = 'seller'

const identity = localStorage.identity || isId

let apiUrl,chatUrl,storeUrl

if(identity=='admin'){
	apiUrl = 'http://8.142.26.129:9004/'
	chatUrl='http://8.142.26.129:9001/'
	storeUrl = 'http://8.142.26.129:9001/'
}else{
	apiUrl = 'http://8.142.26.129:9002/'
	chatUrl='http://8.142.26.129:9004/'
	storeUrl = 'http://8.142.26.129:9002/'
}

export {apiUrl,chatUrl,storeUrl}


// export const apiUrl = `https://${identity}.55sld.com/`//接口请求地址
// export const chatUrl = 'ws://8.142.26.129:9004/'//客服地址
// export const storeUrl = `https://${identity}.55sld.com/`;//对应的商户后台地址

export const curLang = 'zh';//当前语言,zh:中文，若为其他语言，需要对应/src/assets/language下面的文件名

/** copyright *** slodon *** version-v3.5 *** date-2022-03-25 ***主版本v3.9**/
