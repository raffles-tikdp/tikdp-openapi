<template>
  <p v-html="title"></p>
  <el-form :model="settingForm" label-width="80px">
    <el-table :show-header="false" :data="tableData" border style="width: 100%">
      <el-table-column prop="date" min-width="200" align="right" :label="L['新消息声音提醒']">
      </el-table-column>
      <el-table-column align="left" min-width="700">
        <template #default="scope">
          <template v-if="scope.row.type == 'text'">
            <el-form-item label-width="0">
              <el-switch v-model="settingForm.voice" @change="switchVoice"></el-switch>
            </el-form-item>
          </template>
          <template v-if="scope.row.type == 'btn'">
            <el-button type="primary" size="small" @click="onSubmit">{{L['保存']}}</el-button>
          </template>
        </template>
      </el-table-column>
    </el-table>
  </el-form>
</template>
<script>
  import { getCurrentInstance, reactive } from 'vue'

  export default {
    name: "Question",
    components: {},
    setup() {
      const { proxy } = getCurrentInstance();
      const L = proxy.$getCurLanguage()
      const title = proxy.$sldLlineRtextAddGoodsAddMargin('#0563FF', L['常见问题'], 0, 0, 15);
      const sldHorLine = proxy.$getSldHorLine(1);
      const settingForm = reactive({ voice: false });//表单数据
      const onSubmit = () => {
      }
      const switchVoice = (e) => {
        settingForm.voice = e;
      }
      return {
        title,
        sldHorLine,
        settingForm,
        tableData: [{
          date: L['新消息声音提醒'],
          type: 'text'
        }, {
          date: '',
          type: 'btn'
        },],
        onSubmit,
        switchVoice,
        L
      };
    }
  };
</script>
<style lang="scss" scoped>
  .el-form-item {
    margin-bottom: 0;
  }
</style>