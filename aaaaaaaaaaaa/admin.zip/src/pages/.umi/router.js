import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/_renderRoutes';
import RendererWrapper0 from 'D:/Git/成都博问金服/博问金服admin/src/pages/.umi/LocaleWrapper.jsx'
import _dvaDynamic from 'dva/dynamic'

let Router = require('dva/router').routerRedux.ConnectedRouter;

let routes = [
  {
    "path": "/user",
    "component": _dvaDynamic({
  
  component: () => import('../../layouts/UserLayout'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
    "routes": [
      {
        "path": "/user",
        "redirect": "/user/login",
        "exact": true
      },
      {
        "path": "/user/login",
        "component": _dvaDynamic({
  
  component: () => import('../User/Login'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "path": "/decorate_pc/diy_page_lists_to_edit",
    "component": _dvaDynamic({
  
  component: () => import('../../layouts/UserLayout'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
    "Routes": [require('../CheckLogin').default],
    "routes": [
      {
        "path": "/decorate_pc/diy_page_lists_to_edit",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/pc/models/pc_homes.js').then(m => { return { namespace: 'pc_homes',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/pc/home/edit_diy_page'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "path": "/decorate_pc/topic_diy_page_lists_to_edit",
    "component": _dvaDynamic({
  
  component: () => import('../../layouts/UserLayout'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
    "Routes": [require('../CheckLogin').default],
    "routes": [
      {
        "path": "/decorate_pc/topic_diy_page_lists_to_edit",
        "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/pc/models/pc_homes.js').then(m => { return { namespace: 'pc_homes',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/pc/home/edit_diy_page'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "path": "/",
    "component": _dvaDynamic({
  
  component: () => import('../../layouts/BasicLayout'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
    "Routes": [require('../CheckLogin').default],
    "routes": [
      {
        "path": "/",
        "redirect": "/sysset_home/basic",
        "exact": true
      },
      {
        "path": "/sysset_home",
        "icon": "home",
        "name": "home",
        "routes": [
          {
            "path": "/sysset_home/basic",
            "name": "basic",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/home/basic'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/sysset_setting",
        "icon": "setting",
        "name": "setting",
        "routes": [
          {
            "path": "/sysset_setting/site_info",
            "name": "site_info",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/base/site_info'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sysset_setting/pic_set",
            "name": "pic_set",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/base/pic_set'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sysset_setting/payment",
            "name": "payment",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/base/payment'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sysset_setting/order",
            "name": "order",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/base/order'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sysset_setting/app_set",
            "name": "app_set",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/base/app_set'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/sysset_notice_set",
        "icon": "bell",
        "name": "notice_set",
        "routes": [
          {
            "path": "/sysset_notice_set/sms",
            "name": "sms",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/notice_set/sms'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sysset_notice_set/email",
            "name": "email",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/notice_set/email'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sysset_notice_set/msg_tpl",
            "name": "msg_tpl",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/notice_set/msg_tpl'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/sysset_acount",
        "icon": "usergroup-add",
        "name": "acount",
        "routes": [
          {
            "path": "/sysset_acount/union_login",
            "name": "union_login",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/acount/union_login'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/sysset_authority",
        "icon": "security-scan",
        "name": "authority",
        "routes": [
          {
            "path": "/sysset_authority/authority_group",
            "name": "authority_group",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/authority/group'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sysset_authority/authority_member",
            "name": "authority_member",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/authority/member'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sysset_authority/operate_log",
            "name": "operate_log",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/authority/operate_log'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/sysset_agreement",
        "icon": "reconciliation",
        "name": "agreement",
        "routes": [
          {
            "path": "/sysset_agreement/lists",
            "name": "lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/agreement/lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sysset_agreement/lists_to_edit",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/agreement/edit'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/sysset_express",
        "icon": "car",
        "name": "express",
        "routes": [
          {
            "path": "/sysset_express/express_lists",
            "name": "express_lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/express/express_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/sysset_express/express",
            "name": "express",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/agreement.js').then(m => { return { namespace: 'agreement',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/authority.js').then(m => { return { namespace: 'authority',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/sysset/models/sldsetting.js').then(m => { return { namespace: 'sldsetting',...m.default}})
],
  component: () => import('../sysset/express/express'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/member",
        "name": "member",
        "icon": "usergroup-add",
        "routes": [
          {
            "path": "/member/lists",
            "name": "lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/member/models/member.js').then(m => { return { namespace: 'member',...m.default}})
],
  component: () => import('../member/lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/member/lists_to_detail",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/member/models/member.js').then(m => { return { namespace: 'member',...m.default}})
],
  component: () => import('../member/detail'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/member/recharge",
            "name": "recharge",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/member/models/member.js').then(m => { return { namespace: 'member',...m.default}})
],
  component: () => import('../member/recharge'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/member/withdraw",
            "name": "withdraw",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/member/models/member.js').then(m => { return { namespace: 'member',...m.default}})
],
  component: () => import('../member/withdraw'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/member/balance_log",
            "name": "balance_log",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/member/models/member.js').then(m => { return { namespace: 'member',...m.default}})
],
  component: () => import('../member/balance_log'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/member/point_setting",
            "name": "point_setting",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/member/models/member.js').then(m => { return { namespace: 'member',...m.default}})
],
  component: () => import('../member/point_set'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/manage_product",
        "icon": "appstore",
        "name": "product",
        "routes": [
          {
            "path": "/manage_product/goods_setting",
            "name": "goods_setting",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/product/goods_setting'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_product/goods_list",
            "name": "goods_list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/product/goods_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_product/goods_list_to_detail",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/product/goods_detail'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_product/cate_lists",
            "name": "cate_lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/product/cate_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_product/brand",
            "name": "brand",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/product/brand'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_product/search_attr",
            "name": "search_attr",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/product/search_attr'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_product/goods_label",
            "name": "goods_label",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/product/goods_label'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/manage_goods_platform",
        "icon": "cloud-upload",
        "name": "goods_platform",
        "routes": [
          {
            "path": "/manage_goods_platform/list",
            "name": "list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/goods_platform/list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_goods_platform/list_to_edit",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/goods_platform/edit'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_goods_platform/add",
            "name": "add",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/goods_platform/add'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_goods_platform/LM",
            "name": "LM",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/goods_platform/lm'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_goods_platform/VOP",
            "name": "VOP",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/goods_platform/vop'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/decorate_pc",
        "icon": "cluster",
        "name": "decorate_pc",
        "routes": [
          {
            "path": "/decorate_pc/instance_template_lists",
            "name": "instance_template_lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/pc/models/pc_homes.js').then(m => { return { namespace: 'pc_homes',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/pc/home/instance_template_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/decorate_pc/instance_template_lists_to_add",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/pc/models/pc_homes.js').then(m => { return { namespace: 'pc_homes',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/pc/home/add_template'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/decorate_pc/diy_page_lists",
            "name": "diy_page_lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/pc/models/pc_homes.js').then(m => { return { namespace: 'pc_homes',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/pc/home/diy_page_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/decorate_pc/topic_diy_page_lists",
            "name": "topic_diy_page_lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/pc/models/pc_homes.js').then(m => { return { namespace: 'pc_homes',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/pc/topic/topic_diy_page_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/decorate_pc/home_setting",
            "name": "home_setting",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/pc/models/pc_homes.js').then(m => { return { namespace: 'pc_homes',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/pc/home/home_setting'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/decorate_pc/nav",
            "name": "nav",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/pc/models/pc_homes.js').then(m => { return { namespace: 'pc_homes',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/pc/home/nav'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/decorate_pc/footer",
            "name": "footer",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/pc/models/pc_homes.js').then(m => { return { namespace: 'pc_homes',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/pc/home/footer'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/decorate_m",
        "icon": "mobile",
        "name": "decorate_m",
        "routes": [
          {
            "path": "/decorate_m/lists",
            "name": "lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/mobile/lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/decorate_m/lists_to_diy",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/mobile/edit_diy_page'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/decorate_m/topic_lists",
            "name": "topic_lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/mobile/topic_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/decorate_m/topic_lists_to_diy",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/mobile/edit_diy_page'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/decorate_m/cat_pic",
            "name": "cat_pic",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/mdecorate.js').then(m => { return { namespace: 'mdecorate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/decorate/models/pc_home.js').then(m => { return { namespace: 'pc_home',...m.default}})
],
  component: () => import('../decorate/mobile/mcat'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/manage_store",
        "icon": "shop",
        "name": "store",
        "routes": [
          {
            "path": "/manage_store/own_list",
            "name": "own_list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/store/own_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_store/settle_store_list",
            "name": "settle_store_list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/store/settle_store_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_store/settle_store_list_apply_detail",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/store/apply_store_detail'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_store/settle_store_list_view",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/store/settled_store_detail'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_store/settle_store_list_to_edit",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/store/edit_settled_store'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_store/grade_list",
            "name": "grade_list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/store/grade_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/manage_order",
        "icon": "form",
        "name": "order",
        "routes": [
          {
            "path": "/manage_order/order_lists",
            "name": "order_lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/order/order_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_order/order_lists_to_detail",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/order/order_detail'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_order/service",
            "name": "service",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/order/service'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_order/evaluation",
            "name": "evaluation",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/order/evaluation'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_order/salereson_lists",
            "name": "salereson_lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/order/salereson_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/manage_bill",
        "icon": "pay-circle",
        "name": "bill",
        "routes": [
          {
            "path": "/manage_bill/lists",
            "name": "lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/bill/lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_bill/lists_to_detail",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/bill/detail'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/manage_article",
        "icon": "file-word",
        "name": "article",
        "routes": [
          {
            "path": "/manage_article/article_cat_lists",
            "name": "article_cat_lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/article/article_cat_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_article/article_lists",
            "name": "article_lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/article/article_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/manage_article/article_lists_to_add",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/article/add_article'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/marketing_promotion",
        "icon": "chrome",
        "name": "promotion",
        "routes": [
          {
            "path": "/marketing_promotion/center",
            "name": "center",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/center'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/coupon",
            "name": "coupon",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/coupon/home'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/coupon_to_add",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/coupon/add_coupon'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/coupon_to_view",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/coupon/view_coupon'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/coupon_to_receive_list",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/coupon/member_receive_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/store_coupon",
            "name": "store_coupon",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/coupon/store_coupon'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/store_coupon_to_view",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/coupon/view_coupon'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/store_coupon_to_receive_list",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/coupon/member_receive_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/rank",
            "name": "rank",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/rank/index'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/rank_to_bind",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/rank/bind_rank_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/rank_to_add",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/rank/add'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/point_setting",
            "name": "point_setting",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/point_setting'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/full_discount",
            "name": "full_discount",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/full/discount'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/seckill",
            "name": "seckill",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/seckill/lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/seckill_detail",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/seckill/detail'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/seckill_goods_list",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/seckill/seckill_goods_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/spell_group",
            "name": "spell_group",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/spell_group/lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/spell_group_to_view",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/spell_group/view_spell_group'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/spell_group_bind_goods",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/spell_group/joined_goods_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/spell_group_order",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/spell_group/order_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/spell_group_order_to_detail",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/article.js').then(m => { return { namespace: 'article',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/bill.js').then(m => { return { namespace: 'bill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/evaluate.js').then(m => { return { namespace: 'evaluate',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/goods_platform.js').then(m => { return { namespace: 'goods_platform',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/order.js').then(m => { return { namespace: 'order',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/product.js').then(m => { return { namespace: 'product',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/reason.js').then(m => { return { namespace: 'reason',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/manage/models/store.js').then(m => { return { namespace: 'store',...m.default}})
],
  component: () => import('../manage/order/order_detail'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/spell_group_team_list",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/spell_group/team_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/ladder_group",
            "name": "ladder_group",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/ladder_group/lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/ladder_group_to_view",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/ladder_group/view_ladder_group'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/ladder_group_team_list",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/ladder_group/team_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/presale",
            "name": "presale",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/presale/lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/presale_to_view",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/presale/view_presale'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/presale_goods_list",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/promotion/presale/presale_goods_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/sign",
            "name": "sign",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/sign/stat'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/sign_to_add",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/sign/add'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/sign_to_member_detail",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/sign/member_stat_detail'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/sign_to_activity_detail",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/sign/activity_stat_detail'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/lucky_draw_list",
            "name": "lucky_list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/draw/lucky_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/lucky_draw_list_to_add",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/draw/add'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/turnplate_list",
            "name": "turnplate_list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/draw/turnplate_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/turnplate_list_to_add",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/draw/add'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/scratch_list",
            "name": "scratch_list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/draw/scratch_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/scratch_list_to_add",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/draw/add'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/shake_list",
            "name": "shake_list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/draw/shake_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/shake_list_to_add",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/draw/add'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/turn_list",
            "name": "turn_list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/draw/turn_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_promotion/turn_list_to_add",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/draw/add'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/statistics",
        "icon": "pie-chart",
        "name": "statistics",
        "routes": [
          {
            "path": "/statistics/realtime",
            "name": "realtime",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/statistics/models/statistics.js').then(m => { return { namespace: 'statistics',...m.default}})
],
  component: () => import('../statistics/realtime'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/statistics/trade",
            "name": "trade",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/statistics/models/statistics.js').then(m => { return { namespace: 'statistics',...m.default}})
],
  component: () => import('../statistics/trade'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/statistics/flow",
            "name": "flow",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/statistics/models/statistics.js').then(m => { return { namespace: 'statistics',...m.default}})
],
  component: () => import('../statistics/flow'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/statistics/goods_saling",
            "name": "goods_saling",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/statistics/models/statistics.js').then(m => { return { namespace: 'statistics',...m.default}})
],
  component: () => import('../statistics/goods_saling'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/statistics/goods_category",
            "name": "goods_category",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/statistics/models/statistics.js').then(m => { return { namespace: 'statistics',...m.default}})
],
  component: () => import('../statistics/goods_category'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/statistics/member",
            "name": "member",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/statistics/models/statistics.js').then(m => { return { namespace: 'statistics',...m.default}})
],
  component: () => import('../statistics/member'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/statistics/store",
            "name": "store",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/statistics/models/statistics.js').then(m => { return { namespace: 'statistics',...m.default}})
],
  component: () => import('../statistics/store'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/statistics/region",
            "name": "region",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/statistics/models/statistics.js').then(m => { return { namespace: 'statistics',...m.default}})
],
  component: () => import('../statistics/region'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/marketing_svideo",
        "icon": "pay-circle",
        "name": "svideo",
        "routes": [
          {
            "path": "/marketing_svideo/setting",
            "name": "setting",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/svideo/setting'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_svideo/label",
            "name": "label",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/svideo/label'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_svideo/video_theme",
            "name": "theme",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/svideo/theme'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_svideo/video_theme_to_add",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/svideo/add_theme'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_svideo/video_theme_bind_video",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/svideo/view_theme_video'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_svideo/author_manage",
            "name": "author_manage",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/svideo/author_manage'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_svideo/video_manage",
            "name": "video_manage",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/svideo/video_manage'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_svideo/video_manage_bind_goods",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/svideo/video_goods'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_svideo/comment_lists",
            "name": "comment_lists",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/svideo/comment_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_svideo/comment_lists_to_view",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/svideo/view_video_comments'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "path": "/marketing_point",
        "icon": "transaction",
        "name": "point",
        "routes": [
          {
            "path": "/marketing_point/diy_home",
            "name": "diy_home",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/point/mdiy/home'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_point/diy_home_to_edit",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/point/mdiy/edit_diy_page'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_point/setting",
            "name": "setting",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/point/setting'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_point/label",
            "name": "label",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/point/label'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_point/goods_list",
            "name": "goods_list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/point/goods/goods_list'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_point/order_list",
            "name": "order_list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/point/order/order_lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_point/order_list_to_detail",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/point/order/order_detail'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_point/bill_list",
            "name": "bill_list",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/point/bill/lists'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "path": "/marketing_point/bill_list_to_detail",
            "name": "",
            "component": _dvaDynamic({
  app: window.g_app,
models: () => [
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/draw.js').then(m => { return { namespace: 'draw',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/information.js').then(m => { return { namespace: 'information',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/ladder_group.js').then(m => { return { namespace: 'ladder_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/point.js').then(m => { return { namespace: 'point',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/presale.js').then(m => { return { namespace: 'presale',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/promotion.js').then(m => { return { namespace: 'promotion',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/rank.js').then(m => { return { namespace: 'rank',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/seckill.js').then(m => { return { namespace: 'seckill',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/sign.js').then(m => { return { namespace: 'sign',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spell_group.js').then(m => { return { namespace: 'spell_group',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/spreader.js').then(m => { return { namespace: 'spreader',...m.default}}),
  import('D:/Git/成都博问金服/博问金服admin/src/pages/marketing/models/svideo.js').then(m => { return { namespace: 'svideo',...m.default}})
],
  component: () => import('../marketing/point/bill/detail'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
            "exact": true
          },
          {
            "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
          }
        ]
      },
      {
        "component": _dvaDynamic({
  
  component: () => import('../404'),
  LoadingComponent: require('D:/Git/成都博问金服/博问金服admin/src/components/PageLoading/index').default,
}),
        "exact": true
      },
      {
        "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
      }
    ]
  },
  {
    "component": () => React.createElement(require('D:/Git/成都博问金服/博问金服admin/node_modules/umi-build-dev/lib/plugins/404/NotFound.js').default, { pagesPath: 'src/pages', hasRoutesInConfig: true })
  }
];
window.g_routes = routes;
window.g_plugins.applyForEach('patchRoutes', { initialValue: routes });

// route change handler
function routeChangeHandler(location, action) {
  window.g_plugins.applyForEach('onRouteChange', {
    initialValue: {
      routes,
      location,
      action,
    },
  });
}
window.g_history.listen(routeChangeHandler);
routeChangeHandler(window.g_history.location);

export default function RouterWrapper() {
  return (
<RendererWrapper0>
          <Router history={window.g_history}>
      { renderRoutes(routes, {}) }
    </Router>
        </RendererWrapper0>
  );
}
