import dva from 'dva';
import createLoading from 'dva-loading';

const runtimeDva = window.g_plugins.mergeConfig('dva');
let app = dva({
  history: window.g_history,
  
  ...(runtimeDva.config || {}),
});

window.g_app = app;
app.use(createLoading());
(runtimeDva.plugins || []).forEach(plugin => {
  app.use(plugin);
});

app.model({ namespace: 'common_mdiy', ...(require('D:/Git/成都博问金服/博问金服admin/src/models/common_mdiy.js').default) });
app.model({ namespace: 'common', ...(require('D:/Git/成都博问金服/博问金服admin/src/models/common.js').default) });
app.model({ namespace: 'global', ...(require('D:/Git/成都博问金服/博问金服admin/src/models/global.js').default) });
app.model({ namespace: 'list', ...(require('D:/Git/成都博问金服/博问金服admin/src/models/list.js').default) });
app.model({ namespace: 'login', ...(require('D:/Git/成都博问金服/博问金服admin/src/models/login.js').default) });
app.model({ namespace: 'menu', ...(require('D:/Git/成都博问金服/博问金服admin/src/models/menu.js').default) });
app.model({ namespace: 'project', ...(require('D:/Git/成都博问金服/博问金服admin/src/models/project.js').default) });
app.model({ namespace: 'setting', ...(require('D:/Git/成都博问金服/博问金服admin/src/models/setting.js').default) });
app.model({ namespace: 'user', ...(require('D:/Git/成都博问金服/博问金服admin/src/models/user.js').default) });
app.model({ namespace: 'video', ...(require('D:/Git/成都博问金服/博问金服admin/src/models/video.js').default) });
