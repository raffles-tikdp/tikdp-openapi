module.exports = {
	"navTheme": "dark",
	"primaryColor": "#ff7e28",
	"layout": "sidemenu",
	"contentWidth": "Fluid",
	"fixedHeader": true,
	"autoHideHeader": false,
	"fixSiderbar": true,
	"collapse": true,
	"menu": {
		disableLocal:true
	}
};
