import menu from './pt-BR/menu';

export default {
  ...menu,
};
