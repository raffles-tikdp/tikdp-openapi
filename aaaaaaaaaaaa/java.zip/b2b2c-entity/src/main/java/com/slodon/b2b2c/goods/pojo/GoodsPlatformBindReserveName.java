package com.slodon.b2b2c.goods.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 平台库虚拟商品用户预留信息名称表
 */
@Data
public class GoodsPlatformBindReserveName implements Serializable {
    private static final long serialVersionUID = 8344064312502376343L;

    @ApiModelProperty("预留信息名称id")
    private Integer reserveNameId;

    @ApiModelProperty("预留信息名称")
    private String reserveName;

    @ApiModelProperty("类型，1-手机号，2-身份证号，3-数字，4-文本，5-邮箱")
    private Integer reserveType;

    @ApiModelProperty("是否必填：0-否；1-是")
    private Integer isRequired;

    @ApiModelProperty("平台库商品id")
    private Long platformGoodsId;
}