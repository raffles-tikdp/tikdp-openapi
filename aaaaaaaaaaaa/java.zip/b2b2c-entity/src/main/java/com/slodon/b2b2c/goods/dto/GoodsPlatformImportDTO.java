package com.slodon.b2b2c.goods.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * @program: slodon
 * @Description 前后端交互店铺导入商品库商品DTO对象
 * @Author wuxy
 * @date 2021.10.27 13:39
 */
@Data
public class GoodsPlatformImportDTO {

    @ApiModelProperty(value = "平台库商品id", required = true)
    private Long platformGoodsId;

    @ApiModelProperty(value = "平台库货品id集合,用英文逗号隔开", required = true)
    private String platformProductIds;

    @ApiModelProperty(value = "价格变动类型：1-加法；2-减法；3-乘法；4-除法")
    private Integer changeType;

    @ApiModelProperty(value = "价格变动值")
    private BigDecimal changeValue;

    @ApiModelProperty(value = "库存", required = true)
    private Integer productStock;

    @ApiModelProperty("固定运费(与运费模版id二选一,必有一项)")
    private BigDecimal freightFee;

    @ApiModelProperty("运费模板id(与固定运费二选一,必有一项)")
    private Integer freightId;

    @ApiModelProperty(value = "导入状态，true-上架到店铺，false-添加到仓库", required = true)
    private Boolean importState;
}
