package com.slodon.b2b2c.promotion.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * 抽奖活动新增DTO
 */
@Data
public class DrawDTO implements Serializable {

    private static final long serialVersionUID = 4934297464569861407L;

    @ApiModelProperty("抽奖活动id,编辑时必传")
    private Integer drawId;

    @ApiModelProperty(value = "抽奖活动名称，最多6个字", required = true)
    private String drawName;

    @ApiModelProperty(value = "活动开始时间", required = true)
    private Date startTime;

    @ApiModelProperty(value = "活动结束时间", required = true)
    private Date endTime;

    @ApiModelProperty("抽奖消耗积分数（活动类型）")
    private Integer integralUse;

    @ApiModelProperty("活动规则类型，1-每人每天可抽奖n次，2-每人总共可抽奖n次")
    private Integer ruleType;

    @ApiModelProperty("活动规则次数")
    private Integer ruleNum;

    @ApiModelProperty("背景图")
    private String backgroundImage;

    @ApiModelProperty("正常可用时按钮图片")
    private String availableButtonImage;

    @ApiModelProperty("机会用尽时按钮图片")
    private String chanceOutButtonImage;

    @ApiModelProperty("是否开启虚拟中奖，0-不开启，1-开启，开启后，中奖名单将加入虚拟中奖数据")
    private Integer openVirtual;

    @ApiModelProperty("活动描述，最多100字")
    private String drawDescription;

    @ApiModelProperty(value = "未中奖提示信息，最多6个字", required = true)
    private String losePrizeDescription;

    @ApiModelProperty(value = "未中奖图片", required = true)
    private String losePrizeImage;

    @ApiModelProperty(value = "抽奖活动类型，1-幸运抽奖，2-大转盘，3-刮刮卡，4-摇一摇，5-翻翻看", required = true)
    private Integer drawType;

    @ApiModelProperty("抽奖奖品列表")
    private List<DrawPrizeInfo> drawPrizeInfoList;

    @Data
    public static class DrawPrizeInfo implements Serializable {
        private static final long serialVersionUID = 25612772631835703L;
        @ApiModelProperty(value = "奖项名称", required = true)
        private String prizeName;

        @ApiModelProperty(value = "奖项图片", required = true)
        private String prizeImage;

        @ApiModelProperty(value = "奖品类型，1-积分，2-优惠券", required = true)
        private Integer prizeType;

        @ApiModelProperty("奖励积分数量")
        private Integer integralNum;

        @ApiModelProperty("奖励优惠券id")
        private Integer couponId;

        @ApiModelProperty(value = "奖励份数", required = true)
        private Integer prizeNum;

        @ApiModelProperty(value = "中奖率", required = true)
        private Integer rate;
    }
}