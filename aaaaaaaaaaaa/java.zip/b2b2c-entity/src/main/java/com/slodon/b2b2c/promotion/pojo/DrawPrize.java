package com.slodon.b2b2c.promotion.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 抽奖奖品表
 */
@Data
public class DrawPrize implements Serializable {
    private static final long serialVersionUID = -3974301950781111424L;

    @ApiModelProperty("奖项id")
    private Integer prizeId;

    @ApiModelProperty("抽奖活动id")
    private Integer drawId;

    @ApiModelProperty("奖项名称")
    private String prizeName;

    @ApiModelProperty("奖项图片")
    private String prizeImage;

    @ApiModelProperty("奖品类型，1-积分，2-优惠券")
    private Integer prizeType;

    @ApiModelProperty("奖励积分数量")
    private Integer integralNum;

    @ApiModelProperty("奖励优惠券id")
    private Integer couponId;

    @ApiModelProperty("优惠券名称")
    private String couponName;

    @ApiModelProperty("优惠内容")
    private String couponContent;

    @ApiModelProperty("奖励份数")
    private Integer prizeNum;

    @ApiModelProperty("中奖率")
    private Integer rate;
}