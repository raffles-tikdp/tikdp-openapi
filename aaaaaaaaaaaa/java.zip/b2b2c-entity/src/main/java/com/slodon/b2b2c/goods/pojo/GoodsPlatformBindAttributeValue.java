package com.slodon.b2b2c.goods.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 平台库商品属性表
 */
@Data
public class GoodsPlatformBindAttributeValue implements Serializable {
    private static final long serialVersionUID = 9204976690553347050L;

    @ApiModelProperty("绑定id")
    private Integer bindId;

    @ApiModelProperty("平台库商品ID")
    private Long platformGoodsId;

    @ApiModelProperty("检索属性ID")
    private Integer attributeId;

    @ApiModelProperty("属性名称")
    private String attributeName;

    @ApiModelProperty("属性值ID")
    private Integer attributeValueId;

    @ApiModelProperty("属性值")
    private String attributeValue;
}