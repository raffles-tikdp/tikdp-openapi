package com.slodon.b2b2c.business.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * 虚拟商品订单用户预留信息表
 */
@Data
public class OrderReserve implements Serializable {
    private static final long serialVersionUID = -1355920873840855024L;

    @ApiModelProperty("预留信息id")
    private Integer reserveId;

    @ApiModelProperty("预留信息名称")
    private String reserveName;

    @ApiModelProperty("预留信息值")
    private String reserveValue;

    @ApiModelProperty("订单号")
    private String orderSn;
}