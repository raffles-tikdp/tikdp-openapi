package com.slodon.b2b2c.business.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @program: slodon
 * @Description 订单货品统计DTO
 * @Author wuxy
 */
@Data
public class OrderProductDTO implements Serializable {

    private static final long serialVersionUID = 9175801224653867918L;
    @ApiModelProperty("商品id")
    private Long goodsId;

    @ApiModelProperty("销售额")
    private BigDecimal saleAmount;

    @ApiModelProperty("销量")
    private Integer saleNum;
}
