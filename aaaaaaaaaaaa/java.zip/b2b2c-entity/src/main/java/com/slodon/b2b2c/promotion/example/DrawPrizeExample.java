package com.slodon.b2b2c.promotion.example;

import com.slodon.b2b2c.core.response.PagerInfo;
import lombok.Data;

import java.io.Serializable;

/**
 * 抽奖奖品表example
 */
@Data
public class DrawPrizeExample implements Serializable {
    private static final long serialVersionUID = -4417752585757701171L;

    /**
     * 用于编辑时的重复判断
     */
    private Integer prizeIdNotEquals;

    /**
     * 用于批量操作
     */
    private String prizeIdIn;

    /**
     * 奖项id
     */
    private Integer prizeId;

    /**
     * 抽奖活动id
     */
    private Integer drawId;

    /**
     * 奖项名称
     */
    private String prizeName;

    /**
     * 奖项名称,用于模糊查询
     */
    private String prizeNameLike;

    /**
     * 奖项图片
     */
    private String prizeImage;

    /**
     * 奖品类型，1-积分，2-优惠券
     */
    private Integer prizeType;

    /**
     * 奖励积分数量
     */
    private Integer integralNum;

    /**
     * 奖励优惠券id
     */
    private Integer couponId;

    /**
     * 优惠券名称
     */
    private String couponName;

    /**
     * 优惠券名称,用于模糊查询
     */
    private String couponNameLike;

    /**
     * 优惠内容
     */
    private String couponContent;

    /**
     * 优惠内容,用于模糊查询
     */
    private String couponContentLike;

    /**
     * 奖励份数
     */
    private Integer prizeNum;

    /**
     * 中奖率
     */
    private Integer rate;

    /**
     * 排序条件，条件之间用逗号隔开，如果不传则按照prizeId倒序排列
     */
    private String orderBy;

    /**
     * 分组条件
     */
    private String groupBy;

    /**
     * 分页信息
     */
    private PagerInfo pager;
}