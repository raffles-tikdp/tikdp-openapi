package com.slodon.b2b2c.goods.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 高频搜索词表
 */
@Data
public class GoodsSearchWords implements Serializable {
    private static final long serialVersionUID = 8817360010420373844L;

    @ApiModelProperty("高频词id")
    private Long wordsId;

    @ApiModelProperty("高频词内容")
    private String wordsContent;

    @ApiModelProperty("拼音全拼")
    private String fullPy;

    @ApiModelProperty("拼音首字母")
    private String simplePy;

    @ApiModelProperty("添加来源，1-平台添加，2-用户搜索，3-商品分词")
    private Integer resource;

    @ApiModelProperty("添加时间")
    private Date createTime;

    @ApiModelProperty("可以搜索到的商品数")
    private Integer searchGoodsNum;

    @ApiModelProperty("被搜索次数")
    private Integer searchFrequency;
}