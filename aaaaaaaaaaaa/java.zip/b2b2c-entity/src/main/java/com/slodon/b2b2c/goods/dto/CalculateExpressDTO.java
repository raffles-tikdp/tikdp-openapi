package com.slodon.b2b2c.goods.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 * 计算运费dto
 */
@Data
public class CalculateExpressDTO implements Serializable {

    private static final long serialVersionUID = -7453414076415027798L;

    @ApiModelProperty("店铺id")
    private Long storeId;
    @ApiModelProperty("城市编码")
    private String cityCode;
    @ApiModelProperty("货品列表")
    private List<ProductInfo> productList = new ArrayList<>();

    /**
     * 计算运费用的商品信息
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class ProductInfo implements Serializable {

        private static final long serialVersionUID = 3200409853577690011L;
        @ApiModelProperty("商品id")
        private Long goodsId;
        @ApiModelProperty("货品id")
        private Long productId;
        @ApiModelProperty("货品单价")
        private BigDecimal productPrice;
        @ApiModelProperty("购买数量")
        private Integer number;
    }
}
