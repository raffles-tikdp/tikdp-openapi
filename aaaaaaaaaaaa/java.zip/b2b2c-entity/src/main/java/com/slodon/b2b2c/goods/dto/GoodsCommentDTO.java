package com.slodon.b2b2c.goods.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 商品评论统计DTO
 */
@Data
public class GoodsCommentDTO implements Serializable {

    private static final long serialVersionUID = 3420678536193209643L;
    @ApiModelProperty("商品id")
    private Long goodsId;

    @ApiModelProperty("总数")
    private Integer totalNum;

    @ApiModelProperty("好评数")
    private Integer highNum;

    @ApiModelProperty("好评率")
    private BigDecimal highPercent;

}