package com.slodon.b2b2c.goods.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @program: slodon
 * @Description 加载排行榜商品搜索条件DTO
 * @Author wuxy
 */
@Data
public class RankConditionDTO implements Serializable {

    private static final long serialVersionUID = 712169349577885993L;
    @ApiModelProperty(value = "榜单类型：1-畅销榜；2-好评榜；3-新品榜；4-自定义", required = true)
    private Integer rankType;

    @ApiModelProperty("商品分类id")
    private Integer goodsCategoryId;

    @ApiModelProperty("统计时间：1-近7天；2-近30天")
    private Integer statsTime;

    @ApiModelProperty("畅销榜计算规则：1-销量排行；2-销售额排行")
    private Integer bestSellerRankRule;

    @ApiModelProperty("新品榜计算规则：1-按照商品发布的时间降序排列；2-按照商品发布的时间升序排列")
    private Integer newProductRankRule;

    @ApiModelProperty("好评数")
    private Integer highCommentNum;

    @ApiModelProperty("好评率")
    private Integer highCommentRate;

    @ApiModelProperty("商品名称")
    private String goodsName;

    @ApiModelProperty("店铺名称")
    private String storeName;

    @ApiModelProperty("品牌名称")
    private String brandName;
}
