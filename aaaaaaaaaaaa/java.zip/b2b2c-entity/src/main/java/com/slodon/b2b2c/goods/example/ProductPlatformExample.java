package com.slodon.b2b2c.goods.example;

import com.slodon.b2b2c.core.response.PagerInfo;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 平台库货品表example
 */
@Data
public class ProductPlatformExample implements Serializable {
    private static final long serialVersionUID = -8735943323776710730L;

    /**
     * 用于编辑时的重复判断
     */
    private Long platformProductIdNotEquals;

    /**
     * 用于批量操作
     */
    private String platformProductIdIn;

    /**
     * 自增物理主键
     */
    private Long id;

    /**
     * 平台库货品id
     */
    private Long platformProductId;

    /**
     * 平台库商品ID
     */
    private Long platformGoodsId;

    /**
     * 货品id
     */
    private Long productId;

    /**
     * 商品id
     */
    private Long goodsId;

    /**
     * 商品名称
     */
    private String goodsName;

    /**
     * 商品名称,用于模糊查询
     */
    private String goodsNameLike;

    /**
     * 规格值，用逗号分隔
     */
    private String specValues;

    /**
     * 规格值的ID，用逗号分隔
     */
    private String specValueIds;

    /**
     * 品牌id
     */
    private Integer brandId;

    /**
     * 品牌名称
     */
    private String brandName;

    /**
     * 品牌名称,用于模糊查询
     */
    private String brandNameLike;

    /**
     * 店铺id
     */
    private Long storeId;

    /**
     * 1级分类ID
     */
    private Integer categoryId1;

    /**
     * 2级分类ID
     */
    private Integer categoryId2;

    /**
     * 3级分类ID
     */
    private Integer categoryId3;

    /**
     * 商品所属分类路径(如：分类1>分类2>分类3)
     */
    private String categoryPath;

    /**
     * 货品价格
     */
    private BigDecimal productPrice;

    /**
     * 市场价
     */
    private BigDecimal marketPrice;

    /**
     * 商品主图路径；每个SKU一张主图；如果启用图片规格，即为图片规格值对应组图中的主图。如果没有启用图片规格，即为SPU主图。
     */
    private String mainImage;

    /**
     * 货品状态: 0-已删除,1-正常,2-禁用（发布编辑商品禁用规格）
     */
    private Integer state;

    /**
     * stateIn，用于批量操作
     */
    private String stateIn;

    /**
     * stateNotIn，用于批量操作
     */
    private String stateNotIn;

    /**
     * stateNotEquals，用于批量操作
     */
    private Integer stateNotEquals;

    /**
     * 是否默认货品：0-否；1-是
     */
    private Integer isDefault;

    /**
     * 商品条形码
     */
    private String barCode;

    /**
     * 重量kg
     */
    private BigDecimal weight;

    /**
     * 长度cm
     */
    private BigDecimal length;

    /**
     * 宽度cm
     */
    private BigDecimal width;

    /**
     * 高度cm
     */
    private BigDecimal height;

    /**
     * 排序条件，条件之间用逗号隔开，如果不传则按照platformProductId倒序排列
     */
    private String orderBy;

    /**
     * 分组条件
     */
    private String groupBy;

    /**
     * 分页信息
     */
    private PagerInfo pager;
}