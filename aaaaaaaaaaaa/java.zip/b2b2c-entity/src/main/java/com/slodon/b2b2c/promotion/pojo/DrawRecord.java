package com.slodon.b2b2c.promotion.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 抽奖记录表
 */
@Data
public class DrawRecord implements Serializable {
    private static final long serialVersionUID = -7011589847799565842L;

    @ApiModelProperty("抽奖记录id")
    private Integer recordId;

    @ApiModelProperty("抽奖活动id")
    private Integer drawId;

    @ApiModelProperty("奖项id")
    private Integer prizeId;

    @ApiModelProperty("奖项名称")
    private String prizeName;

    @ApiModelProperty("会员id")
    private Integer memberId;

    @ApiModelProperty("会员名称")
    private String memberName;

    @ApiModelProperty("是否中奖，0-未中奖，1-中奖")
    private Integer isPrize;

    @ApiModelProperty("抽奖时间")
    private Date recordTime;

    @ApiModelProperty("抽奖消耗积分数")
    private Integer useIntegral;

    @ApiModelProperty("奖品类型，1-积分，2-优惠券，中奖必填")
    private Integer prizeType;

    @ApiModelProperty("奖励描述（未中奖、xx积分、xxx优惠券*n）")
    private String description;
}