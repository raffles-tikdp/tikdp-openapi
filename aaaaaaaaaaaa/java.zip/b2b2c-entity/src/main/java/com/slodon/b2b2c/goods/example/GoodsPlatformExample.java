package com.slodon.b2b2c.goods.example;

import com.slodon.b2b2c.core.response.PagerInfo;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 平台库商品表example
 */
@Data
public class GoodsPlatformExample implements Serializable {
    private static final long serialVersionUID = 8130824139178072568L;

    /**
     * 用于编辑时的重复判断
     */
    private Long platformGoodsIdNotEquals;

    /**
     * 用于批量操作
     */
    private String platformGoodsIdIn;

    /**
     * 自增物理主键
     */
    private Long id;

    /**
     * 平台库商品ID
     */
    private Long platformGoodsId;

    /**
     * 商品ID
     */
    private Long goodsId;

    /**
     * 商品名称
     */
    private String goodsName;

    /**
     * 商品名称,用于模糊查询
     */
    private String goodsNameLike;

    /**
     * 商品广告语
     */
    private String goodsBrief;

    /**
     * 市场价
     */
    private BigDecimal marketPrice;

    /**
     * 商品价格
     */
    private BigDecimal goodsPrice;

    /**
     * 品牌ID
     */
    private Integer brandId;

    /**
     * 品牌名称
     */
    private String brandName;

    /**
     * 品牌名称,用于模糊查询
     */
    private String brandNameLike;

    /**
     * 1级分类ID
     */
    private Integer categoryId1;

    /**
     * 2级分类ID
     */
    private Integer categoryId2;

    /**
     * 3级分类ID
     */
    private Integer categoryId3;

    /**
     * 用于批量操作
     */
    private String categoryId3In;

    /**
     * 商品所属分类路径(如：分类1>分类2>分类3)
     */
    private String categoryPath;

    /**
     * 是否启用规格：0-否；1-是
     */
    private Integer isSpec;

    /**
     * 商品主规格；0-无主规格，其他id为对应的主规格ID，主规格值切换商品主图会切换
     */
    private Integer mainSpecId;

    /**
     * 店铺ID(平台发布的为0)
     */
    private Long storeId;

    /**
     * 店铺ID NotEquals
     */
    private Long storeIdNotEquals;

    /**
     * 状态：1-待刊登；2-已刊登；3-已下架；4-已删除
     */
    private Integer state;

    /**
     * stateIn，用于批量操作
     */
    private String stateIn;

    /**
     * stateNotIn，用于批量操作
     */
    private String stateNotIn;

    /**
     * stateNotEquals，用于批量操作
     */
    private Integer stateNotEquals;

    /**
     * 是否是虚拟商品：1-实物商品；2-虚拟商品
     */
    private Integer isVirtualGoods;

    /**
     * 商品主图路径，每个SPU一张主图
     */
    private String mainImage;

    /**
     * 商品视频
     */
    private String goodsVideo;

    /**
     * 商品条形码（标准的商品条形码）
     */
    private String barCode;

    /**
     * 默认货品id
     */
    private Long defaultProductId;

    /**
     * 售后服务：0-不支持退款；1-支持退款(虚拟商品必填)
     */
    private Integer afterSaleService;

    /**
     * 商品属性json（商品发布使用的属性信息，系统、自定义）
     */
    private String attributeJson;

    /**
     * 下架原因
     */
    private String offlineReason;

    /**
     * 下架原因,用于模糊查询
     */
    private String offlineReasonLike;

    /**
     * 创建人id
     */
    private Integer createAdminId;

    /**
     * 大于等于开始时间
     */
    private Date createTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date createTimeBefore;

    /**
     * 大于等于开始时间
     */
    private Date updateTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date updateTimeBefore;

    /**
     * 商品详情信息
     */
    private String goodsDetails;

    /**
     * 商品参数，json格式，商品详情顶部显示
     */
    private String goodsParameter;

    /**
     * 商品规格json（商品发布使用的规格及规格值信息）
     */
    private String specJson;

    /**
     * 排序条件，条件之间用逗号隔开，如果不传则按照platformGoodsId倒序排列
     */
    private String orderBy;

    /**
     * 分组条件
     */
    private String groupBy;

    /**
     * 分页信息
     */
    private PagerInfo pager;

    /**
     * 查询店铺商品
     */
    private String queryStoreGoods;
}