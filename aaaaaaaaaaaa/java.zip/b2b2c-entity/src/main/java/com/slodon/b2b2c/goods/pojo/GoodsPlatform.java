package com.slodon.b2b2c.goods.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 平台库商品表
 */
@Data
public class GoodsPlatform implements Serializable {
    private static final long serialVersionUID = 1684835262402249672L;

    @ApiModelProperty("自增物理主键")
    private Long id;

    @ApiModelProperty("平台库商品ID")
    private Long platformGoodsId;

    @ApiModelProperty("商品ID")
    private Long goodsId;

    @ApiModelProperty("商品名称")
    private String goodsName;

    @ApiModelProperty("商品广告语")
    private String goodsBrief;

    @ApiModelProperty("市场价")
    private BigDecimal marketPrice;

    @ApiModelProperty("商品价格")
    private BigDecimal goodsPrice;

    @ApiModelProperty("品牌ID")
    private Integer brandId;

    @ApiModelProperty("品牌名称")
    private String brandName;

    @ApiModelProperty("1级分类ID")
    private Integer categoryId1;

    @ApiModelProperty("2级分类ID")
    private Integer categoryId2;

    @ApiModelProperty("3级分类ID")
    private Integer categoryId3;

    @ApiModelProperty("商品所属分类路径(如：分类1>分类2>分类3)")
    private String categoryPath;

    @ApiModelProperty("是否启用规格：0-否；1-是")
    private Integer isSpec;

    @ApiModelProperty("商品主规格；0-无主规格，其他id为对应的主规格ID，主规格值切换商品主图会切换")
    private Integer mainSpecId;

    @ApiModelProperty("店铺ID(平台发布的为0)")
    private Long storeId;

    @ApiModelProperty("状态：1-待刊登；2-已刊登；3-已下架；4-已删除")
    private Integer state;

    @ApiModelProperty("是否是虚拟商品：1-实物商品；2-虚拟商品")
    private Integer isVirtualGoods;

    @ApiModelProperty("商品主图路径，每个SPU一张主图")
    private String mainImage;

    @ApiModelProperty("商品视频")
    private String goodsVideo;

    @ApiModelProperty("商品条形码（标准的商品条形码）")
    private String barCode;

    @ApiModelProperty("默认货品id")
    private Long defaultProductId;

    @ApiModelProperty("售后服务：0-不支持退款；1-支持退款(虚拟商品必填)")
    private Integer afterSaleService;

    @ApiModelProperty("商品属性json（商品发布使用的属性信息，系统、自定义）")
    private String attributeJson;

    @ApiModelProperty("下架原因")
    private String offlineReason;

    @ApiModelProperty("创建人id")
    private Integer createAdminId;

    @ApiModelProperty("创建时间")
    private Date createTime;

    @ApiModelProperty("更新时间")
    private Date updateTime;

    @ApiModelProperty("商品详情信息")
    private String goodsDetails;

    @ApiModelProperty("商品参数，json格式，商品详情顶部显示")
    private String goodsParameter;

    @ApiModelProperty("商品规格json（商品发布使用的规格及规格值信息）")
    private String specJson;
}