package com.slodon.b2b2c.goods.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 平台库商品图片表
 */
@Data
public class GoodsPlatformPicture implements Serializable {
    private static final long serialVersionUID = -4393908408662544748L;

    @ApiModelProperty("图片id")
    private Integer pictureId;

    @ApiModelProperty("平台库商品id")
    private Long platformGoodsId;

    @ApiModelProperty("商品主spec_value_id，对于没有启用主规格的此值为0")
    private Integer specValueId;

    @ApiModelProperty("图片路径")
    private String imagePath;

    @ApiModelProperty("是否主图：1、主图；2、非主图，主图只能有一张")
    private Integer isMain;

    @ApiModelProperty("上传人id")
    private Integer createAdminId;

    @ApiModelProperty("上传时间")
    private Date createTime;
}