package com.slodon.b2b2c.promotion.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 抽奖活动表
 */
@Data
public class Draw implements Serializable {
    private static final long serialVersionUID = 3766296226256829138L;

    @ApiModelProperty("抽奖活动id")
    private Integer drawId;

    @ApiModelProperty("抽奖活动名称，最多6个字")
    private String drawName;

    @ApiModelProperty("活动开始时间")
    private Date startTime;

    @ApiModelProperty("活动结束时间")
    private Date endTime;

    @ApiModelProperty("抽奖消耗积分数（活动类型）")
    private Integer integralUse;

    @ApiModelProperty("活动规则类型，1-每人每天可抽奖n次，2-每人总共可抽奖n次")
    private Integer ruleType;

    @ApiModelProperty("活动规则次数")
    private Integer ruleNum;

    @ApiModelProperty("背景图")
    private String backgroundImage;

    @ApiModelProperty("正常可用时按钮图片")
    private String availableButtonImage;

    @ApiModelProperty("机会用尽时按钮图片")
    private String chanceOutButtonImage;

    @ApiModelProperty("是否开启虚拟中奖，0-不开启，1-开启，开启后，中奖名单将加入虚拟中奖数据")
    private Integer openVirtual;

    @ApiModelProperty("活动描述，最多100字")
    private String drawDescription;

    @ApiModelProperty("未中奖提示信息，最多6个字")
    private String losePrizeDescription;

    @ApiModelProperty("未中奖图片")
    private String losePrizeImage;

    @ApiModelProperty("创建人id")
    private Integer createAdminId;

    @ApiModelProperty("创建时间")
    private Date createTime;

    @ApiModelProperty("更新时间")
    private Date updateTime;

    @ApiModelProperty("抽奖活动类型，1-幸运抽奖，2-大转盘，3-刮刮卡，4-摇一摇，5-翻翻看")
    private Integer drawType;

    @ApiModelProperty("综合中奖率")
    private Integer totalRate;
}