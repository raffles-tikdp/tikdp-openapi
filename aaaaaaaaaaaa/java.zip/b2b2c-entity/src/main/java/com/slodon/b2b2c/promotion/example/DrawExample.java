package com.slodon.b2b2c.promotion.example;

import com.slodon.b2b2c.core.response.PagerInfo;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 抽奖活动表example
 */
@Data
public class DrawExample implements Serializable {
    private static final long serialVersionUID = -6685806389578345044L;

    /**
     * 用于编辑时的重复判断
     */
    private Integer drawIdNotEquals;

    /**
     * 用于批量操作
     */
    private String drawIdIn;

    /**
     * 抽奖活动id
     */
    private Integer drawId;

    /**
     * 抽奖活动名称，最多6个字
     */
    private String drawName;

    /**
     * 抽奖活动名称，最多6个字,用于模糊查询
     */
    private String drawNameLike;

    /**
     * 大于等于开始时间
     */
    private Date startTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date startTimeBefore;

    /**
     * 大于等于开始时间
     */
    private Date endTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date endTimeBefore;

    /**
     * 抽奖消耗积分数（活动类型）
     */
    private Integer integralUse;

    /**
     * 活动规则类型，1-每人每天可抽奖n次，2-每人总共可抽奖n次
     */
    private Integer ruleType;

    /**
     * 活动规则次数
     */
    private Integer ruleNum;

    /**
     * 背景图
     */
    private String backgroundImage;

    /**
     * 正常可用时按钮图片
     */
    private String availableButtonImage;

    /**
     * 机会用尽时按钮图片
     */
    private String chanceOutButtonImage;

    /**
     * 是否开启虚拟中奖，0-不开启，1-开启，开启后，中奖名单将加入虚拟中奖数据
     */
    private Integer openVirtual;

    /**
     * 活动描述，最多100字
     */
    private String drawDescription;

    /**
     * 未中奖提示信息，最多6个字
     */
    private String losePrizeDescription;

    /**
     * 未中奖图片
     */
    private String losePrizeImage;

    /**
     * 创建人id
     */
    private Integer createAdminId;

    /**
     * 大于等于开始时间
     */
    private Date createTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date createTimeBefore;

    /**
     * 大于等于开始时间
     */
    private Date updateTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date updateTimeBefore;

    /**
     * 抽奖活动类型，1-幸运抽奖，2-大转盘，3-刮刮卡，4-摇一摇，5-翻翻看
     */
    private Integer drawType;

    /**
     * 综合中奖率
     */
    private Integer totalRate;

    /**
     * 排序条件，条件之间用逗号隔开，如果不传则按照drawId倒序排列
     */
    private String orderBy;

    /**
     * 分组条件
     */
    private String groupBy;

    /**
     * 分页信息
     */
    private PagerInfo pager;
}