package com.slodon.b2b2c.goods.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

/**
 * 平台发布商品前端传参dto
 */
@Data
public class GoodsPlatformDTO implements Serializable {
    private static final long serialVersionUID = -7212414689575380368L;
    @ApiModelProperty(value = "平台库商品id，编辑商品时必传")
    private Long platformGoodsId;

    @ApiModelProperty(value = "是否是虚拟商品：1-实物商品；2-虚拟商品,默认1", required = true)
    private Integer isVirtualGoods = 1;

    @ApiModelProperty(value = "商品名称", required = true)
    private String goodsName;
    @ApiModelProperty(value = "商品广告语")
    private String goodsBrief;
    @ApiModelProperty(value = "品牌ID")
    private Integer brandId;
    @ApiModelProperty(value = "3级分类ID", required = true)
    private Integer categoryId3;
    @ApiModelProperty(value = "检索属性和自定义参数信息")
    private GoodsPublishFrontParamDTO.AttributeAndParameter attributeAndParameter;

    @ApiModelProperty("售后服务：0-不支持退款；1-支持退款(虚拟商品必填)")
    private Integer afterSaleService;
    @ApiModelProperty("用户预留信息列表")
    private List<GoodsPublishFrontParamDTO.GoodsReserveNameInfo> reserveInfoList;

    @ApiModelProperty("规格列表，多规格必传")
    private List<GoodsPublishFrontParamDTO.SpecInfo> specInfoList;
    @ApiModelProperty("货品列表，多规格必传")
    private List<ProductPlatformInfo> productList;
    @ApiModelProperty(value = "市场价，无规格填写")
    private BigDecimal marketPrice;
    @ApiModelProperty(value = "价格，无规格填写")
    private BigDecimal productPrice;
    @ApiModelProperty(value = "重量kg，无规格填写")
    private BigDecimal weight;
    @ApiModelProperty(value = "长度cm，无规格填写")
    private BigDecimal length;
    @ApiModelProperty(value = "宽度cm，无规格填写")
    private BigDecimal width;
    @ApiModelProperty(value = "高度cm，无规格填写")
    private BigDecimal height;
    @ApiModelProperty(value = "条形码，无规格填写")
    private String barCode;

    @ApiModelProperty(value = "商品图片列表，无规格或未设置主规格时必传")
    private List<GoodsPublishFrontParamDTO.ImageInfo> imageList;
    @ApiModelProperty(value = "商品视频")
    private String goodsVideo;
    @ApiModelProperty(value = "商品详情信息")
    private String goodsDetails;

    @ApiModelProperty("状态：1-待刊登；2-直接刊登,默认1")
    private Integer state = 1;

    //region 内部类

    /**
     * 多规格货品信息
     */
    @Data
    public static class ProductPlatformInfo implements Serializable {
        private static final long serialVersionUID = -8351959039016146293L;
        @ApiModelProperty(value = "货品规格信息列表")
        private List<ProductSpecInfo> specInfoList;
        @ApiModelProperty(value = "市场价")
        private BigDecimal marketPrice;
        @ApiModelProperty(value = "价格")
        private BigDecimal productPrice;
        @ApiModelProperty(value = "重量kg")
        private BigDecimal weight;
        @ApiModelProperty(value = "长度cm")
        private BigDecimal length;
        @ApiModelProperty(value = "宽度cm")
        private BigDecimal width;
        @ApiModelProperty(value = "高度cm")
        private BigDecimal height;
        @ApiModelProperty(value = "条形码")
        private String barCode;
        @ApiModelProperty(value = "是否启用，1-启用；2-不启用")
        private Integer state;
        @ApiModelProperty(value = "是否默认货品：0-否；1-是，只有一个默认，如果未设置默认，则默认第一个货品")
        private Integer isDefault = 0;

        /**
         * 货品规格信息
         */
        @Data
        public static class ProductSpecInfo implements Serializable {
            private static final long serialVersionUID = -6658092320786112647L;
            @ApiModelProperty(value = "规格id")
            private Integer specId;
            @ApiModelProperty(value = "规格名称")
            private String specName;
            @ApiModelProperty(value = "规格值Id")
            private Integer specValueId;
            @ApiModelProperty(value = "规格值名称")
            private String specValue;
        }
    }

    //endregion
}
