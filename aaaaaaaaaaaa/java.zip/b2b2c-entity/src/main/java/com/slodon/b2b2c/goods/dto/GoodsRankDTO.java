package com.slodon.b2b2c.goods.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @program: slodon
 * @Description 新建排行榜前后端交互DTO对象
 * @Author wuxy
 */
@Data
public class GoodsRankDTO {

    @ApiModelProperty("榜单id,编辑时必传")
    private Integer rankId;

    @ApiModelProperty(value = "榜单名称", required = true)
    private String rankName;

    @ApiModelProperty(value = "榜单分类id", required = true)
    private Integer categoryId;

    @ApiModelProperty(value = "排序", required = true)
    private Integer sort;

    @ApiModelProperty("背景图")
    private String backgroundImage;

    @ApiModelProperty(value = "榜单类型：1-畅销榜；2-好评榜；3-新品榜；4-自定义", required = true)
    private Integer rankType;

    @ApiModelProperty("商品分类id")
    private Integer goodsCategoryId;

    @ApiModelProperty("统计时间：1-近7天；2-近30天")
    private Integer statsTime;

    @ApiModelProperty("畅销榜计算规则：1-销量排行；2-销售额排行")
    private Integer bestSellerRankRule;

    @ApiModelProperty("新品榜计算规则：1-按照商品发布的时间降序排列；2-按照商品发布的时间升序排列")
    private Integer newProductRankRule;

    @ApiModelProperty("好评数(好评榜必填)")
    private Integer highCommentNum;

    @ApiModelProperty("好评率(好评榜必填)")
    private Integer highCommentRate;

    @ApiModelProperty("是否自动更新：1-自动；0-手动")
    private Integer isAutoUpdate;

    @ApiModelProperty("商品列表")
    private List<RankGoodsInfo> goodsList;

    /**
     * 商品信息
     */
    @Data
    public static class RankGoodsInfo {

        @ApiModelProperty("商品id")
        private Long goodsId;

        @ApiModelProperty(value = "商品排名")
        private Integer goodsRank;

        @ApiModelProperty(value = "上榜理由")
        private String rankReason;
    }
}
