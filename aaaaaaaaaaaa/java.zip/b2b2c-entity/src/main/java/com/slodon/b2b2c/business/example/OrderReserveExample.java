package com.slodon.b2b2c.business.example;

import com.slodon.b2b2c.core.response.PagerInfo;
import lombok.Data;

import java.io.Serializable;

/**
 * 虚拟商品订单用户预留信息表example
 */
@Data
public class OrderReserveExample implements Serializable {
    private static final long serialVersionUID = 5340599860110787344L;

    /**
     * 用于编辑时的重复判断
     */
    private Integer reserveIdNotEquals;

    /**
     * 用于批量操作
     */
    private String reserveIdIn;

    /**
     * 预留信息id
     */
    private Integer reserveId;

    /**
     * 预留信息名称
     */
    private String reserveName;

    /**
     * 预留信息名称,用于模糊查询
     */
    private String reserveNameLike;

    /**
     * 预留信息值
     */
    private String reserveValue;

    /**
     * 订单号
     */
    private String orderSn;

    /**
     * 订单号,用于模糊查询
     */
    private String orderSnLike;

    /**
     * 排序条件，条件之间用逗号隔开，如果不传则按照reserveId倒序排列
     */
    private String orderBy;

    /**
     * 分组条件
     */
    private String groupBy;

    /**
     * 分页信息
     */
    private PagerInfo pager;
}