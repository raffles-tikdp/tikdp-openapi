package com.slodon.b2b2c.goods.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 榜单与商品绑定关系表
 */
@Data
public class GoodsBindRank implements Serializable {
    private static final long serialVersionUID = 7200642093611924995L;

    @ApiModelProperty("绑定id")
    private Integer bindId;

    @ApiModelProperty("榜单id")
    private Integer rankId;

    @ApiModelProperty("商品id")
    private Long goodsId;

    @ApiModelProperty("商品排名")
    private Integer goodsRank;

    @ApiModelProperty("销量")
    private Integer saleNum;

    @ApiModelProperty("销售额")
    private BigDecimal saleAmount;

    @ApiModelProperty("好评数")
    private Integer highNum;

    @ApiModelProperty("好评率")
    private String highRate;

    @ApiModelProperty("上榜理由")
    private String rankReason;

    @ApiModelProperty("创建时间")
    private Date createTime;
}