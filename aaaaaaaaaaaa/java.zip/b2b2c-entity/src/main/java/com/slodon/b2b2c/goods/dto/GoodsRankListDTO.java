package com.slodon.b2b2c.goods.dto;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.Date;

/**
 * @program: slodon
 * @Description 榜单商品排名列表DTO
 * @Author wuxy
 */
@Data
public class GoodsRankListDTO {

    @ApiModelProperty("榜单id")
    private Integer rankId;

    @ApiModelProperty("榜单名称")
    private String rankName;

    @ApiModelProperty("榜单类型")
    private Integer rankType;

    @ApiModelProperty("商品排行")
    private Integer goodsRank;

    @ApiModelProperty("排序")
    private Integer sort;

    @ApiModelProperty("创建时间")
    private Date createTime;
}
