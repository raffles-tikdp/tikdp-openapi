package com.slodon.b2b2c.goods.example;

import com.slodon.b2b2c.core.response.PagerInfo;
import lombok.Data;

import java.io.Serializable;

/**
 * 平台库虚拟商品用户预留信息名称表example
 */
@Data
public class GoodsPlatformBindReserveNameExample implements Serializable {
    private static final long serialVersionUID = 6763483149075886400L;

    /**
     * 用于编辑时的重复判断
     */
    private Integer reserveNameIdNotEquals;

    /**
     * 用于批量操作
     */
    private String reserveNameIdIn;

    /**
     * 预留信息名称id
     */
    private Integer reserveNameId;

    /**
     * 预留信息名称id,用于模糊查询
     */
    private String reserveNameIdLike;

    /**
     * 预留信息名称
     */
    private String reserveName;

    /**
     * 预留信息名称,用于模糊查询
     */
    private String reserveNameLike;

    /**
     * 类型，1-手机号，2-身份证号，3-数字，4-文本，5-邮箱
     */
    private Integer reserveType;

    /**
     * 是否必填：0-否；1-是
     */
    private Integer isRequired;

    /**
     * 平台库商品id
     */
    private Long platformGoodsId;

    /**
     * 排序条件，条件之间用逗号隔开，如果不传则按照reserveNameId倒序排列
     */
    private String orderBy;

    /**
     * 分组条件
     */
    private String groupBy;

    /**
     * 分页信息
     */
    private PagerInfo pager;
}