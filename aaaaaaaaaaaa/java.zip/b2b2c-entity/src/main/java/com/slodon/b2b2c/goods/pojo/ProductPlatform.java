package com.slodon.b2b2c.goods.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 平台库货品表
 */
@Data
public class ProductPlatform implements Serializable {
    private static final long serialVersionUID = -8553085573216753713L;

    @ApiModelProperty("自增物理主键")
    private Long id;

    @ApiModelProperty("平台库货品id")
    private Long platformProductId;

    @ApiModelProperty("平台库商品ID")
    private Long platformGoodsId;

    @ApiModelProperty("货品id")
    private Long productId;

    @ApiModelProperty("商品id")
    private Long goodsId;

    @ApiModelProperty("商品名称")
    private String goodsName;

    @ApiModelProperty("规格值，用逗号分隔")
    private String specValues;

    @ApiModelProperty("规格值的ID，用逗号分隔")
    private String specValueIds;

    @ApiModelProperty("品牌id")
    private Integer brandId;

    @ApiModelProperty("品牌名称")
    private String brandName;

    @ApiModelProperty("店铺id")
    private Long storeId;

    @ApiModelProperty("1级分类ID")
    private Integer categoryId1;

    @ApiModelProperty("2级分类ID")
    private Integer categoryId2;

    @ApiModelProperty("3级分类ID")
    private Integer categoryId3;

    @ApiModelProperty("商品所属分类路径(如：分类1>分类2>分类3)")
    private String categoryPath;

    @ApiModelProperty("货品价格")
    private BigDecimal productPrice;

    @ApiModelProperty("市场价")
    private BigDecimal marketPrice;

    @ApiModelProperty("商品主图路径；每个SKU一张主图；如果启用图片规格，即为图片规格值对应组图中的主图。如果没有启用图片规格，即为SPU主图。")
    private String mainImage;

    @ApiModelProperty("货品状态: 0-已删除,1-正常,2-禁用（发布编辑商品禁用规格）")
    private Integer state;

    @ApiModelProperty("是否默认货品：0-否；1-是")
    private Integer isDefault;

    @ApiModelProperty("商品条形码")
    private String barCode;

    @ApiModelProperty("重量kg")
    private BigDecimal weight;

    @ApiModelProperty("长度cm")
    private BigDecimal length;

    @ApiModelProperty("宽度cm")
    private BigDecimal width;

    @ApiModelProperty("高度cm")
    private BigDecimal height;
}