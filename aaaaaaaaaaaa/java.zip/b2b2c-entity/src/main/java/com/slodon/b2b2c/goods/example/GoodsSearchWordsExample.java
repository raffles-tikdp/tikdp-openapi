package com.slodon.b2b2c.goods.example;

import com.slodon.b2b2c.core.response.PagerInfo;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 高频搜索词表example
 */
@Data
public class GoodsSearchWordsExample implements Serializable {
    private static final long serialVersionUID = 8081145201725360997L;

    /**
     * 用于编辑时的重复判断
     */
    private Long wordsIdNotEquals;

    /**
     * 用于批量操作
     */
    private String wordsIdIn;

    /**
     * 高频词id
     */
    private Long wordsId;

    /**
     * 高频词内容
     */
    private String wordsContent;

    /**
     * 高频词内容,用于模糊查询
     */
    private String wordsContentLike;

    /**
     * 高频词内容或拼音like,用于模糊查询
     */
    private String wordsContentOrPyLike;

    /**
     * 拼音全拼
     */
    private String fullPy;

    /**
     * 拼音首字母
     */
    private String simplePy;

    /**
     * 添加来源，1-平台添加，2-用户搜索，3-商品分词
     */
    private Integer resource;

    /**
     * 大于等于开始时间
     */
    private Date createTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date createTimeBefore;

    /**
     * 可以搜索到的商品数
     */
    private Integer searchGoodsNum;

    /**
     * 可以搜索到的商品数大于等于
     */
    private Integer searchGoodsNumGte;

    /**
     * 可以搜索到的商品数,用于模糊查询
     */
    private String searchGoodsNumLike;

    /**
     * 被搜索次数
     */
    private Integer searchFrequency;

    /**
     * 排序条件，条件之间用逗号隔开，如果不传则按照wordsId倒序排列
     */
    private String orderBy;

    /**
     * 分组条件
     */
    private String groupBy;

    /**
     * 分页信息
     */
    private PagerInfo pager;
}