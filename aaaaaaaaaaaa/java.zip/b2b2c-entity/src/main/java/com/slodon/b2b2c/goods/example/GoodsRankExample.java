package com.slodon.b2b2c.goods.example;

import com.slodon.b2b2c.core.response.PagerInfo;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 排行榜example
 */
@Data
public class GoodsRankExample implements Serializable {
    private static final long serialVersionUID = -2241087508884082709L;

    /**
     * 用于编辑时的重复判断
     */
    private Integer rankIdNotEquals;

    /**
     * 用于批量操作
     */
    private String rankIdIn;

    /**
     * 榜单id
     */
    private Integer rankId;

    /**
     * 榜单名称
     */
    private String rankName;

    /**
     * 榜单名称,用于模糊查询
     */
    private String rankNameLike;

    /**
     * 榜单分类id
     */
    private Integer categoryId;

    /**
     * 榜单分类名称
     */
    private String categoryName;

    /**
     * 榜单分类名称,用于模糊查询
     */
    private String categoryNameLike;

    /**
     * 排序
     */
    private Integer sort;

    /**
     * 背景图
     */
    private String backgroundImage;

    /**
     * 榜单类型：1-畅销榜；2-好评榜；3-新品榜；4-自定义
     */
    private Integer rankType;

    /**
     * 商品分类id
     */
    private Integer goodsCategoryId;

    /**
     * 商品分类名称
     */
    private String goodsCategoryName;

    /**
     * 商品分类名称,用于模糊查询
     */
    private String goodsCategoryNameLike;

    /**
     * 统计时间：1-近7天；2-近30天
     */
    private Integer statsTime;

    /**
     * 畅销榜计算规则：1-销量排行；2-销售额排行
     */
    private Integer bestSellerRankRule;

    /**
     * 新品榜计算规则：1-按照商品发布的时间降序排列；2-按照商品发布的时间升序排列
     */
    private Integer newProductRankRule;

    /**
     * 好评数(好评榜必填)
     */
    private Integer highCommentNum;

    /**
     * 好评率(好评榜必填)
     */
    private Integer highCommentRate;

    /**
     * 是否自动更新：1-自动；0-手动
     */
    private Integer isAutoUpdate;

    /**
     * 启用状态：0-未启用；1-启用
     */
    private Integer state;

    /**
     * stateIn，用于批量操作
     */
    private String stateIn;

    /**
     * stateNotIn，用于批量操作
     */
    private String stateNotIn;

    /**
     * stateNotEquals，用于批量操作
     */
    private Integer stateNotEquals;

    /**
     * 描述
     */
    private String description;

    /**
     * 大于等于开始时间
     */
    private Date createTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date createTimeBefore;

    /**
     * 创建人id
     */
    private Integer createAdminId;

    /**
     * 大于等于开始时间
     */
    private Date updateTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date updateTimeBefore;

    /**
     * 更新人id
     */
    private Integer updateAdminId;

    /**
     * 排序条件，条件之间用逗号隔开，如果不传则按照rankId倒序排列
     */
    private String orderBy;

    /**
     * 分组条件
     */
    private String groupBy;

    /**
     * 分页信息
     */
    private PagerInfo pager;
}