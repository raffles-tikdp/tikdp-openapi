package com.slodon.b2b2c.goods.pojo;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * 排行榜
 */
@Data
public class GoodsRank implements Serializable {
    private static final long serialVersionUID = -1169389220955065806L;

    @ApiModelProperty("榜单id")
    private Integer rankId;

    @ApiModelProperty("榜单名称")
    private String rankName;

    @ApiModelProperty("榜单分类id")
    private Integer categoryId;

    @ApiModelProperty("榜单分类名称")
    private String categoryName;

    @ApiModelProperty("排序")
    private Integer sort;

    @ApiModelProperty("背景图")
    private String backgroundImage;

    @ApiModelProperty("榜单类型：1-畅销榜；2-好评榜；3-新品榜；4-自定义")
    private Integer rankType;

    @ApiModelProperty("商品分类id")
    private Integer goodsCategoryId;

    @ApiModelProperty("商品分类名称")
    private String goodsCategoryName;

    @ApiModelProperty("统计时间：1-近7天；2-近30天")
    private Integer statsTime;

    @ApiModelProperty("畅销榜计算规则：1-销量排行；2-销售额排行")
    private Integer bestSellerRankRule;

    @ApiModelProperty("新品榜计算规则：1-按照商品发布的时间降序排列；2-按照商品发布的时间升序排列")
    private Integer newProductRankRule;

    @ApiModelProperty("好评数(好评榜必填)")
    private Integer highCommentNum;

    @ApiModelProperty("好评率(好评榜必填)")
    private Integer highCommentRate;

    @ApiModelProperty("是否自动更新：1-自动；0-手动")
    private Integer isAutoUpdate;

    @ApiModelProperty("启用状态：0-未启用；1-启用")
    private Integer state;

    @ApiModelProperty("描述")
    private String description;

    @ApiModelProperty("创建时间")
    private Date createTime;

    @ApiModelProperty("创建人id")
    private Integer createAdminId;

    @ApiModelProperty("更新时间")
    private Date updateTime;

    @ApiModelProperty("更新人id")
    private Integer updateAdminId;
}