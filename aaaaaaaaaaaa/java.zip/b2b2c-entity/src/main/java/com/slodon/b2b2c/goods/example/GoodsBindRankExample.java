package com.slodon.b2b2c.goods.example;

import com.slodon.b2b2c.core.response.PagerInfo;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 榜单与商品绑定关系表example
 */
@Data
public class GoodsBindRankExample implements Serializable {
    private static final long serialVersionUID = 5133080864628153453L;

    /**
     * 用于编辑时的重复判断
     */
    private Integer bindIdNotEquals;

    /**
     * 用于批量操作
     */
    private String bindIdIn;

    /**
     * 绑定id
     */
    private Integer bindId;

    /**
     * 榜单id
     */
    private Integer rankId;

    /**
     * 用于批量操作
     */
    private String rankIdIn;

    /**
     * 商品id
     */
    private Long goodsId;

    /**
     * 商品排名
     */
    private Integer goodsRank;

    /**
     * 销量
     */
    private Integer saleNum;

    /**
     * 销售额
     */
    private BigDecimal saleAmount;

    /**
     * 好评数
     */
    private Integer highNum;

    /**
     * 好评率
     */
    private String highRate;

    /**
     * 上榜理由
     */
    private String rankReason;

    /**
     * 上榜理由,用于模糊查询
     */
    private String rankReasonLike;

    /**
     * 大于等于开始时间
     */
    private Date createTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date createTimeBefore;

    /**
     * 排序条件，条件之间用逗号隔开，如果不传则按照bindId倒序排列
     */
    private String orderBy;

    /**
     * 分组条件
     */
    private String groupBy;

    /**
     * 分页信息
     */
    private PagerInfo pager;
}