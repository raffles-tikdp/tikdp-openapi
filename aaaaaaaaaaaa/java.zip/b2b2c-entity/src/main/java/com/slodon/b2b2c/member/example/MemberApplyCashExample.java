package com.slodon.b2b2c.member.example;

import com.slodon.b2b2c.core.response.PagerInfo;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 会员提现申请example
 */
@Data
public class MemberApplyCashExample implements Serializable {
    private static final long serialVersionUID = 8916895631881056177L;

    /**
     * 用于编辑时的重复判断
     */
    private Integer cashIdNotEquals;

    /**
     * 用于批量操作
     */
    private String cashIdIn;

    /**
     * 提现ID
     */
    private Integer cashId;

    /**
     * 会员ID
     */
    private Integer memberId;

    /**
     * 会员名称
     */
    private String memberName;

    /**
     * 会员名称,用于模糊查询
     */
    private String memberNameLike;

    /**
     * 提现单号
     */
    private String cashSn;

    /**
     * 提现单号,用于模糊查询
     */
    private String cashSnLike;

    /**
     * 提现金额
     */
    private BigDecimal cashAmount;

    /**
     * 大于等于开始时间
     */
    private Date applyTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date applyTimeBefore;

    /**
     * 大于等于开始时间
     */
    private Date auditTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date auditTimeBefore;

    /**
     * 大于等于开始时间
     */
    private Date finishTimeAfter;

    /**
     * 小于等于结束时间
     */
    private Date finishTimeBefore;

    /**
     * 付款账号
     */
    private String payAccount;

    /**
     * 收款银行
     */
    private String receiveBank;

    /**
     * 收款账号
     */
    private String receiveAccount;

    /**
     * 收款人姓名
     */
    private String receiveName;

    /**
     * 收款人姓名,用于模糊查询
     */
    private String receiveNameLike;

    /**
     * 收款方式：UNIONPAY-银行、WXPAY-微信、ALIPAY-支付宝
     */
    private String receiveType;

    /**
     * 状态：1、待处理；2、提现成功；3、已拒绝；4、提现失败
     */
    private Integer state;

    /**
     * stateIn，用于批量操作
     */
    private String stateIn;

    /**
     * stateNotIn，用于批量操作
     */
    private String stateNotIn;

    /**
     * stateNotEquals，用于批量操作
     */
    private Integer stateNotEquals;

    /**
     * 拒绝原因
     */
    private String refuseReason;

    /**
     * 拒绝原因,用于模糊查询
     */
    private String refuseReasonLike;

    /**
     * 提现失败原因
     */
    private String failReason;

    /**
     * 提现失败原因,用于模糊查询
     */
    private String failReasonLike;

    /**
     * 操作管理员ID
     */
    private Integer adminId;

    /**
     * 操作管理员名称
     */
    private String adminName;

    /**
     * 操作管理员名称,用于模糊查询
     */
    private String adminNameLike;

    /**
     * 手续费
     */
    private BigDecimal serviceFee;

    /**
     * 交易流水号
     */
    private String transactionSn;

    /**
     * 交易流水号,用于模糊查询
     */
    private String transactionSnLike;

    /**
     * 排序条件，条件之间用逗号隔开，如果不传则按照cashId倒序排列
     */
    private String orderBy;

    /**
     * 分组条件
     */
    private String groupBy;

    /**
     * 分页信息
     */
    private PagerInfo pager;
}