package com.slodon.b2b2c.core.constant;

/**
 * 快递公司相关常量
 */
public class ExpressConst {

    /**
     * 快递公司状态：1-启用，0-不启用
     */
    public static final int EXPRESS_STATE_OPEN = 1;
    public static final int EXPRESS_STATE_CLOSE = 0;

}
