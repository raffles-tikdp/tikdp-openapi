package com.slodon.b2b2c.core.constant;

/**
 * 视频相关常量
 **/
public class VideoConst {

    /**
     * 角色类型:1会员，2商家
     */
    public static final int ROLE_TYPE_1 = 1;
    public static final int ROLE_TYPE_2 = 2;

    /**
     * 是否显示0:不显示，1显示
     */
    public static final int IS_SHOW_0 = 0;
    public static final int IS_SHOW_1 = 1;

    /**
     * 发布权限状态：0-默认，1-待审核，2-审核通过(正常发布)，3-审核拒绝，4-禁止发布
     */
    public static final int PERMISSION_STATE_0 = 0;
    public static final int PERMISSION_STATE_1 = 1;
    public static final int PERMISSION_STATE_2 = 2;
    public static final int PERMISSION_STATE_3 = 3;
    public static final int PERMISSION_STATE_4 = 4;

    /**
     * 视频状态:1待审核，2审核通过，3审核拒绝，4禁止显示，5删除
     */
    public static final int STATE_1 = 1;
    public static final int STATE_2 = 2;
    public static final int STATE_3 = 3;
    public static final int STATE_4 = 4;
    public static final int STATE_5 = 5;

    /**
     * 类型1:from关注to。2to关注from，3互相关注
     */
    public static final int FOLLOW_TYPE_1 = 1;
    public static final int FOLLOW_TYPE_2 = 2;
    public static final int FOLLOW_TYPE_3 = 3;

    /**
     * 是否已读：0未读，1已读
     */
    public static final int IS_READ_0 = 0;
    public static final int IS_READ_1 = 1;

    /**
     * 删除;0不删除，1伪删除
     */
    public static final int IS_DELETE_0 = 0;
    public static final int IS_DELETE_1 = 1;

    /**
     * 视频类型：1-短视频；2-直播
     */
    public static final int VIDEO_TYPE_1 = 1;
    public static final int VIDEO_TYPE_2 = 2;

    /**
     * 是否推荐，1-推荐；0-不推荐
     */
    public static final int IS_RECOMMEND_0 = 0;
    public static final int IS_RECOMMEND_1 = 1;

    /**
     * 直播状态，1-待直播；2-已开始；3-已结束；4-录制结束；5-已删除；6-平台结束
     */
    public static final int LIVE_VIDEO_STATE_1 = 1;
    public static final int LIVE_VIDEO_STATE_2 = 2;
    public static final int LIVE_VIDEO_STATE_3 = 3;
    public static final int LIVE_VIDEO_STATE_4 = 4;
    public static final int LIVE_VIDEO_STATE_5 = 5;
    public static final int LIVE_VIDEO_STATE_6 = 6;

    /**
     * 播放状态，1-正常；2-禁止
     */
    public static final int PLAY_STATE_1 = 1;
    public static final int PLAY_STATE_2 = 2;

    /**
     * 主播直播状态，1-正常；0-禁止
     */
    public static final int LIVE_STATE_1 = 1;
    public static final int LIVE_STATE_0 = 0;

    /**
     * 短视频类型:1-视频;2-图文
     */
    public static final int SVIDEO_TYPE_1 = 1;
    public static final int SVIDEO_TYPE_2 = 2;

    /**
     * 事件类型:0-直播断流;1-直播推流;100-直播录制
     */
    public static final String EVENT_TYPE_0 = "0";
    public static final String EVENT_TYPE_1 = "1";
    public static final String EVENT_TYPE_100 = "100";

    /**
     * 事件类型:publish：推流;publish_done：断流
     */
    public static final String ACTION_PUBLISH = "publish";
    public static final String ACTION_PUBLISH_DONE = "publish_done";

    /**
     * 直播和短视频设置表
     * 短视频开关，1-打开；0-关闭
     */
    public static final String VIDEO_SWITCH_1 = "1";
    public static final String VIDEO_SWITCH_0 = "0";
}
