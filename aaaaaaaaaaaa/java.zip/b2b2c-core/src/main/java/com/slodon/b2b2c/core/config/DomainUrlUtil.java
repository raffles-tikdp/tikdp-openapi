/*
 * copyright
 * slodon
 * version-v3.9
 * date-2022-03-25
 */
package com.slodon.b2b2c.core.config;

import lombok.extern.slf4j.Slf4j;

/**
 * DomainUrlUtil
 */
@Slf4j
public class DomainUrlUtil {

    /**
     * 主站的URL
     */
    public static final String SLD_API_URL = "http://8.142.26.129:9001";
    /**
     * 静态资源的URL
     */
    public static final String SLD_STATIC_RESOURCES = "http://8.142.26.129:9001";
    /**
     * admin前端地址
     */
    public static final String SLD_ADMIN_URL = "http://8.142.26.129:9001";
    /**
     * seller前端地址
     */
    public static final String SLD_SELLER_URL = "http://8.142.26.129:9002";
    /**
     * 移动端前端地址
     */
    public static final String SLD_H5_URL = "http://8.142.26.129:9003";
    /**
     * pc前端地址
     */
    public static final String SLD_PC_URL = "http://8.142.26.129:9005";

    /**
     * minio图片资源的URL
     */
    public static final String SLD_IMAGE_RESOURCES = "http://8.142.26.129:9006";
    /**
     * 七牛云图片资源的URL
     */
    public static final String QINIUYUN_IMAGE_RESOURCES = "http://javaimg.slodon.cn";
    /**
     * 腾讯云图片资源的URL
     */
    public static final String TENCENTCLOUD_IMAGE_RESOURCES = "https://javaimg-1255445787.cos.ap-beijing.myqcloud.com";
    /**
     * 阿里云图片资源的URL
     */
    public static final String ALIYUN_IMAGE_RESOURCES = "http://bucket33333333.oss-cn-beijing.aliyuncs.com";

    /**
     * Elastic Search URL PORT
     */
    public static final String SLD_ES_URL = "sld-es";
    public static final Integer SLD_ES_PORT = 9200;
    /**
     * es索引名称
     */
    public static final String ES_INDEX_NAME = "slodon-b2b2c";
    /**
     * 积分商城es索引名称
     */
    public static final String INTEGRAL_ES_INDEX_NAME = "slodon-b2b2c_integral";

    /**
     * rabbitMq host 端口号 用户名 密码
     */
    public static final String SLD_MQ_HOST = "sld-mq";
    public static final Integer SLD_MQ_PORT = 5672;
    public static final String SLD_MQ_USERNAME = "guest";
    public static final String SLD_MQ_PASSWORD = "guest";
    /**
     * rabbitMq 名称前缀（交换机、队列名称）
     */
    public static final String SLD_MQ_NAME_PREFIX = "slodon-b2b2c";

    /**
     * redis host 端口 密码
     */
    public static final String SLD_REDIS_HOST = "sld-redis";
    public static final Integer SLD_REDIS_PORT = 6379;
    public static final String SLD_REDIS_PASSWORD = "111111";

    /**
     * mysql读库 用户名 密码
     */
    public static final String SLD_MYSQL_READ_USERNAME = "quark";
    public static final String SLD_MYSQL_READ_PASSWORD = "faoiQ71635#@!";
    /**
     * mysql写库 用户名 密码
     */
    public static final String SLD_MYSQL_WRITE_USERNAME = "quark";
    public static final String SLD_MYSQL_WRITE_PASSWORD = "faoiQ71635#@!";

    /**
     * mongodb uri
     */
    public static final String SLD_MONGODB_URI = "mongodb://root:111111@sld-mongodb:27017/b2b2c";

    /**
     * 上传图片类型，1-公共上传，2-七牛云上传，3-腾讯云上传，4-阿里云上传
     */
    public static final Integer UPLOAD_IMAGE_TYPE = 1;

    /**
     * 发送短信类型，1-腾讯云发送，2-云片发送
     */
    public static final Integer SEND_SMS_TYPE = 1;

    /**
     * 数据清洗模式，1==清除模式，2==转义模式
     */
    public static final Integer XSS_MODE = 2;

    /**
     * 支付宝公钥证书路径
     */
    public static final String APP_CERT_PATH = "/root/alipay_cert/appCertPublicKey_2017112900241969.crt";
    public static final String ALIPAY_CERT_PATH = "/root/alipay_cert/alipayCertPublicKey_RSA2.crt";
    public static final String ALIPAY_ROOT_CERT_PATH = "/root/alipay_cert/alipayRootCert.crt";
}
