package com.slodon.b2b2c.core.constant;

public class ArticleConst {

    /**
     * 文章显示状态：0-不显示;1-显示
     */
    public static final int STATE_YES = 1;
    public static final int STATE_NO = 0;

}
