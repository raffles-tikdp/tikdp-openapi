package com.slodon.b2b2c.core.util;

import com.slodon.b2b2c.core.config.DomainUrlUtil;
import com.slodon.b2b2c.core.constant.ImageSizeEnum;
import org.springframework.util.StringUtils;

/**
 * 图片绝对地址工具
 */
public class FileUrlUtil {

    /**
     * 根据图片相对路径，获取绝对路径
     *
     * @param filePath
     * @param imageSize
     * @return
     */
    public static String getFileUrl(String filePath, ImageSizeEnum imageSize) {
        if (StringUtils.isEmpty(filePath)) {
            //相对地址为空
            return null;
        }
        String prefix, suffix;//图片绝对地址前缀、后缀
        switch (DomainUrlUtil.UPLOAD_IMAGE_TYPE) {
            case 1:
                //minio
                //无后缀
                suffix = "";
                if (imageSize == null || StringUtils.isEmpty(imageSize.getHeight())) {
                    //默认大图
                    prefix = DomainUrlUtil.SLD_IMAGE_RESOURCES;
                } else {
                    if (filePath.contains(".gif")) {
                        prefix = DomainUrlUtil.SLD_IMAGE_RESOURCES;
                    } else {
                        prefix = DomainUrlUtil.SLD_IMAGE_RESOURCES + "/unsafe/"
                                + imageSize.getHeight() + "x" + imageSize.getWidth() + "/"
                                + DomainUrlUtil.SLD_IMAGE_RESOURCES;
                    }
                }
                break;
            case 2:
                //七牛云
                prefix = DomainUrlUtil.QINIUYUN_IMAGE_RESOURCES + "/";
                if (imageSize == null || StringUtils.isEmpty(imageSize.getHeight())) {
                    suffix = "";
                } else {
                    suffix = "?imageView2/2/w/" + imageSize.getWidth() + "/h/" + imageSize.getHeight();
                }
                break;
            case 3:
                //腾讯云
                prefix = DomainUrlUtil.TENCENTCLOUD_IMAGE_RESOURCES;
                if (imageSize == null || StringUtils.isEmpty(imageSize.getHeight())) {
                    suffix = "";
                } else {
                    suffix = "?imageMogr2/thumbnail/" + imageSize.getWidth() + "x" + imageSize.getHeight();
                }
                break;
            case 4:
                //阿里云
                prefix = DomainUrlUtil.ALIYUN_IMAGE_RESOURCES;
                if (imageSize == null || StringUtils.isEmpty(imageSize.getHeight())) {
                    suffix = "";
                } else {
                    suffix = "?x-oss-process=image/resize,w_" + imageSize.getWidth() + ",h_" + imageSize.getHeight();
                }
                break;
            default:
                prefix = "";
                suffix = "";
                break;
        }
        //裁剪图片
        return prefix + filePath + suffix;
    }
}
