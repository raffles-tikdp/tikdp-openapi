package com.slodon.b2b2c.core.sms;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * 统一发送短信封装参数
 */
@Data
public class SmsRequest {

    @ApiModelProperty(value = "短信类型：0-验证码短信；1-通知类短信", required = true)
    private Integer smsType;

    @ApiModelProperty(value = "手机号", required = true)
    private String mobile;

    @ApiModelProperty(value = "短信模板ID")
    private String templateId;

    @ApiModelProperty(value = "短信模板内容")
    private String templateContent;

    @ApiModelProperty(value = "模版参数，从前往后对应的是模版的{1}、{2}等，若无模板参数，则设置为空")
    private String[] templateParam;

}
