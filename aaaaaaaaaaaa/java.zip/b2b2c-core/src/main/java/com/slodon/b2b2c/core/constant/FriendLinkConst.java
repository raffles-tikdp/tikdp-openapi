package com.slodon.b2b2c.core.constant;

public class FriendLinkConst {

    /**
     * 合作伙伴显示状态：0-不可见;1-可见
     */
    public static final int STATE_YES = 1;
    public static final int STATE_NO = 0;

}
