package com.slodon.b2b2c.core.constant;

public class MemberWxSignConst {
    /**
     * pc应用
     */
    public static final int PC  = 1;
    /**
     * app应用
     */
    public static final int APP = 2;
    /**
     * 公众号
     */
    public static final int GZH = 3;
    /**
     * 小程序
     */
    public static final int XCX = 4;
}
