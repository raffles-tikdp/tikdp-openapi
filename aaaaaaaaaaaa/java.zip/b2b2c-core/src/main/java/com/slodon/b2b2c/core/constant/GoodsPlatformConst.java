package com.slodon.b2b2c.core.constant;

/**
 * @program: slodon
 * @Description 平台库商品相关常量
 * @Author wuxy
 * @date 2021.10.26 11:58
 */
public class GoodsPlatformConst {

    /**
     * 商品状态：1-待刊登；2-已刊登；3-已下架；4-已删除
     */
    public final static int GOODS_STATE_1 = 1;
    public final static int GOODS_STATE_2 = 2;
    public final static int GOODS_STATE_3 = 3;
    public final static int GOODS_STATE_4 = 4;

    /**
     * 价格变动类型：1-加法；2-减法；3-乘法；4-除法
     */
    public final static int CHANGE_TYPE_1 = 1;
    public final static int CHANGE_TYPE_2 = 2;
    public final static int CHANGE_TYPE_3 = 3;
    public final static int CHANGE_TYPE_4 = 4;
}
