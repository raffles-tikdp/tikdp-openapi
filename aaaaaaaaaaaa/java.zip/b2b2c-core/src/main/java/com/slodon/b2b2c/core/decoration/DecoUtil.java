package com.slodon.b2b2c.core.decoration;

import com.slodon.b2b2c.core.util.Md5;

/**
 * 装修页生成工具类
 */
public final class DecoUtil {

    public static String encodePreview(String key) {
        String value = String.valueOf(System.currentTimeMillis());
        String str = value.substring(value.length() - 6);
        return str + Md5.getMd5String((str + key)).substring(0, 10);
    }

    public static Boolean validatePreview(String origin, String key) {
        return Md5.getMd5String(origin.substring(0, 6) + key).substring(0, 10).equalsIgnoreCase(origin.substring(6));
    }

}
