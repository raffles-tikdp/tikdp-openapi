package com.slodon.b2b2c.core.constant;

/**
 * 抽奖常量
 **/
public class DrawConst {

    /**
     * 活动规则类型，1-每人每天可抽奖n次，2-每人总共可抽奖n次
     */
    public static final int RULE_TYPE_1 = 1;
    public static final int RULE_TYPE_2 = 2;

    /**
     * 抽奖活动类型，1-幸运抽奖，2-大转盘，3-刮刮卡，4-摇一摇，5-翻翻看
     */
    public static final int DRAW_TYPE_1 = 1;
    public static final int DRAW_TYPE_2 = 2;
    public static final int DRAW_TYPE_3 = 3;
    public static final int DRAW_TYPE_4 = 4;
    public static final int DRAW_TYPE_5 = 5;

    /**
     * 活动状态(1-未开始;2-进行中;3-已结束)
     */
    public static final int STATE_1 = 1;
    public static final int STATE_2 = 2;
    public static final int STATE_3 = 3;

    /**
     * 奖品类型，1-积分，2-优惠券
     */
    public static final int PRIZE_TYPE_1 = 1;
    public static final int PRIZE_TYPE_2 = 2;

    /**
     * 是否中奖，0-未中奖，1-中奖
     */
    public static final int IS_PRIZE_0 = 0;
    public static final int IS_PRIZE_1 = 1;

    /**
     * 是否开启虚拟中奖，0-不开启，1-开启
     */
    public static final int OPEN_VIRTUAL_0 = 0;
    public static final int OPEN_VIRTUAL_1 = 1;

    /**
     * 是否虚拟数据，0-否，1-是
     */
    public static final int IS_VIRTUAL_DATA_0 = 0;
    public static final int IS_VIRTUAL_DATA_1 = 1;

}
