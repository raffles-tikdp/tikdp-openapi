package com.slodon.b2b2c.core.exception;

import com.slodon.b2b2c.core.constant.ResponseConst;

/**
 * 系统自定义异常, 常用异常参考SLDException类
 */
public class MallException extends RuntimeException {

    private static final long serialVersionUID = 2726487812574043208L;
    private int code = ResponseConst.STATE_FAIL;
    //异常产生的微服务应用名称
    private String application;

    public MallException(String msg) {
        super(msg);
    }

    public MallException(String msg, int code) {
        super(msg);
        this.code = code;
    }

    public MallException(String message, String application) {
        super(message);
        this.application = application;
    }

    public MallException(String message, int code, String application) {
        super(message);
        this.code = code;
        this.application = application;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getApplication() {
        return application;
    }

    public void setApplication(String application) {
        this.application = application;
    }

}