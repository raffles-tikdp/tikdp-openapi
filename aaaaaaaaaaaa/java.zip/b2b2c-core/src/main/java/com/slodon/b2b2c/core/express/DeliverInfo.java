package com.slodon.b2b2c.core.express;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.ToString;

import java.io.Serializable;
import java.util.List;

/**
 * @program: slodon
 * @description: 物流信息返回值封装(快递鸟)
 * @author: wuxy
 **/
@ToString
@Data
public class DeliverInfo implements Serializable {

    private static final long serialVersionUID = -720566025842547711L;
    @ApiModelProperty("快递鸟id")
    private String EBusinessID;
    @ApiModelProperty("订单号")
    private String OrderCode;
    @ApiModelProperty("物流公司编码")
    private String ShipperCode;
    @ApiModelProperty("快递单号")
    private String LogisticCode;
    @ApiModelProperty("成功")
    private String Success;
    @ApiModelProperty("状态")
    private String State;
    @ApiModelProperty("原因")
    private String Reason;
    @ApiModelProperty("物流信息")
    private List<Traces> Traces;

    @ToString
    @Data
    public static class Traces {
        @ApiModelProperty("派件时间")
        private String AcceptTime;
        @ApiModelProperty("派件状态 + 派件地点")
        private String AcceptStation;
        @ApiModelProperty("派件状态")
        private String Remark;
    }

}
