package com.slodon.b2b2c.core.constant;

/**
 * @program: slodon
 * @Description 会员提现相关常量
 * @Author wuxy
 * @date 2022.01.27 12:12
 */
public class MemberWithdrawConst {

    /**
     * 账号编码：ALIPAY-支付宝,WXPAY-微信,UNIONPAY-银行卡
     */
    public static final String ACCOUNT_CODE_ALIPAY = "ALIPAY";
    public static final String ACCOUNT_CODE_WXPAY = "WXPAY";
    public static final String ACCOUNT_CODE_UNIONPAY = "UNIONPAY";

    /**
     * 是否最近提现账号：0-否；1-是
     */
    public static final int IS_LAST_0 = 0;
    public static final int IS_LAST_1 = 1;

    /**
     * 状态：1、待处理；2、提现成功；3、已拒绝；4、提现失败
     */
    public static final int STATE_1 = 1;
    public static final int STATE_2 = 2;
    public static final int STATE_3 = 3;
    public static final int STATE_4 = 4;

}
