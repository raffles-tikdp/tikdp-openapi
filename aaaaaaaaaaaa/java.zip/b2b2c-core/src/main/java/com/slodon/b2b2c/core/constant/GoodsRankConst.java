package com.slodon.b2b2c.core.constant;

/**
 * 排行榜相关常量
 */
public class GoodsRankConst {

    /**
     * 启用状态：0-未启用；1-启用
     */
    public final static int STATE_0 = 0;
    public final static int STATE_1 = 1;

    /**
     * 榜单类型：1-畅销榜；2-好评榜；3-新品榜；4-自定义
     */
    public final static int RANK_TYPE_1 = 1;
    public final static int RANK_TYPE_2 = 2;
    public final static int RANK_TYPE_3 = 3;
    public final static int RANK_TYPE_4 = 4;

    /**
     * 统计时间：1-近7天；2-近30天
     */
    public final static int STATS_TIME_1 = 1;
    public final static int STATS_TIME_2 = 2;

    /**
     * 畅销榜计算规则：1-销量排行；2-销售额排行
     */
    public final static int BEST_SELLER_RANK_RULE_1 = 1;
    public final static int BEST_SELLER_RANK_RULE_2 = 2;

    /**
     * 新品榜计算规则：1-按照商品发布的时间降序排列；2-按照商品发布的时间升序排列
     */
    public final static int NEW_PRODUCT_RANK_RULE_1 = 1;
    public final static int NEW_PRODUCT_RANK_RULE_2 = 2;

    /**
     * 是否自动更新：1-自动；0-手动
     */
    public final static int IS_AUTO_UPDATE_0 = 0;
    public final static int IS_AUTO_UPDATE_1 = 1;
}
