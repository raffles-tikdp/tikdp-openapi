package com.slodon.b2b2c.core.sms;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 发送响应结果
 */
@NoArgsConstructor
@Data
public class SmsResponse {

    /**
     * 响应码:0代表发送成功，其他code代表出错
     */
    private String code;
    /**
     * 例如""发送成功""，或者相应错误信息
     */
    private String msg;
    /**
     * 系统发送的验证码
     */
    private String verifyCode;

    public SmsResponse(String code, String msg, String verifyCode) {
        this.code = code;
        this.msg = msg;
        this.verifyCode = verifyCode;
    }
}
