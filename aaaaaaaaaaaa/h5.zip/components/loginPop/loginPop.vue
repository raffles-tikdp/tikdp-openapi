<template>
	<uni-popup ref="loginModal" type="dialog">
		<uni-popup-dialog type="input" title="提示" content="请登录" :duration="2000" @confirm="confirmLogin">
		</uni-popup-dialog>
	</uni-popup>
</template>

<script>
	import uniPopup from '@/components/uni-popup/uni-popup.vue';
	import uniPopupDialog from '@/components/uni-popup/uni-popup-dialog.vue'
	export default {
		components: {
			uniPopup,
			uniPopupDialog
		},

		methods: {
			confirmLogin() {
				this.$refs.loginModal.close()
				this.$emit('confirmLogin')
				let url = this.$Route.path;
				const query = this.$Route.query;
				uni.setStorageSync('fromurl', {
					url,
					query
				});
				this.$Router.push('/pages/public/login')
			},
			openLogin() {
				// console.log(this.$refs,'asdasda')
				this.$refs.loginModal.open()
			},
			close() {
				this.$refs.loginModal.close()
			}
		}
	}
</script>

<style>
</style>