<!-- 推荐商品列表组件 -->
<template name="activity_not_open">
	<view class="activity_not_open">
		<view class="empty_sort_page">
			<image :src="imgUrl+'point/not_open.png'" mode="aspectFit" class="empty_img">
			</image>
			<view class="empty_text">模块暂未开启</view>
			<view class="back" @click="$Router.back(1)">返回</view>
		</view>
	</view>
</template>

<script>
	export default {
		name: 'ActivityNotOpen',
		components: {},
		data() {
			return {
				imgUrl:getApp().globalData.imgUrl,
			}
		},
		mounted() {},
	}
</script>

<style lang='scss'>
	.activity_not_open {
		.empty_sort_page {
			width: 100%;
			// height: 100vh;
			background: #F5F5F5;
			display: flex;
			flex-direction: column;
			align-items: center;
			padding-top: 340rpx;

			.empty_img {
				width: 210rpx;
				height: 210rpx;
				margin-bottom: 32rpx;
			}

			.empty_text {
				font-size: 26rpx;
				color: #999;
			}
			
			.back{
				margin-top: 80rpx;
				padding: 10rpx 50rpx;
				font-size: 28rpx;
				border: 2rpx solid #999;
				border-radius: 30rpx;
				color: #999;
			}
		}
	}
</style>
