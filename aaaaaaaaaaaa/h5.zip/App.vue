<script>
	import {
		mapMutations,
		mapState
	} from 'vuex';
	import Router from './router.js'
	import {initStat} from "./utils/stat.js";
	import Config from "./utils/config.js";
	import {WXBrowserShareStart,checkUpdate} from '@/utils/common.js';
	import loginPop from '@/components/loginPop/loginPop.vue'
	export default {
		globalData: {
			goLogin(Route) {
				let _this = this
				uni.showModal({
					title: '提示',
					content: '请登录',
					success: res => {
						if (res.confirm) {
							let url = Router.path;
							const query = Router.query;
							uni.setStorageSync('fromurl', {
								url,
								query
							});
							Router.push('/pages/public/login')
						}
					}
				});
			},
			...Config
		}, //全局配置
		computed: {
			...mapState(['hasLogin', 'userInfo', 'userCenterData'])
		},
		methods: {
			...mapMutations(['login', 'logout', 'setUserCenterData']),

			//判断当前时间是否为今天 并且不是第二天
			isToday(data) {
				return (new Date().toDateString() === data.toDateString()) && (Date.parse(data) < Date.parse(new Date(
					new Date().setHours(23, 59, 59, 59))));
			},
		},
		onLaunch: function () {
			let userInfo = uni.getStorageSync('userInfo') || '';
			if (userInfo.access_token) {
				//更新登陆状态
				uni.getStorage({
					key: 'userInfo',
					success: (res) => {
						this.login(res.data);
						this.setUserCenterData(uni.getStorageSync('userCenterData'))
					}
				});
			}
			//初始化统计数据
			let source = 'h5';
			// #ifdef APP-PLUS
			source = uni.getSystemInfoSync().platform;
			// #endif
			// #ifdef MP-WEIXIN
			source = 'xcx';
			// #endif
			
			// #ifdef MP-BAIDU
			source = 'bdxcx'
			// #endif
			
			// #ifdef MP-ALIPAY
			source = 'alixcx'
			// #endif
			
			// #ifdef MP-TOUTIAO
			source = 'dyxcx'
			// #endif
			
			// #ifdef H5
			WXBrowserShareStart()
			// #endif
			
			// #ifdef APP-PLUS
			// checkUpdate()
			// #endif
			
			//统计初始化
			initStat(this.globalData.statShowDebug, {
				equipmentType: 2, //设备类型，1-pc，2-移动设备，3-其他
				source: source, //终端名称，pc-pc；h5-H5；android-Android；ios-IOS；xcx-微信小程序
				memberId: 0, //会员id默认为0
				ip: '', //移动端ip默认都为空
			});

			uni.getSystemInfo({
				success: res => {
					this.globalData.systemInfo = res;
					this.globalData.bottomSateArea = 0; //手机底部安全区域高度
					this.globalData.model = res.model;
					this.globalData.titleBarHeight = 44; //原生的标题高度
					let iphoneXArr = ["iPhone X", "iPhone 11", "iPhone 11 Pro Max", "iPhone XR",
						"iPhoneXS"]; //iphone手机底部一条黑线
					if (iphoneXArr.indexOf(res.model) != -1) {
						this.globalData.bottomSateArea = "30rpx";
					}
					this.globalData.statusBarHeight = res.statusBarHeight;
				}
			});
		},
		onShow: function () {
			setInterval(function () {
				let data = new Date();
				let isToday = (new Date().toDateString() === data.toDateString()) && (Date.parse(data) < Date
					.parse(new Date(new Date().setHours(23, 59, 59, 59)))); //判断当前时间是否为今天并且不为第二天
				if (!isToday) {
					uni.removeSavedFile({
						key: 'cookie'
					})
				}
			}, 1000);
		},
		onHide: function () { },
	}
</script>

<style lang='scss'>
	/*
		全局图标——阿里巴巴图标库
	*/
   /* #ifndef MP-ALIPAY */
	@import './common/css/icons.css';
	/* #endif */
	/* #ifdef MP-ALIPAY */
	@import './common/css/icons_alipay.css';
	/* #endif */
	/*
		全局公共样式
	*/
	@import './common/css/base.css';

	/*
		全局公共样式和字体图标
	*/
	@font-face {
		font-family: yticon;
		font-weight: normal;
		font-style: normal;
		src: url('https://at.alicdn.com/t/font_1078604_w4kpxh0rafi.ttf') format('truetype');
	}
	
	[type="search"]::-webkit-search-decoration {  
	  display: none;  
	}
	
	/* #ifdef MP-BAIDU */
	swan-button:after{
		border: none;
	}
	/* #endif */

	/* 微信浏览器分享提示 start */
	.wx_brower_share_mask {
		width: 750rpx;
		height: 100vh;
		background-color: rgba(0, 0, 0, 0.45);
		position: fixed;
		z-index: 99999;
		top: 0;
	}

	/* #ifdef H5 */
	page {
		width: 750rpx;
		margin: 0 auto;
	}

	/* #endif */
	
	/* #ifdef MP-ALIPAY */
	page{
		height: 100vh;
	}
	/* #endif */
	
	/* #ifdef APP-PLUS */
	page {
		background: transparent;
	}
	/* #endif */

	.wx_brower_share_top_wrap {
		width: 100%;
		height: 100%;
		display: flex;
		justify-content: flex-end;
		align-items: flex-start;
		margin-top: 150rpx;
	}

	.wx_brower_share_top_wrap .wx_brower_share_img {
		width: 450rpx;
		height: 150rpx;
		margin-right: 80rpx;
	}

	.share_h5 {
		width: 100% !important;
		height: 100% !important
	}

	uni-image>img {
		opacity: unset;
		object-fit: contain;
	}

	.share_h5_operate_img {
		width: 440rpx !important;
		height: 120rpx !important;
	}

	.share_h5_close_img {
		width: 50rpx !important;
		height: 50rpx !important;
	}

	.share_h5_img_bottom {
		width: 50rpx !important;
		height: 160rpx !important;
	}

	/* 微信浏览器分享提示 end */

	.yticon {
		font-family: "yticon" !important;
		font-size: 16px;
		font-style: normal;
		-webkit-font-smoothing: antialiased;
		-moz-osx-font-smoothing: grayscale;
	}

	/* #ifdef MP-WEIXIN */
	.ql-container {
		display: flex;
		align-items: center;
		line-height: 62rpx;
	}

	/* #endif */


	.ql-editor {

		p {
			display: flex;
			align-items: center;
			flex-wrap: wrap;
			line-height: 62rpx !important;
		}
	}

	.ql-editor.ql-blank::before {
		color: rgba(0, 0, 0, 0.6);
		content: attr(data-placeholder);
		font-style: normal !important;
		pointer-events: none;
		position: absolute;
		line-height: 62rpx !important;
	}

	.icon-yiguoqi1:before {
		content: "\e700";
	}

	.icon-iconfontshanchu1:before {
		content: "\e619";
	}

	.icon-iconfontweixin:before {
		content: "\e611";
	}

	.icon-alipay:before {
		content: "\e636";
	}

	.icon-shang:before {
		content: "\e624";
	}

	.icon-shouye:before {
		content: "\e626";
	}

	.icon-shanchu4:before {
		content: "\e622";
	}

	.icon-xiaoxi:before {
		content: "\e618";
	}

	.icon-jiantour-copy:before {
		content: "\e600";
	}

	.icon-fenxiang2:before {
		content: "\e61e";
	}

	.icon-pingjia:before {
		content: "\e67b";
	}

	.icon-daifukuan:before {
		content: "\e68f";
	}

	.icon-pinglun-copy:before {
		content: "\e612";
	}

	.icon-dianhua-copy:before {
		content: "\e621";
	}

	.icon-shoucang:before {
		content: "\e645";
	}

	.icon-xuanzhong2:before {
		content: "\e62f";
	}

	.icon-gouwuche_:before {
		content: "\e630";
	}

	.icon-icon-test:before {
		content: "\e60c";
	}

	.icon-icon-test1:before {
		content: "\e632";
	}

	.icon-bianji:before {
		content: "\e646";
	}

	.icon-jiazailoading-A:before {
		content: "\e8fc";
	}

	.icon-zuoshang:before {
		content: "\e613";
	}

	.icon-jia2:before {
		content: "\e60a";
	}

	.icon-huifu:before {
		content: "\e68b";
	}

	.icon-sousuo:before {
		content: "\e7ce";
	}

	.icon-arrow-fine-up:before {
		content: "\e601";
	}

	.icon-hot:before {
		content: "\e60e";
	}

	.icon-lishijilu:before {
		content: "\e6b9";
	}

	.icon-zhengxinchaxun-zhifubaoceping-:before {
		content: "\e616";
	}

	.icon-naozhong:before {
		content: "\e64a";
	}

	.icon-xiatubiao--copy:before {
		content: "\e608";
	}

	.icon-shoucang_xuanzhongzhuangtai:before {
		content: "\e6a9";
	}

	.icon-jia1:before {
		content: "\e61c";
	}

	.icon-bangzhu1:before {
		content: "\e63d";
	}

	.icon-arrow-left-bottom:before {
		content: "\e602";
	}

	.icon-arrow-right-bottom:before {
		content: "\e603";
	}

	.icon-arrow-left-top:before {
		content: "\e604";
	}

	.icon-icon--:before {
		content: "\e744";
	}

	.icon-zuojiantou-up:before {
		content: "\e605";
	}

	.icon-xia:before {
		content: "\e62d";
	}

	.icon--jianhao:before {
		content: "\e60b";
	}

	.icon-weixinzhifu:before {
		content: "\e61a";
	}

	.icon-comment:before {
		content: "\e64f";
	}

	.icon-weixin:before {
		content: "\e61f";
	}

	.icon-fenlei1:before {
		content: "\e620";
	}

	.icon-erjiye-yucunkuan:before {
		content: "\e623";
	}

	.icon-Group-:before {
		content: "\e688";
	}

	.icon-you:before {
		content: "\e606";
	}

	.icon-forward:before {
		content: "\e607";
	}

	.icon-tuijian:before {
		content: "\e610";
	}

	.icon-bangzhu:before {
		content: "\e679";
	}

	.icon-share:before {
		content: "\e656";
	}

	.icon-yiguoqi:before {
		content: "\e997";
	}

	.icon-shezhi1:before {
		content: "\e61d";
	}

	.icon-fork:before {
		content: "\e61b";
	}

	.icon-kafei:before {
		content: "\e66a";
	}

	.icon-iLinkapp-:before {
		content: "\e654";
	}

	.icon-saomiao:before {
		content: "\e60d";
	}

	.icon-shezhi:before {
		content: "\e60f";
	}

	.icon-shouhoutuikuan:before {
		content: "\e631";
	}

	.icon-gouwuche:before {
		content: "\e609";
	}

	.icon-dizhi:before {
		content: "\e614";
	}

	.icon-fenlei:before {
		content: "\e706";
	}

	.icon-xingxing:before {
		content: "\e70b";
	}

	.icon-tuandui:before {
		content: "\e633";
	}

	.icon-zuanshi:before {
		content: "\e615";
	}

	.icon-zuo:before {
		content: "\e63c";
	}

	.icon-shoucang2:before {
		content: "\e62e";
	}

	.icon-shouhuodizhi:before {
		content: "\e712";
	}

	.icon-yishouhuo:before {
		content: "\e71a";
	}

	.icon-dianzan-ash:before {
		content: "\e617";
	}

	button::after{
		border: none;
	}



	view,
	scroll-view,
	swiper,
	swiper-item,
	cover-view,
	cover-image,
	icon,
	text,
	rich-text,
	progress,
	button,
	checkbox,
	form,
	input,
	label,
	radio,
	slider,
	switch,
	textarea,
	navigator,
	audio,
	camera,
	image,
	video {
		box-sizing: border-box;
	}

	/* 骨架屏替代方案 */
	.Skeleton {
		background: #f3f3f3;
		padding: 20upx 0;
		border-radius: 8upx;
	}

	/* 图片载入替代方案 */
	.image-wrapper {
		font-size: 0;
		background: #f3f3f3;
		border-radius: 4px;

		image {
			width: 100%;
			height: 100%;
			transition: .6s;
			opacity: 0;

			&.loaded {
				opacity: 1;
			}
		}
	}

	.clamp {
		overflow: hidden;
		text-overflow: ellipsis;
		white-space: nowrap;
		display: block;
	}

	.common-hover {
		background: #f5f5f5;
	}

	/*边框*/
	.b-b:after,
	.b-t:after {
		position: absolute;
		z-index: 3;
		left: 0;
		right: 0;
		height: 0;
		content: '';
		transform: scaleY(.5);
		border-bottom: 1rpx solid rgba(0, 0, 0, .1);
	}

	/*边框*/
	.b_b:after,
	.b_t:after {
		position: absolute;
		z-index: 3;
		left: 0;
		right: 0;
		height: 0;
		content: '';
		transform: scaleY(.5);
		border-bottom: 1rpx solid rgba(0, 0, 0, .1);
	}

	.b_b:after {
		bottom: 0;
	}

	.b_t:after {
		top: 0;
	}

	.b-b:after {
		bottom: 0;
	}

	.b-t:after {
		top: 0;
	}

	/* button样式改写 */
	uni-button,
	button {
		height: 80upx;
		line-height: 80upx;
		font-size: $font-lg + 2upx;
		font-weight: normal;

		&.no-border:before,
		&.no-border:after {
			border: 0;
		}
	}

	uni-button[type=default],
	button[type=default] {
		color: $font-color-dark;
	}

	/* input 样式 */
	.input-placeholder {
		color: #999999;
	}

	.placeholder {
		color: #949494;
		font-size: 26rpx;
	}

	::-webkit-scrollbar {
		display: none;
		width: 0;
		height: 0;
		color: transparent;
		display: flex;
		justify-content: center;
	}

	uni-tabbar .uni-tabbar {
		-webkit-box-shadow: 0 -2px 7px 0 hsla(0, 0%, 89.8%, .5);
		box-shadow: 0 -2px 7px 0 hsla(0, 0%, 89.8%, .5);
		width: 750rpx !important;
		left: auto !important;
		right: auto !important;
	}

	uni-tabbar {
		right: 0;
		display: flex;
		justify-content: center;
	}

	uni-page-head .uni-page-head {
		width: 750rpx !important;
		left: auto !important;
		right: auto !important;
	}

	uni-page-head {
		display: flex !important;
		justify-content: center;
	}

	body {
		font-family: "PingFangSC-Regular", "Microsoft YaHei", "Helvetica", "Droid Sans", "Arial", "sans-serif";
	}

	* {
		-webkit-font-smoothing: subpixel-antialiased
	}

	/* 商品详情页 H5 图文详情强制换行处理 start */
	/* #ifdef H5 */
	.detail-desc {
		word-break: break-all;
	}

	/* #endif */
	/* 商品详情页 H5 图文详情强制换行处理 end */
	.uni-page-head .uni-page-head-ft .uni-page-head-btn .uni-btn-icon {
		font-size: 40rpx;
		margin-right: 15rpx;
	}

	.uni-popup.spec_model.bottom .uni-transition.fade-out {
		width: 750rpx;
		right: 0;
		left: 0;
		margin: 0 auto;
	}

	.uni-picker-container,
	.uni-picker-toggle,
	.uni-picker-toggle {
		width: 750rpx !important;
		left: 0 !important;
		right: 0 !important;
		margin: 0 auto !important;
	}

	.uni-popup .fade-out {
		width: 750rpx;
		margin: 0 auto;
	}

	.select_address .content_view {
		width: 750rpx;
		margin: 0 auto;
	}

	/* 分页loading */
	.loading {
		display: flex;
		align-items: center;
		justify-content: center;
		height: 80rpx;
		font-size: 24rpx;
		color: #999;
	}

	.spinner {
		display: inline-block;
		vertical-align: middle;
		margin-right: 20rpx;
		font-size: 26rpx;
		width: 26rpx;
		height: 26rpx;
		text-align: left;
		border-radius: 50%;
		box-shadow: inset 0 0 0 3rpx rgba(58, 168, 237, .3);
	}

	.spinner text {
		position: absolute;
		clip: rect(0, 26rpx, 26rpx, 13rpx);
		width: 26rpx;
		height: 26rpx;
		animation: spinner-circle-clipper 1s ease-in-out infinite;
		-webkit-animation: spinner-circle-clipper 1s ease-in-out infinite;
	}

	@keyframes spinner-circle-clipper {
		0% {
			transform: rotate(0deg);
		}

		100% {
			transform: rotate(180deg);
		}
	}

	@-webkit-keyframes spinner-circle-clipper {
		0% {
			-webkit-transform: rotate(0deg);
		}

		100% {
			-webkit-transform: rotate(180deg);
		}
	}

	.spinner text:after {
		position: absolute;
		clip: rect(0, 26rpx, 26rpx, 13rpx);
		width: 26rpx;
		height: 26rpx;
		content: '';
		animation: spinner-circle 1s ease-in-out infinite;
		-webkit-animation: spinner-circle 1s ease-in-out infinite;
		border-radius: 50%;
		box-shadow: inset 0 0 0 3rpx #3aa8ed;
	}

	@keyframes spinner-circle {
		0% {
			transform: rotate(-180deg);
		}

		100% {
			transform: rotate(180deg);
		}
	}

	@-webkit-keyframes spinner-circle {
		0% {
			-webkit-transform: rotate(-180deg);
		}

		100% {
			-webkit-transform: rotate(180deg);
		}
	}
</style>