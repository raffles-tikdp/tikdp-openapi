import Vue from 'vue'
import Vuex from 'vuex'
import {updateStatCommonProperty} from '../utils/stat.js'

Vue.use(Vuex)

const store = new Vuex.Store({
	state: {
		hasLogin: false,
		userInfo: {
			access_token:'',
			refresh_token:''
		},
		userCenterData:{},//个人中心页面数据
		cartData:{},//购物车数据
		addressList:[],//收货地址列表
		chatBaseInfo:uni.getStorageSync('chatBaseInfo')?uni.getStorageSync('chatBaseInfo'):{},//聊天的基本信息，包含会员id、头像、店铺id、头像
	},
	mutations: {
		login(state, provider) {
			state.hasLogin = true;
			state.userInfo = provider;
			updateStatCommonProperty({memberId:provider.memberId});//登录成功需要更新统计里面的会员id
			//缓存用户登陆状态
			uni.setStorageSync('userInfo',provider);
		},
		logout(state) {
			state.hasLogin = false;
			state.userInfo = {};
			state.userCenterData = {};
			state.cartData = {};
			state.addressList = [];
			state.chatBaseInfo = {}
			uni.removeStorage({key: 'addressId'});
			uni.removeStorage({key: 'userInfo'});
			uni.removeStorage({key: 'userCenterData'});
			updateStatCommonProperty({memberId:0});//退出登录需要将会员id置为0
		},
		
		//设置个人中心的数据
		setUserCenterData(state, provider){
			state.userCenterData = provider
			//缓存用户个人信息
			uni.setStorageSync('userCenterData',provider)
		},
		
		//操作购物车的数据
		operateCartData(state, provider){
			state.cartData = provider
		},
		
		//操作收货地址
		operateAddressData(state, provider){
			state.addressList = provider
		},
		//保存聊天的会员id、会员头像，店铺id、店铺头像
		saveChatBaseInfo(state, provider){
			state.chatBaseInfo = provider
			//缓存聊天的基本信息
			uni.setStorageSync('chatBaseInfo',provider)
		},
		
	},
	actions: {
	
	}
})

export default store
