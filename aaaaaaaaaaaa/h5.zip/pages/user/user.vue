<template>
	<view class="container">
		<!-- 会员信息 上滑展示 start -->
		<view class="member_info_sliding" v-if="memberSliding">
			<view class="member_info_sliding_left">
				<image :src="userCenterData.memberAvatar != undefined ? userCenterData.memberAvatar : defaultAvatar"
					mode="aspectFill"></image>
			</view>
			<view class="member_info_sliding_center">
				{{$L('我的')}}
			</view>
			<view class="member_info_sliding_right">
				<view class="user_sets" @click="goSet()">
					<image :src="imgUrl + 'member/setting_icon1.png' " mode="aspectFit" class="user_set_img"></image>
				</view>
				<view class="user_msg" @click="goMsg()">
					<image :src="imgUrl + 'member/msg_icon1.png'" mode="aspectFit" class="user_msg_img"></image>
					<text v-if="userCenterData && userCenterData.msgNum > 0">{{userCenterData.msgNum > 99 ? '99+' :
						userCenterData.msgNum}}</text>
				</view>
			</view>
		</view>
		<view class="member_info_sliding" v-if="memberSliding">
			<view class="member_info_sliding_left">
				<image :src="userCenterData.memberAvatar != undefined ? userCenterData.memberAvatar : defaultAvatar"
					mode="aspectFill"></image>
			</view>
			<view class="member_info_sliding_center">
				{{$L('我的')}}
			</view>
			<view class="member_info_sliding_right">
				<view class="user_sets" @click="goSet()">
					<image :src="imgUrl + 'member/setting_icon1.png' " mode="aspectFit" class="user_set_img"></image>
				</view>
				<view class="user_msg" @click="goMsg()">
					<image :src="imgUrl + 'member/msg_icon1.png'" mode="aspectFit" class="user_msg_img"></image>
					<text v-if="userCenterData && userCenterData.msgNum > 0">{{userCenterData.msgNum > 99 ? '99+' :
						userCenterData.msgNum}}</text>
				</view>
			</view>
		</view>
		<!-- 会员信息 上滑展示 end -->


		<!-- 会员信息 start 未上滑 -->
		<view class="user-section">
			<view class="fixed_top_status_bar"></view>
			<image class="bg" :src="imgUrl+'member/member_bg.png'" mode="aspectFit"></image>
			<view class="user_set">
				<view class="user_msg" @click="goSet()">
					<image :src="imgUrl + 'member/setting_icon.png' " mode="aspectFit" class="user_set_img"></image>
				</view>
				<view class="user_msg" @click="goMsg()">
					<image :src="imgUrl + 'member/msg_icon.png'" mode="aspectFit" class="user_msg_img"></image>
					<text v-if="userCenterData && userCenterData.msgNum > 0">{{userCenterData.msgNum > 99 ? '99+' :
						userCenterData.msgNum}}</text>
				</view>
			</view>
			<view class="user-info-box">
				<view class="portrait-box">
					<view class="portrait-bgc">
						<image
							:src="userCenterData && userCenterData.memberAvatar != undefined ? userCenterData.memberAvatar : defaultAvatar"
							mode="aspectFill" class="portrait"></image>
					</view>
				</view>
				<view class="mem-info">

					<text class="nick-name"
						v-if="userCenterData && (userCenterData.memberName || userCenterData.memberNickName)"
						@click="navTo('/pages/user/info')">{{userCenterData.memberNickName||userCenterData.memberName}}</text>
					<!-- #ifdef MP-WEIXIN -->
					<button class="login_btn"
						v-if="(!userCenterData || (userCenterData && !userCenterData.memberName))&&canIUseGetUserProfile"
						@tap="getUserProfile">
						<text class="nick-name">{{$L('登录')}}</text>
					</button>
					<button class="login_btn" open-type="getUserInfo" @getuserinfo="getUser"
						v-if="(!userCenterData || (userCenterData && !userCenterData.memberName))&&!canIUseGetUserProfile">
						<text class="nick-name">{{$L('登录')}}</text>
					</button>
					<!-- #endif -->
					<!-- #ifndef MP-WEIXIN -->
					<text class="nick-name" @tap="gotoLogin"
						v-if="!userCenterData || (userCenterData && !userCenterData.memberName)">{{$L('登录')}}</text>
					<!-- #endif -->

					<text class="member-name" @click="navTo('/pages/user/info')"
						v-if="userCenterData && userCenterData.memberName">{{$L('会员名:')}}{{userCenterData.memberName}}</text>
				</view>
			</view>

			<view v-if="isSignOpen" @click="navTo('/standard/signIn/signIn')">
				<view class="check-in">
					<image :src="imgUrl+ 'signIn/mine_time.png'" mode="widthFix"></image>
					{{isSign?'已签到':'去签到'}}
				</view>
			</view>
		</view>
		<!-- 会员信息 未上滑 end -->

		<!-- 关注店铺  我的收藏 我的足迹 start -->
		<view class="mine_record">
			<view class="mine_record_pre" @click="navTo('/standard/store/attentionStore')">
				<image :src="imgUrl + 'member/mine_stores.png'" mode="aspectFit"></image>
				<text>{{$L('关注店铺')}}<text
						v-if="hasLogin && userCenterData && userCenterData.followStoreNum">({{userCenterData.followStoreNum
						? userCenterData.followStoreNum : 0}})</text></text>
			</view>
			<view class="mine_record_pre" @click="navTo('/pages/member/collect')">
				<image :src="imgUrl + 'member/mine_collection.png'" mode="aspectFit"></image>
				<text>{{$L('我的收藏')}}<text
						v-if="hasLogin && userCenterData && userCenterData.followProductNum">({{userCenterData.followProductNum
						? userCenterData.followProductNum : 0}})</text></text>
			</view>
			<view class="mine_record_pre" @click="navTo('/pages/member/history')">
				<image :src="imgUrl + 'member/mine_footprint.png'" mode="aspectFit"></image>
				<text>{{$L('我的足迹')}}<text
						v-if="hasLogin && userCenterData && userCenterData.lookLogNum">({{userCenterData.lookLogNum ?
						userCenterData.lookLogNum : 0}})</text></text>
			</view>
		</view>
		<!-- 关注店铺  我的收藏 我的足迹 end -->

		<view class="main-content">
			<!-- 我的订单 start-->
			<view class="order-part flex_column_start_start">
				<view class="title flex_row_between_center">
					<text class="left">{{$L('我的订单')}}</text>
					<view class="right flex_row_end_center" @click="navTo({path:'/pages/order/list',query:{state:0}})">
						<text>{{$L('全部订单')}}</text>
						<image :src="imgUrl+'member/right_down.png'" mode="aspectFit" />
					</view>
				</view>
				<view class="detail flex_row_around_center">
					<view class="wait-pay item flex_column_center_center"
						@click="navTo({path:'/pages/order/list',query:{state:1}})">
						<image :src="imgUrl+'member/wait_pay_icon.png'" mode="aspectFit" />
						<text class="show-text">{{$L('待付款')}}</text>
						<text class="nums" :class="{num:userCenterData.toPaidOrder <= 9}"
							v-if="userCenterData && userCenterData.toPaidOrder">{{userCenterData.toPaidOrder>99?'99+':userCenterData.toPaidOrder}}</text>
					</view>
					<view class="wait-pay item flex_column_center_center"
						@click="navTo({path:'/pages/order/list',query:{state:2}})">
						<image :src="imgUrl+'member/wait_deliver_icon.png'" mode="aspectFit" />
						<text class="show-text">{{$L('待发货')}}</text>
						<text v-if="userCenterData && userCenterData.toDeliverOrder" class="nums"
							:class="{num:userCenterData.toDeliverOrder <= 9}">{{userCenterData.toDeliverOrder>99?'99+':userCenterData.toDeliverOrder}}</text>
					</view>
					<view class="wait-pay item flex_column_center_center"
						@click="navTo({path:'/pages/order/list',query:{state:3}})">
						<image :src="imgUrl+'member/wait_receive_icon.png'" mode="aspectFit" />
						<text class="show-text">{{$L('待收货')}}</text>
						<text v-if="userCenterData && userCenterData.toReceivedOrder" class="nums"
							:class="{num:userCenterData.toReceivedOrder <= 9}">{{userCenterData.toReceivedOrder>99?'99+':userCenterData.toReceivedOrder}}</text>
					</view>
					<view class="wait-pay item flex_column_center_center"
						@click="navTo({path:'/pages/order/list',query:{state:4}})">
						<image :src="imgUrl+'member/wait_evaluate_icon.png'" mode="aspectFit" />
						<text class="show-text">{{$L('待评价')}}</text>
						<text v-if="userCenterData && userCenterData.toEvaluateOrder" class="nums"
							:class="{num:userCenterData.toEvaluateOrder <= 9}">{{userCenterData.toEvaluateOrder>99?'99+':userCenterData.toEvaluateOrder}}</text>
					</view>
					<view class="wait-pay item flex_column_center_center"
						@click="navTo({path:'/pages/order/returnAndRefundList',query:{state:0}})">
						<image :src="imgUrl+'member/wait_service_icon.png'" mode="aspectFit" />
						<text class="show-text">{{$L('退款/售后')}}</text>
						<text v-if="userCenterData && userCenterData.afterSaleNum" class="nums"
							:class="{num:userCenterData.afterSaleNum <= 9}">{{userCenterData.afterSaleNum>99?'99+':userCenterData.afterSaleNum}}</text>
					</view>
				</view>
			</view>
			<!-- 我的订单 end-->

			<!-- video_poster start -->
			<view class="picture_adv_poster_con" @click="goMyVideo"
				v-if="(hasLogin && (setting.video_switch == '1'||setting.live_switch == '1'))">
				<image :src="imgUrl + 'svideo/video_poster3x.png'"></image>
			</view>
			<!-- video_poster end-->

			<!-- 开店横版广告展示 start -->
			<view class="picture_adv_poster_con" @click="sellerOpt" v-if="hasLogin&&userCenterData.sellerSwitch==1">
				<image :src="imgUrl+'store_poster.png'" mode="aspectFit"></image>
			</view>
			<!-- 开店横版广告展示 end -->

			<!-- 常用服务 start -->
			<view class="common_services">
				<view class="common_services_title">{{$L('常用服务')}}</view>
				<view class="common_services_list">
					<view class="common_services_pre" @click="navTo('/pages/balance/balance')">
						<view class="common_serv_pre_left">
							<image :src="imgUrl + 'member/mine_wallet.png'" mode="aspectFit"></image>
							<text>{{$L('我的钱包')}}</text>
						</view>
						<view class="common_serv_pre_right">
							<text
								v-if="userCenterData && userCenterData.memberBalance">￥{{userCenterData.memberBalance}}</text>
							<image :src="imgUrl+'member/right_down.png'" mode="aspectFit" />
						</view>
					</view>
					<view class="common_services_pre" @click="toPointsPage">
						<view class="common_serv_pre_left">
							<image :src="imgUrl + 'member/mine_integral.png'" mode="aspectFit"></image>
							<text>{{$L('我的积分')}}</text>
						</view>
						<view class="common_serv_pre_right">
							<text
								v-if="userCenterData && userCenterData.memberIntegral">{{userCenterData.memberIntegral}}</text>
							<image :src="imgUrl+'member/right_down.png'" mode="aspectFit" />
						</view>
					</view>
					<view class="common_services_pre" @click="goMyCoupon">
						<view class="common_serv_pre_left">
							<image :src="imgUrl + 'member/my_coupon.png'" mode="aspectFit"></image>
							<text>{{$L('我的优惠券')}}</text>
						</view>
						<view class="common_serv_pre_right">
							<text v-if="userCenterData && userCenterData.couponNum">{{userCenterData.couponNum}}</text>
							<image :src="imgUrl+'member/right_down.png'" mode="aspectFit" />
						</view>
					</view>
					<view class="common_services_pre" @click="goMyPointOrder">
						<view class="common_serv_pre_left">
							<image :src="imgUrl + 'member/point_order.png'" mode="aspectFit"></image>
							<text>{{$L('我的积分订单')}}</text>
						</view>
						<view class="common_serv_pre_right">
							<text v-if="pointOrderNums&&hasLogin">{{pointOrderNums}}</text>
							<image :src="imgUrl+'member/right_down.png'" mode="aspectFit" />
						</view>
					</view>
					<view class="common_services_pre" @click="makeCall">
						<view class="common_serv_pre_left">
							<image :src="imgUrl + '/customer_help_icon.png'" mode="aspectFit"></image>
							<text>官方客服</text>
						</view>
						<view class="common_serv_pre_right">
							<image :src="imgUrl+'member/right_down.png'" mode="aspectFit" />
						</view>
					</view>
				</view>
			</view>
			<!-- 常用服务 end -->
		</view>
		<!-- 推荐商品 start-->
		<recommendGoods ref='recomment_goods' @reload_cart="getCartNum" />
		<!-- 推荐商品 end-->

		<!-- 开屏框 start -->

		<view class="open_screen" v-if="signOpenCookie&&!isSign">
			<view :style="{ width: width + 'rpx', 'height': height + 'rpx' }" class="open_screen_con"
				@click="navTo('/standard/signIn/signIn')">
				<view class="con_img" @click.stop="signOpenCookie = false">
					<image :src="imgUrl+'signIn/close_screen.png'"></image>
				</view>
				<image class="open_screen_con_img" :src="JSON.stringify(signNotice)?signNotice:openscnImg"
					style="height:821rpx" mode="aspectFit"></image>
			</view>
		</view>
		<!-- 开屏框 end -->
		<uni-popup ref="popup" type="dialog">
			<uni-popup-dialog type="input" title="温馨提示" :content="sellerTip" :confirmText="'复制'" :duration="2000"
				@confirm="copyClipp"></uni-popup-dialog>
		</uni-popup>

		<!-- #ifdef MP-WEIXIN -->
		<uni-popup uni-popup ref="wt" type="center" :mask-click="false">
			<view class="sld-success flex_column_center_center">
				<view class="sld-success-title">是否允许获取该微信绑定的手机号？</view>
				<view class="sld-btns">
					<button @click="getBindCancle">取消</button>
					<button open-type="getPhoneNumber" @getphonenumber="getMobile" class="confirm">确定</button>
				</view>
			</view>
		</uni-popup>

		<uni-popup uni-popup ref="bind" type="center" :mask-click="false">
			<view class="wrapper">
				<view class="bind_state_top">

					<text class="mobile_num">{{userPhone}}</text>
					<text class="mobile_binded">{{$L('该手机号已被绑定')}}</text>
				</view>
				<view class="bind_change_info">
					<view class="bind_change_info_text">{{$L('继续绑定：将解除与账号')}}<text
							class="change_info_mobile">{{bindedAccount}}</text>{{$L('的绑定关系')}}</view>
					<view class="bind_change_info_text">{{$L('更新信息：授权信息将绑定到账号')}}<text
							class="change_info_mobile">{{bindedAccount}}</text>{{$L('上')}}</view>
				</view>
				<view class="bind_state_btn_con">
					<view class="update_btn" @click="bindMobile(3)">{{$L('更新信息')}}</view>
					<view class="go_on_btn" @click="bindMobile(2)">{{$L('继续绑定')}}</view>
				</view>
			</view>
		</uni-popup>
		<!-- #endif -->

		<loginPop ref="loginPop" @confirmLogin="confirmLogin"></loginPop>

	</view>
</template>
<script>
	import recommendGoods from "@/components/recommend-goods.vue"
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	import uniPopupDialog from '@/components/uni-popup/uni-popup-dialog.vue'
	import h5Copy from '@/utils/H5copy.js'
	import {
		mapState,
		mapMutations
	} from 'vuex';
	let startY = 0,
		moveY = 0,
		pageAtTop = true;
	export default {
		components: {
			recommendGoods,
			uniPopup,
			uniPopupDialog
		},
		data() {
			return {
				imgUrl: getApp().globalData.imgUrl,
				defaultAvatar: getApp().globalData.imgUrl + 'default/member-avatar.png', //默认头像
				coverTransform: 'translateY(0px)',
				coverTransition: '0s',
				moving: false,
				client: 1, //终端类型， 1、H5(微信内部浏览器) 2、H5(微信小程序)；3、app
				oriUrl: '', //不带code的页面地址
				memberSliding: false, //页面上滑效果是否显示
				pointOrderNums: 0, //为完成积分订单数量
				videoNum: 0, //我的视频数量
				setting: {}, //平台配置信息
				bgStyle: 'background-size:contain;background-position:center center;background-repeat: no-repeat;',
				canIUseGetUserProfile: false, //是否可以使用getUserProfile获取用户信息，用于微信小程序,
				openscnImg: getApp().globalData.imgUrl + 'signIn/signner.png',
				width: 636,
				height: 821,
				signOpenCookie: false, //签到提醒flag,
				isSignOpen: false, //签到活动是否可用
				isSign: false, //是否签到,
				showState: false,
				signNotice: {},
				adminTel: '',
				sellerTip: '',
				isClick: true,
				wtCode: '',
				userPhone: '',
				bindState: true,
				bindedAccount: '',
				bindKey: '',
				adminSerAvatar: '',
				adminSerName: ''
			}
		},


		onLoad(option) {

			this.client = this.$getLoginClient();
			//#ifdef MP-WEIXIN
			if (uni.getUserProfile) {
				this.canIUseGetUserProfile = true;
			}
			//#endif
			//#ifdef H5
			let code = this.$getQueryVariable('code');
			if (code) {
				let oriUrl = this.$Route.query.ori_url + 'pages/user/user';
				let tmp_data = '';
				for (let i in this.$Route.query) {
					if (i != 'ori_url') {
						tmp_data += i + '=' + this.$Route.query[i] + '&'
					}
				}
				oriUrl += '?' + tmp_data;
				this.oriUrl = oriUrl;
				if (this.$isWeiXinBrower()) {
					//微信浏览器的话要把浏览器地址里面的code去掉
					history.replaceState({}, '', this.oriUrl);
				}
				this.toLogin(code, '');
			}
			//#endif
			this.initData();
			this.getSetting();
			this.getSysSetting()
			if (this.hasLogin) {
				this.signOpenScreen();
			}

		},
		onShow() {
			if (this.$refs.loginPop != undefined) {
				this.$refs.loginPop.close()
			}
			if (this.showState) {
				this.initData();
				this.getSetting();
				this.signOpenScreen();
				this.$refs.loginPop.close()
			}


			//统计埋点方法--针对微信小程序
			// #ifdef MP-WEIXIN
			let url = getApp().globalData.apiUrl.substring(0, getApp().globalData.apiUrl.length - 1);
			this.$sldStatEvent({
				behaviorType: 'pv',
				pageUrl: url + '/pages/user/user',
				referrerPageUrl: ''
			});
			// #endif
			this.getCartNum();
		},

		onHide() {
			this.signOpenCookie = false
		},

		// #ifndef MP
		onNavigationBarButtonTap(e) {
			const index = e.index;
			if (index === 0) {
				this.navTo('/pages/set/set');
			} else if (index === 1) {
				// #ifdef APP-PLUS
				const pages = getCurrentPages();
				const page = pages[pages.length - 1];
				const currentWebview = page.$getAppWebview();
				currentWebview.hideTitleNViewButtonRedDot({
					index
				});
				// #endif
				this.$Router.push('/pages/notice/noticeCenter')
			}
			this.showState = true
		},
		// #endif
		computed: {
			...mapState(['hasLogin', 'userInfo', 'userCenterData'])
		},
		onReachBottom() {
			this.$refs.recomment_goods.getMoreData();
		},
		//监听页面滚动，顶部上滑效果显示
		onPageScroll(res) {
			if (res.scrollTop > 191) {
				this.memberSliding = true;
			} else {
				this.memberSliding = false;
			}
		},
		methods: {
			...mapMutations(['login', 'setUserCenterData','saveChatBaseInfo']),
			//获取个人中心数据


			confirmLogin() {
				this.$refs.loginPop.close()
				this.showState = true
			},

			initData() {
				let that = this;
				if (this.userInfo.access_token) {
					this.$request({
						url: 'v3/member/front/member/getInfo',
					}).then(res => {
						if (res.state == 200) {
							that.$request({
								url: '/v3/helpdesk/front/chat/unReadMsgNum',
							}).then(response => {
								if (response.state == 200) {
									res.data.msgNum = response.data
									that.setUserCenterData(res.data);
								} else {
									that.setUserCenterData(res.data);
								}
							})
						} else {
							this.$api.msg(res.msg);
						}
					}).catch((e) => {})

					//获取订单订单未完成数量
					this.$request({
						url: 'v3/integral/front/integral/order/orderCount',
					}).then(res => {
						if (res.state == 200) {
							this.pointOrderNums = res.data;
						}
					})

					this.$request({
						url: 'v3/video/front/video/author/personPage'
					}).then(res => {
						if (res.state == 200) {
							this.videoNum = res.data.videoNum
						}
					})
				}
			},
			// 获取设置信息
			getSetting() {
				let param = {};
				param.url = 'v3/video/front/video/setting/getSettingList';
				param.method = 'GET';
				param.data = {};
				param.data.str = 'video_switch,live_switch';
				this.$request(param).then(res => {
					if (res.state == 200) {
						let result = res.data;
						result && result.map(settingItem => {
							if (settingItem.name == 'video_switch') { //绑定商品数
								this.setting.video_switch = settingItem.value;
							} else {
								this.setting.live_switch = settingItem.value;
							}
						})
					}
				})
			},

			getSysSetting() {
				let param = {
					url: 'v3/system/front/setting/getSettings',
					data: {
						names: 'basic_site_phone,platform_customer_service_name,platform_customer_service_logo'
					}
				};
				this.$request(param).then(res => {
					if (res.state == 200) {
						this.adminTel = res.data[0]
						this.adminSerName = res.data[1]
						this.adminSerAvatar = res.data[2]
					}
				})
			},

			makeCall() {
				
				if(!this.hasLogin){
					this.$refs.loginPop.openLogin()
					return
				}

				let chatInfo = {
					memberId: this.userCenterData.memberId,
					memberName: this.userCenterData.memberName,
					memberNickName: this.userCenterData.memberNickName,
					memberAvatar: this.userCenterData.memberAvatar,
					storeId: 0,
					storeLogo: this.adminSerAvatar,
					storeName: this.adminSerName,
					showData: {},
					source: '',
				}

				this.saveChatBaseInfo(chatInfo);
				this.$Router.push({
					path: '/standard/chat/detail',
					query: {
						vid: 0
					}
				})
			},

			sellerOpt() {
				this.sellerTip = `请复制地址到电脑端操作:\n${this.userCenterData.sellerUrl}`
				this.$refs.popup.open()
			},

			copyClipp() {
				this.$refs.popup.close()
				// #ifdef H5
				const result = h5Copy(this.userCenterData.sellerUrl)
				if (result === false) {
					this.$api.msg('不支持')
				} else {
					this.$api.msg('已复制到剪贴板')
				}
				// #endif

				// #ifdef APP-PLUS || MP-WEIXIN
				uni.setClipboardData({
					data: this.userCenterData.sellerUrl,
					success: function() {
						this.$api.msg('已复制到剪贴板')
					}
				});
				// #endif

			},

			gotoLogin() {
				uni.setStorageSync('fromurl', {
					url: '/pages/user/user'
				});
				this.showState = true

				// #ifdef APP-PLUS || MP
				this.$Router.push('/pages/public/login');
				// #endif

				// #ifdef H5
				let isWexin = this.$isWeiXinBrower();
				if (isWexin) {
					let tar_url = location.href;
					tar_url += location.href.indexOf('?') > -1 ? '&' : '?';
					tar_url += 'ori_url=' + location.href;
					let uricode = encodeURIComponent(tar_url)
					window.location.href = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' +
						getApp().globalData.h5AppId +
						'&redirect_uri=' + uricode +
						'&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect';
				} else {
					this.$Router.push('/pages/public/login');
				}
				// #endif


			},

			getUser(e) {
				if (e.detail.errMsg == "getUserInfo:ok") {
					let userinfo = e.detail.userInfo;
					this.getWxXcxCoce(userinfo);
				}
			},

			getUserProfile(e) {
				let that = this
				if (!this.isClick) {
					return
				}
				this.isClick = false
				// 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
				// 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
				uni.getUserProfile({
					desc: '用于完善个人信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
					success: (res) => {
						that.isClick = true
						if (res.errMsg == "getUserProfile:ok") {
							let userinfo = res.userInfo;
							this.getWxXcxCoce(userinfo);
						}
					},
					complete() {
						that.isClick = true
					}
				})
			},

			//微信小程序根据用户信息获取code
			getWxXcxCoce(userinfo) {
				uni.showLoading({
					title: '正在请求...',
					mask: true
				});
				uni.login({
					success: code => {
						console.log(code, 'code')
						this.toLogin(code.code, JSON.stringify(userinfo));
					}
				});
			},

			//登录 code为用户的code【微信小程序或者微信h5】  userInfo为获取到的微信用户信息
			toLogin(code, userInfo = '') {
				this.wtCode = code
				uni.setStorageSync('fromurl', {
					url: '/pages/user/user'
				});
				let {
					client,
				} = this;
				let _this = this;
				let param = {};
				param.url = 'v3/member/front/login/wechat/login';
				param.data = {};
				param.data.source = client;
				param.data.code = code;

				//如果有缓存的购物车数据，登录需要把数据同步，并清除本地缓存
				let local_cart_list = uni.getStorageSync('cart_list')
				let cartInfo = []
				if (local_cart_list) {
					local_cart_list.cartInfoList.map(item => {
						if (item.isChecked == 1) {
							cartInfo.push({
								goodsId: item.goodsId,
								productId: item.productId,
								buyNum: item.buyNum,
								productPrice: item.productPrice,
								checked: 1
							})
						}
					})
					param.data.cartInfo = JSON.stringify(cartInfo);
				}
				if (userInfo) {
					param.data.userInfo = userInfo;
				}
				param.method = 'POST';
				this.$request(param).then(res => {
					if (res.state == 200) {
						uni.hideLoading();
						uni.removeStorage({
							key: 'cart_list'
						}); //清除购物车数据
						if (res.data.redirect == undefined) {
							uni.setStorage({
								key: 'userInfo',
								data: res.data,
								success() {
									//登录时间
									res.data.loginTime = Date.parse(new Date());
									_this.login(res.data);
									//登录成功 获取个人中心的数据
									_this.$request({
										url: 'v3/member/front/member/memberInfo',
									}).then(result => {
										_this.setUserCenterData(result.data);
										_this.$loginGoPage();
										_this.getSetting();
									}).catch((e) => {})
								}
							})
						} else if (res.data.redirect != undefined) {
							//用户未注册，需要绑定手机号进行注册
							this.showState = true
							//#ifdef H5
							let isWeiXinH5 = this.$isWeiXinBrower();
							if (isWeiXinH5 && this.$getQueryVariable('code')) {
								//如果是微信浏览器，而且浏览器地址里有code，需要把code再跳转下一页，防止返回的时候再去验证code
								history.replaceState({}, '', location.href.split('?')[0]);
							}
							//#endif
							// #ifndef MP-WEIXIN
							this.$Router.push({
								path: '/pages/public/bindMobile',
								query: {
									code: res.data.bindKey
								}
							})
							// #endif

							// #ifdef MP-WEIXIN
							this.bindKey = res.data.bindKey
							this.$refs.wt.open()
							// #endif


						}
					} else {
						uni.hideLoading();
						//错误提示
						_this.$api.msg(res.msg);
					}

				}).catch((e) => {
					uni.hideLoading();
				})
			},

			/**
			 * 统一跳转接口,拦截未登录路由
			 * navigator标签现在默认没有转场动画，所以用view
			 */
			navTo(url) {
				this.showState = true
				if (url == '') {
					this.$sldCommonTip()
					return
				}
				if (!this.hasLogin) {
					if (url == '/pages/user/info') {
						this.$Router.push('/pages/public/login')
					} else {
						this.$refs.loginPop.openLogin()
					}
				} else {
					if (url == "/standard/signIn/signIn") {
						this.signOpenCookie = false
					}
					this.$Router.push(url)
				}
			},

			/**
			 *  会员卡下拉和回弹
			 *  1.关闭bounce避免ios端下拉冲突
			 *  2.由于touchmove事件的缺陷（以前做小程序就遇到，比如20跳到40，h5反而好很多），下拉的时候会有掉帧的感觉
			 *    transition设置0.1秒延迟，让css来过渡这段空窗期
			 *  3.回弹效果可修改曲线值来调整效果，推荐一个好用的bezier生成工具 http://cubic-bezier.com/
			 */
			coverTouchstart(e) {
				if (pageAtTop === false) {
					return;
				}
				this.coverTransition = 'transform .1s linear';
				startY = e.touches[0].clientY;
			},
			coverTouchmove(e) {
				moveY = e.touches[0].clientY;
				let moveDistance = moveY - startY;
				if (moveDistance < 0) {
					this.moving = false;
					return;
				}
				this.moving = true;
				if (moveDistance >= 80 && moveDistance < 100) {
					moveDistance = 80;
				}

				if (moveDistance > 0 && moveDistance <= 80) {
					this.coverTransform = `translateY(${moveDistance}px)`;
				}
			},
			coverTouchend() {
				if (this.moving === false) {
					return;
				}
				this.moving = false;
				this.coverTransition = 'transform 0.3s cubic-bezier(.21,1.93,.53,.64)';
				this.coverTransform = 'translateY(0px)';
			},
			//去设置页面
			goSet() {

				if (!this.hasLogin) {
					this.$refs.loginPop.openLogin()
				} else {
					this.showState = true
					this.$Router.push('/pages/set/set')
				}

			},
			//去消息页面
			goMsg() {
				if (!this.hasLogin) {
					this.$refs.loginPop.openLogin()
				} else {
					this.showState = true
					this.$Router.push('/standard/chat/list')
				}
			},
			// 去我的积分页面
			toPointsPage() {
				if (!this.hasLogin) {
					this.$refs.loginPop.openLogin()
				} else {
					this.showState = true
					this.$Router.push('/pages/user/myIntegral')
				}
			},
			//去我的优惠券页面
			goMyCoupon() {
				if (!this.hasLogin) {
					this.$refs.loginPop.openLogin()
				} else {
					this.showState = true
					this.$Router.push('/pages/coupon/myCoupon')
				}
			},
			//去我的积分订单页面
			goMyPointOrder() {
				if (!this.hasLogin) {
					this.$refs.loginPop.openLogin()
				} else {
					this.showState = true
					this.$Router.push({
						path: '/standard/point/order/list',
						query: {
							state: 0
						}
					})
				}
			},
			//去我的视频页面
			goMyVideo() {
				if (!this.hasLogin) {
					this.$refs.loginPop.openLogin()
				} else {
					this.showState = true
					this.$Router.push('/extra/svideo/myVideo')
				}
			},

			/*
			 * 活动签到提醒
			 * 从签到信息接口获取是否提醒的字段(isRemind)
			 * isRemind为1，则开启提醒，设置cookie存入提醒字段，每天只显示一次
			 * 
			 */
			signOpenScreen() {
				this.$request({
					url: 'v3/promotion/front/sign/activity/detail'
				}).then(res => {
					if (res.state == 200) {
						this.signNotice = res.data.notice.imgPath
						this.isSignOpen = true
						let isRemind = res.data.isRemind
						let signCookie = uni.getStorageSync('signCookie')
						this.isSign = res.data.isSign == 2 ? true : false
						if (isRemind == 1) {

							if (!signCookie) {
								this.signOpenCookie = true
								uni.setStorage({
									key: 'signCookie',
									data: new Date().getTime()
								})
							} else {
								if (new Date().getTime() > new Date(new Date().toLocaleDateString()).getTime() &&
									new Date().getTime() > signCookie) {
									this.signOpenCookie = false
								} else {
									this.signOpenCookie = true
									uni.setStorage({
										key: 'signCookie',
										data: new Date().getTime()
									})
								}
							}


						} else {
							this.signOpenCookie = false
							uni.removeStorage({
								key: 'signCookie'
							})
						}
					} else {
						this.isSignOpen = false
					}
				})
			},
			toInfo() {
				if (this.hasLogin) {
					this.$Router.push('/pages/user/info')
				}
			},

			// #ifdef MP-WEIXIN
			getMobile(e) {
				if (e.detail.errMsg == 'getPhoneNumber:ok') {
					this.$refs.wt.close()
					uni.showLoading({})
					uni.login({
						success: code => {
							let {
								encryptedData,
								iv
							} = e.detail
							this.$request({
								url: 'v3/member/front/login/wechat/getMobile',
								method: 'POST',
								data: {
									code: code.code,
									encryptedData,
									iv
								}
							}).then(res => {
								if (res.state == 200) {
									this.userPhone = res.data.phoneNumber
									this.bindMobile(1)
								} else {
									this.$api.msg(res.msg)
								}
							})
						},
						complete(com) {
							console.log(com, 'ssss')
						}
					});
				} else {
					this.showState = true
					this.$Router.push({
						path: '/pages/public/bindMobile',
						query: {
							code: this.bindKey
						}
					})
				}
			},

			bindMobile(bindType) {

				let param = {};
				param.url = 'v3/member/front/login/wechat/bindMobile';
				param.data = {};
				param.data.bindType = bindType;
				param.data.mobile = this.userPhone;
				param.data.resource = 4;
				param.data.bindKey = this.bindKey;
				param.method = 'POST';

				let local_cart_list = uni.getStorageSync('cart_list')
				let cartInfo = []
				if (local_cart_list) {
					local_cart_list.cartInfoList.map(item => {
						if (item.isChecked == 1) {
							cartInfo.push({
								goodsId: item.goodsId,
								productId: item.productId,
								buyNum: item.buyNum,
								productPrice: item.productPrice,
								checked: 1
							})
						}
					})
					param.data.cartInfo = JSON.stringify(cartInfo);
				}


				this.$request(param).then(res => {
					uni.hideLoading()
					if (res.state == 200) {
						this.$refs.bind.close()
						uni.removeStorage({
							key: 'cart_data'
						}); //清除购物车数据
						res.data.loginTime = Date.parse(new Date()); //登录时间
						this.login(res.data);
						//获取个人中心的数据
						this.$request({
							url: 'v3/member/front/member/memberInfo',
						}).then(result => {
							this.setUserCenterData(result.data);
						})
						this.$api.msg(res.msg)
					} else if (res.state == 267) {
						//手机号已被绑定,提示用户
						this.$refs.bind.open()
						this.bindedAccount = res.data;
					} else {
						//错误提示
						this.$api.msg(res.msg);
					}
				})
			},
			getBindCancle() {
				this.$refs.wt.close()
				this.showState = true
				this.$Router.push({
					path: '/pages/public/bindMobile',
					query: {
						code: this.bindKey
					}
				})
			},
			// #endif

			//获取购物车数据
			getCartNum() {
				if (this.hasLogin) {
					let param = {};
					param.url = 'v3/business/front/cart/cartNum';
					param.method = 'GET';
					param.data = {};
					// param.data.key = this.userInfo.access_token;
					this.$request(param).then(res => {
						if (res.state == 200) {
							if (res.data > 0) {
								uni.setTabBarBadge({
									index: 3,
									text: res.data.toString()
								})
							} else {
								uni.hideTabBarRedDot({
									index: 3
								})
							}
						} else {
							this.$api.msg(res.msg);
						}
					}).catch((e) => {
						//异常处理
					})
				} else {
					this.getNoLoginCartNum();
				}
			},
			//获取未登录，购物车数量
			getNoLoginCartNum() {
				let cartNum = 0;
				let cart_list = uni.getStorageSync('cart_list');
				if (cart_list && cart_list.storeCartGroupList) {
					cart_list.storeCartGroupList.map(item => {
						item.promotionCartGroupList.map(item1 => {
							item1.cartList.map(item2 => {
								cartNum++;
							})
						})
					})
				}
				if (cartNum > 0) {
					uni.setTabBarBadge({
						index: 3,
						text: cartNum.toString()
					})
				} else {
					uni.hideTabBarRedDot({
						index: 3
					})
				}
			},
			//获取购物车数据
			getCartNum() {
				if (this.hasLogin) {
					let param = {};
					param.url = 'v3/business/front/cart/cartNum';
					param.method = 'GET';
					param.data = {};
					// param.data.key = this.userInfo.access_token;
					this.$request(param).then(res => {
						if (res.state == 200) {
							if (res.data > 0) {
								uni.setTabBarBadge({
									index: 3,
									text: res.data.toString()
								})
							} else {
								uni.hideTabBarRedDot({
									index: 3
								})
							}
						} else {
							this.$api.msg(res.msg);
						}
					}).catch((e) => {
						//异常处理
					})
				} else {
					this.getNoLoginCartNum();
				}
			},
		}
	}
</script>
<style lang='scss' scoped>
	page {
		background: $bg-color-split;
		width: 750rpx;
		margin: 0 auto;
		position: relative;
	}

	.container {
		height: 100%;
		position: relative;
	}

	.picture_adv_poster_con image {
		width: 100%;
		height: 180rpx;
		display: block;
		cursor: pointer;
	}

	.picture_adv_poster_con {
		&:nth-child(2) {
			margin-top: 20rpx;
			margin-bottom: 20rpx;
		}

		margin-top: 13rpx;
		margin-bottom: 16rpx;
	}

	.picture_adv_poster_con .video_poster {
		width: 100%;
		height: 100%;
	}

	%flex-center {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	%section {
		display: flex;
		justify-content: space-around;
		align-content: center;
		background: #fff;
		border-radius: 10upx;
	}


	.sld-success-title {
		line-height: 42rpx;
		font-size: 32rpx;
		color: #666666;
		padding: 40rpx 30rpx;
		text-align: center;
	}

	.sld-success {
		background-color: #fff;
		color: #666666;
		font-size: 28rpx;
		width: 500rpx;
		border-radius: 20rpx;
		padding: 30rpx;

		.sld-success-content {
			line-height: 45rpx;
			margin-bottom: 30rpx;
			padding: 0 35rpx;
			color: #999;
			font-size: 26rpx;
		}

		.sld-btns {
			display: flex;
			align-items: center;
			justify-content: space-between;
			margin-top: 20rpx;
			width: 100%;

			button {
				width: 200rpx;
				height: 50rpx;
				border-radius: 40rpx;
				font-size: 28rpx;
				line-height: 50rpx;
				outline: none;
				background-color: #fff;
				color: #999;
				border: 1px solid #999999;
				margin: 0;

				&.confirm {
					color: #fff;
					background: linear-gradient(135deg, #FB3E31 0%, #FED600 0%, #FF4E00 0%, #FF001D 100%);
					;
					border: none;
				}

				&::after {
					border: none;
				}
			}
		}
	}



	.check-in {
		position: absolute;
		/* #ifdef APP-PLUS */
		top: calc(var(--status-bar-height) + 160rpx);
		/* #endif */
		/* #ifndef APP-PLUS */
		top: 160rpx;
		/* #endif */
		right: 0;
		width: 140rpx;
		height: 48rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		border-radius: 24rpx 0 0 24rpx;
		color: #fff;
		font-size: 24rpx;
		background: rgba(250, 250, 250, 0.2);
		z-index: 999;
	}

	.check-in image {
		width: 21rpx;
		height: 23rpx;
		margin-right: 5rpx;
	}

	/* 开屏 -- start */
	.open_screen {
		width: 750rpx;
		height: 100vh;
		position: absolute;
		top: 0;
		left: 0;
		background-color: rgba(0, 0, 0, 0.3);
		z-index: 99999;
	}

	.open_screen .open_screen_con {
		maring: 0 auto;
		position: absolute;
		top: 50%;
		left: 50%;
		transform: translate(-50%, -50%);
		border-radius: 15rpx;
		display: flex;
		align-items: center;
		flex-direction: column;
	}

	.open_screen .open_screen_con .open_screen_con_img {
		background-size: contain;
		border-radius: 15rpx;
	}

	.open_screen .open_screen_con .con_img {
		width: 58rpx;
		height: 58rpx;
		position: relative;
		top: 0;
		right: 0;
		z-index: 999;
		align-self: flex-end;
	}

	.open_screen_con .con_img image {
		width: 100%;
		height: 100%;
	}

	/* 开屏 -- end */




	/* 会员信息上滑 start */
	.member_info_sliding {
		width: 750rpx;
		height: 94rpx;
		background: linear-gradient(135deg, #FB3E31 0%, #FED600 0%, #FF4E00 0%, #FF001D 100%);
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0 30rpx 0 20rpx;
		box-sizing: border-box;
		position: fixed;
		top: 0;
		/* #ifdef APP-PLUS */
		top: var(--status-bar-height);
		/* #endif */
		left: 0;
		right: 0;
		margin: 0 auto;
		z-index: 10;

		.member_info_sliding_left {
			width: 78rpx;
			height: 78rpx;
			border: 4rpx solid rgba(255, 255, 255, .5);
			border-radius: 50%;

			image {
				width: 100%;
				height: 100%;
				border-radius: 50%;
				border: 4rpx solid #FFFFFF;
			}
		}

		.member_info_sliding_center {
			font-size: 36rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #FFFFFF;
			line-height: 32rpx;
		}

		.member_info_sliding_right {
			display: flex;
			align-items: center;

			.user_sets {
				width: 42rpx;
				height: 42rpx;
				margin-right: 30rpx;

				image {
					width: 40rpx;
					height: 40rpx;
				}
			}

			.user_msg {
				position: relative;
				display: flex;
				align-items: center;

				.user_msg_img {
					width: 40rpx;
					height: 40rpx;
				}

				text {
					position: absolute;
					top: -10rpx;
					right: -10rpx;
					width: 30rpx;
					height: 30rpx;
					background: #FFFFFF;
					border-radius: 50%;
					font-size: 20rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #FF152C;
					line-height: 30rpx;
					text-align: center;
				}
			}
		}
	}

	/* 会员信息上滑 end */

	.user-section {
		/* height: calc(418rpx + env(safe-area-inset-top));
		height: calc(418rpx + constant(safe-area-inset-top)); */
		height: 418rpx;
		position: relative;
		padding: 40rpx 30rpx 0;
		/* #ifdef APP-PLUS */
		padding: 90rpx 30rpx 0;
		padding-top: calc(30rpx + var(--status-bar-height));

		/* #endif */
		.bg {
			position: absolute;
			left: 0;
			top: 0;
			width: 100%;
			height: 382rpx;
			/* #ifdef APP-PLUS */
			height: calc(382rpx + var(--status-bar-height));
			/* #endif */
		}
	}

	.user_set {
		display: flex;
		justify-content: flex-end;

		.user_set_img {
			width: 50rpx;
			height: 50rpx;
			margin-right: 31rpx;
		}

		.user_msg {
			position: relative;

			.user_msg_img {
				width: 50rpx;
				height: 50rpx;
			}

			text {
				min-width: 34rpx;
				height: 34rpx;
				background: #FFFFFF;
				border-radius: 50rpx;
				font-size: 20rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FF152C;
				line-height: 30rpx;
				text-align: center;
				position: absolute;
				top: -8rpx;
				left: 50%;
				transform: translateX(-10%);
			}
		}
	}



	.user-info-box {
		height: 134rpx;
		display: flex;
		align-items: center;
		position: relative;
		z-index: 1;
		/* #ifdef H5 */
		margin-top: 25rpx;

		/* #endif */
		.portrait-box {
			width: 128rpx;
			height: 128rpx;
			border-radius: 50%;
			border: 8rpx solid rgba(255, 255, 255, .5);
			box-sizing: border-box;
			overflow: hidden;
			display: flex;
			align-items: center;
			justify-content: center;

			.portrait-bgc {
				width: 124rpx;
				height: 124rpx;
				box-sizing: border-box;
				border-radius: 50%;
				overflow: hidden;
				background-color: #ffffff;
				display: flex;
				align-items: center;
				justify-content: center;

				.portrait {
					width: 100rpx;
					height: 100rpx;
					border-radius: 50%;
				}
			}

		}

		.mem-info {
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: flex-start;
			margin-left: 20rpx;

			.nick-name {
				color: #fff;
				font-size: 40rpx;
				line-height: 44rpx;
				font-weight: bold;
				max-width: 450rpx;
				overflow: hidden;
				text-overflow: ellipsis;
				display: -webkit-box;
				-webkit-line-clamp: 1; //文字上限行
				-webkit-box-orient: vertical;

			}

			.member-name {
				color: #fff;
				font-size: 20rpx;
				border-radius: 13rpx;
				margin-top: 13rpx;
				height: 28rpx;
				display: flex;
				justify-content: center;
				align-items: center;
			}

			.login_btn {
				background: transparent;
				line-height: 44rpx;
				height: 44rpx;
				padding-left: 0;

				&::after {
					border: none;
				}

				text-align: left;
			}

		}

	}

	/* 我的记录 start */
	.mine_record {
		width: 710rpx;
		background: #FFFFFF;
		border-radius: 10rpx;
		display: flex;
		justify-content: space-around;
		padding: 35rpx 20rpx 41rpx;
		box-sizing: border-box;
		margin: -127rpx auto 20rpx;
		/* #ifdef APP-PLUS */
		margin-top: calc(-107rpx + env(safe-area-inset-top));
		/* #endif */
		position: relative;

		.mine_record_pre {
			display: flex;
			flex-direction: column;
			align-items: center;

			image {
				width: 45rpx;
				height: 45rpx;
				margin-bottom: 30rpx;
			}

			text {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #666666;
				line-height: 26rpx;
			}
		}
	}

	/* 我的记录 end */

	.main-content {
		width: 750rpx;
		padding: 0 $com-v-border;
		position: relative;

		.order-part {
			width: 100%;
			height: 277rpx;
			background: #fff;
			box-shadow: 0px 0px 20px 0px rgba(153, 153, 153, 0.15);
			border-radius: 15rpx;

			.title {
				width: 100%;
				height: 90rpx;
				border-bottom: 1px solid #F8F8F8;
				padding-right: 30rpx;
				box-sizing: border-box;

				.left {
					flex-shrink: 0;
					padding-left: 29rpx;
					color: #2D2D2D;
					font-size: 34rpx;
					line-height: 36rpx;
					font-weight: bold;
				}

				.right {
					text {
						flex-shrink: 0;
						color: #666;
						font-size: 28rpx;
						font-weight: 400;
						margin-right: 20rpx;
					}

					image {
						width: 11rpx;
						height: 19rpx;
					}
				}
			}

			.detail {
				flex: 1;
				width: 100%;

				.item {
					position: relative;

					.show-text {
						color: #333333;
						font-size: 28rpx;
						line-height: 28rpx;
						margin-top: 20rpx;
					}

					.nums {
						position: absolute;
						top: -5rpx;
						right: -5rpx;
						background: #FFFFFF;
						border: 1rpx solid #FF0000;
						border-radius: 11rpx;
						padding: 0rpx 5rpx;
						box-sizing: border-box;
						font-size: 20rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FF1D2E;
						text-align: center;
						height: 25rpx;
						line-height: 25rpx;
						display: flex;
						align-items: center;
						justify-content: center;
					}

					.num {
						position: absolute;
						top: -5rpx;
						right: -5rpx;
						width: 25rpx;
						height: 25rpx;
						background: #FFFFFF;
						border: 1rpx solid #FF0000;
						border-radius: 50%;
						font-size: 20rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FF1D2E;
						line-height: 25rpx;
						text-align: center;
						display: flex;
						align-items: center;
						justify-content: center;
					}

					image {
						width: 67rpx;
						height: 58rpx;
					}
				}
			}
		}

		/* 常用服务 start */
		.common_services {
			width: 710rpx;
			min-height: 485rpx;
			background: #FFFFFF;
			border-radius: 15rpx;
			margin: 20rpx auto 0;

			.common_services_title {
				width: 100%;
				height: 92rpx;
				border-bottom: 1rpx solid #F8F8F8;
				font-size: 34rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #2D2D2D;
				line-height: 92rpx;
				padding-left: 30rpx;
			}

			.common_services_list {
				display: flex;
				flex-direction: column;

				.common_services_pre {
					height: 130rpx;
					display: flex;
					justify-content: space-between;
					align-items: center;
					margin: 0 30rpx;
					border-bottom: 1rpx solid #F8F8F8;

					&:nth-last-child(1) {
						border-bottom: none;
					}



					.common_serv_pre_left {
						display: flex;
						align-items: center;

						image {
							width: 51rpx;
							height: 51rpx;
						}

						text {
							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #2D2D2D;
							line-height: 39rpx;
							margin-left: 25rpx;
						}
					}

					.common_serv_pre_right {
						display: flex;
						align-items: center;

						text {
							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: bold;
							color: #333333;
							line-height: 39rpx;
							margin-right: 20rpx;
						}

						image {
							width: 11rpx;
							height: 19rpx;
						}
					}
				}
			}
		}

		/* 常用服务 end */

		.recommend-title {
			display: flex;
			justify-content: center;

			image {
				width: 387rpx;
				height: 34rpx;
				margin: 30rpx 0;
			}
		}

		.recommend-goods {
			flex-wrap: wrap;
		}
	}

	.fixed_top_status_bar {
		position: fixed;
		/* #ifdef APP-PLUS */
		height: var(--status-bar-height);
		/* #endif */
		/* #ifndef APP-PLUS */
		height: 0;
		/* #endif */
		top: 0;
		left: 0;
		right: 0;
		z-index: 99;
		background: #fff;
	}

	/* 绑定结果页 */

	.wrapper {
		background: #fff;
		padding: 30rpx;
		border-radius: 20rpx;
	}




	.bind_state_top {

		display: flex;
		flex-direction: column;
		align-items: center;

		.mobile_logo {
			width: 120rpx;
			height: 120rpx;
		}

		.mobile_num {
			font-size: 30rpx;
			font-weight: 500;
			color: #FC2624;
			margin-top: 39rpx;
		}

		.mobile_binded {
			font-size: 30rpx;
			font-weight: 500;
			color: #333333;
			margin-top: 19rpx;
		}

	}

	.bind_change_info {
		font-size: 24rpx;
		text-align: center;
		color: #666666;
		line-height: 39rpx;
		margin-top: 31rpx;

		.change_info_mobile {
			color: #333333;
		}
	}

	.bind_state_btn_con {
		width: 520rpx;
		height: 70rpx;
		margin: 0 auto;
		margin-top: 40rpx;
		font-size: 30rpx;
		display: flex;
		justify-content: center;

		.update_btn {
			width: 208rpx;
			height: 69rpx;
			line-height: 69rpx;
			color: #ff0000;
			text-align: center;
			border-radius: 35rpx 0 0 35rpx;
			border: 1px solid #ff0000;
		}

		.go_on_btn {
			width: 208rpx;
			height: 69rpx;
			line-height: 69rpx;
			text-align: center;
			background-color: #ff0000;
			color: white;
			border-radius: 0 35rpx 35rpx 0;
			border: 1px solid #ff0000;
		}
	}
</style>
