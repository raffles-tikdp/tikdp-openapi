<template>
	<web-view :src="skip_url"></web-view>
</template>

<script>
	export default{
		data(){
			return {
				skip_url:''
			}
		},
		onLoad(){
			
			this.skip_url = this.$Route.query.url
		}
	}
</script>

<style>
</style>
