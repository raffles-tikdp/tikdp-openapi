<template>
	<view class="container">
		<!-- #ifdef H5-->
		<home-deco :deco_info="deco_data" :topicNotExit='topicNotExit' :is_show_top="false" :topic_name="topic_name" :is_from_found="false"></home-deco>
		<!-- #endif -->
		<!-- #ifdef MP||APP-PLUS -->
		<home-deco :deco_info="deco_data" :topicNotExit='topicNotExit' :is_show_top="false" :topic_name="topic_name" :is_from_found="true"></home-deco>
		<!-- #endif -->
	</view>
</template>

<script>
	import HomeDeco from '@/components/home_deco.vue'
	export default {
		data() {
			return {
				deco_data:[],
				topic_id:'', //专题id
				topic_name:'', //专题名称
				client:'', //客户端类型
				topicNotExit:false
			};
		},
		components: {
			HomeDeco
		},
		onLoad(option) {
			this.topic_id = this.$Route.query.id
			this.loadData(this.topic_id);
		},
		onShow() {
			
		},
		methods: {
			/**
			 * 请求静态数据只是为了代码不那么乱
			 * 分次请求未作整合
			 */
			async loadData(id) {
				uni.showLoading({
					title:'加载中...'
				})
				let param = {}
				param.url = 'v3/system/front/deco/special?decoId='+id+'&type=topic'
				param.method = 'GET'
				this.$request(param).then(res => {
					if (res.state == 200) {
						uni.hideLoading()
						if(res.data==null){
							this.topicNotExit=true
							this.deco_data = []
							return
						}
						if(res.data.data != ''){
							this.deco_data = JSON.parse(res.data.data)
						}else{
							this.deco_data = []
						}
						this.topic_name = res.data.name
						uni.setNavigationBarTitle({
							title:this.topic_name
						})
						uni.hideLoading()
					}
				})
			}
		}
	}
</script>

<style lang="scss">

</style>
