<template>
	<view :style="privacyPolicyModel?'overflow: hidden':'overflow: unset'">
		<view class="fixed_top_status_bar"></view>
		<!-- #ifdef APP-PLUS -->
		<!-- <view class="privacy_policy_model" v-if="privacyPolicyModel" @touchmove.stop.prevent="moveHandle">
			<view class="privacy_model" @touchmove.stop.prevent="moveHandle" @touchstart.stop="()=>{}" >
				<view class="privacy_model_title">{{$L('用户隐私政策')}}</view>
				<scroll-view class="privacy_policy" scroll-y @touchmove.stop.prevent="moveHandle">
					<rich-text :nodes="privacyPolicyHtml"></rich-text>
				</scroll-view>
				<view class="privacy_model_confirm" @click="confirmPrivacy">{{$L('同意，继续使用')}}</view>
				<view class="privacy_model_cancel" @click="cancelPrivacy">{{$L('不同意，退出APP')}}>></view>
			</view>
		</view> -->
		<!-- #endif -->
		<home-deco :deco_info="deco_data" :width='width' :height='height' :home_page_img='home_page_img' :is_show_top="true" 
			:home_is_show_top_cat="home_is_show_top_cat" :is_from_found="false" type="home" 
			:overflow="privacyPolicyModel" @cartUpdate="getCartNum" ref="homeDeco" @needLogin="needLogin"></home-deco>
		<!-- 登录弹框 -->
		<loginPop ref="loginPop" @confirmLogin="confirmLogin"></loginPop>
		<!-- 登录弹框 -->
	</view>
</template>

<script>
	import HomeDeco from '@/components/home_deco.vue';
	import { checkUpdate } from "@/utils/app-update-check.js";
	import {
		mapState,
		mapMutations
	} from 'vuex';
	export default {
		data() {
			return {
				deco_data:[] ,//首页装修数据
				home_is_show_top_cat:true ,//是否显示顶部分类，默认显示
				home_page_img:[],
				width:'',
				height:'',
				shareData:{},
				privacyPolicyHtml:'', //隐私政策协议的富文本
				privacyPolicyModel:false,
			};
		},
		components:{
			HomeDeco
		},
		computed:{
			...mapState(['hasLogin', 'userInfo', 'userCenterData'])
		},
		onLoad() {
			// #ifdef APP-PLUS
			this.getAppInfo(0); //获取线上APP版本信息  参数type 0自动检查  1手动检查（手动检查时，之前取消更新的版本也会提示出来）
			// #endif
			
			this.loadData();
			// this.privacyPolicyHtml = privacyPolicy.user_privacy_policy_content;
			// let privacyPolicyHtml = uni.getStorageSync('privacyPolicy');
			// if(!privacyPolicyHtml){
			// 	this.privacyPolicyModel = true;
			// }
			// #ifdef MP-WEIXIN
			let url = getApp().globalData.apiUrl.substring(0,getApp().globalData.apiUrl.length-1);
			this.$sldStatEvent({behaviorType:'pv',pageUrl:url+'/pages/index/index',referrerPageUrl:''});
			// #endif
		},
		/**
		 * 用户点击右上角分享
		 */
		onShareAppMessage: function () {
		  const {
		    shareData
		  } = this;
		  return shareData;
		},
		
		onShareTimeline: function () {
		  const {
		    shareData
		  } = this;
		  return shareData;
		},
		onShow(){
			// let privacyPolicyHtml = uni.getStorageSync('privacyPolicy');
			// if(!privacyPolicyHtml){
			// 	this.privacyPolicyModel = true;
			// }
			if(this.userInfo.access_token){
				this.$request({
					url: '/v3/helpdesk/front/chat/unReadMsgNum',
				}).then(res => {
					if (res.state == 200) {
						this.userCenterData.msgNum = res.data
						this.setUserCenterData(this.userCenterData);
					}
				})
			}
			this.getCartNum();
		},
		
		methods: {
			...mapMutations(['login', 'setUserCenterData']),
			
			// #ifdef APP-PLUS
			//获取线上APP版本信息
			getAppInfo(type) {
				const platform = uni.getSystemInfoSync().platform;  //本机设备操作系统  android / ios
			
				//请求获取最新版本
				//这里自行请求API获取版本信息 建议传入操作系统标识，返回本机对应的操作系统最新版本信息，也就是安卓的返回就是安卓的版本信息  ios返回就是ios的版本信息
				let param = {};
				param.url = 'v3/system/front/setting/getSettings';
				param.method = 'GET';
				param.data = {};
				if (platform == 'android') { //android
					param.data.names = 'app_android_hot_edition,' //热更新版本号
					+ 'app_android_hot_link,' //热更新地址
					+ 'app_android_hot_tip,' //更新提示内容
					+ 'app_android_package_edition,' //整包升级版本号
					+ 'app_android_package_link' //整包升级地址
				} else if(platform == 'ios') { //ios
					param.data.names = 'app_ios_hot_edition,' //热更新版本号
					+ 'app_ios_hot_link,' //热更新地址
					+ 'app_ios_hot_tip,' //更新提示内容
					+ 'app_ios_package_edition,' //整包升级版本号
					+ 'app_ios_package_link' //整包升级地址
				}else{
					return false;
				}
				
				this.$request(param).then(res => {
					if (res.state == 200) {
						let update_info = {
							version: res.data[3], //整包版本
							versionCode: res.data[0], //热更新版本号
							now_url: "", //更新链接
							version_url: res.data[4], //整包下载地址
							versionCode_url: res.data[1], //热更新下载地址
							silent: 0, //是否是静默更新
							force: 1, //是否是强制更新
							net_check: 1, //非WIfi是否提示
							note: res.data[2], //更新内容
						}
						checkUpdate(update_info, type).then(res => {
							if (res.data) {
								plus.nativeUI.toast(res.data.msg);
							}
						}); ///检查更新 线上版本号与本地版本号做对比,如果需要更新 根据静默、强制、wifi等信息执行静默更新或跳转到升级页面 
					}
				})
			},
			// #endif
			
			needLogin(){
				this.$refs.loginPop.openLogin()
			},
			confirmLogin(){
				this.$refs.loginPop.close()
			},
			
			async loadData() {
				uni.showLoading({
					title:'加载中...'
				})
				// #ifdef H5
				this.client = 'h5'
				// #endif
				
				// #ifdef APP-PLUS
				switch(uni.getSystemInfoSync().platform){
					case 'android':
					   this.client = 'android'
					   break;
					case 'ios':
					   this.client = 'ios'
					   break;
					default:
					   break;
				}
				// #endif
				
				// #ifdef MP
				this.client = 'weixinXcx'
				// #endif
				let param = {}
				param.url = 'v3/system/front/deco/index?os='+this.client
				param.method = 'GET'
				this.$request(param).then(res => {
					if (res.state == 200) {
						if(JSON.stringify(res.data) == "{}"){
							this.deco_data = null;
							uni.hideLoading();
							return
						}
						if(res.data.data != ''){
							this.deco_data = JSON.parse(res.data.data)
						}else{
							this.deco_data = null
						}
						
						
						// #ifdef MP
						  this.shareData={
						    title: res.data.siteName,
						    path: '/pages/index/index',
						    imageUrl: res.data.xcxImage
						  }
						  // #endif
						if(res.data.showTip != null){
							this.home_page_img = JSON.parse(res.data.showTip)
							const {windowWidth,windowHeight} = uni.getSystemInfoSync();
							this.width = this.home_page_img[0].width || windowWidth*0.75 * 1.8;
							this.height = this.home_page_img[0].height || windowHeight*0.56 * 1.8;
						}else{
							this.home_page_img = []
						}
						
						if(this.deco_data && this.deco_data.length != undefined && this.deco_data.length>0){
							this.home_is_show_top_cat = this.deco_data[0].type == 'top_cat_nav'?true:false;
						}
						uni.hideLoading()
					}
				})
			},
			//阻止模态框下页面滚动
			moveHandle(){},
			//同意，继续使用
			// confirmPrivacy(){
			// 	this.privacyPolicyModel = false;
			// 	uni.setStorageSync('privacyPolicy',this.privacyPolicyHtml);
			// },
			//不同意，退出app
			// cancelPrivacy(){
			// 	this.privacyPolicyModel = false;
			// 	uni.clearStorageSync('privacyPolicy');
			// 	//退出app
			// 	// #ifdef APP-PLUS
			// 	 if (plus.os.name.toLowerCase() === 'android') {
			// 		 plus.runtime.quit();
			// 	 }
			// 	 else{ 
			// 		 const threadClass = plus.ios.importClass("NSThread");
			// 		 const mainThread = plus.ios.invoke(threadClass, "mainThread");
			// 		 plus.ios.invoke(mainThread, "exit");
			// 		 plus.ios.import("UIApplication").sharedApplication().performSelector("exit")
			// 	 }
			// 	// #endif
			// },
			//获取购物车数据
			getCartNum() {
				if (this.hasLogin) {
					let param = {};
					param.url = 'v3/business/front/cart/cartNum';
					param.method = 'GET';
					param.data = {};
					// param.data.key = this.userInfo.access_token;
					this.$request(param).then(res => {
						if (res.state == 200) {
							if(res.data>0){
								uni.setTabBarBadge({
									index: 3,
									text: res.data.toString()
								})
							}else{
								uni.hideTabBarRedDot({
									index: 3
								})
							}
						} else {
							this.$api.msg(res.msg);
						}
					}).catch((e) => {
						//异常处理
					})
				} else {
					this.getNoLoginCartNum();
				}
			},
			//获取未登录，购物车数量
			getNoLoginCartNum() {
				let cartNum = 0;
				let cart_list = uni.getStorageSync('cart_list');
				if (cart_list && cart_list.storeCartGroupList) {
					cart_list.storeCartGroupList.map(item => {
						item.promotionCartGroupList.map(item1 => {
							item1.cartList.map(item2 => {
								cartNum++;
							})
						})
					})
				}
				if(cartNum>0){
					uni.setTabBarBadge({
						index: 3,
						text: cartNum.toString()
					})
				}else{
					uni.hideTabBarRedDot({
						index: 3
					})
				}
			},
		},
	}
</script>

<style lang="scss">
.fixed_top_status_bar {
		position: fixed;
		/* #ifdef APP-PLUS */
		height: var(--status-bar-height);
		/* #endif */
		/* #ifndef APP-PLUS */
		height: 0;
		/* #endif */
		top: 0;
		left: 0;
		right: 0;
		z-index: 99;
		background: #fff;
	}
page{
	background: #F5F5F5;
}
.privacy_policy_model{
	width: 750rpx;
	height:100vh;
	background: rgba(0,0,0,0.7);
	position: fixed;
	top: 0;
	left: 0;
	z-index: 9999999;
	overflow: hidden;
	.privacy_model{
		width: 625rpx;
		height:70vh;
		background: #FFFFFF;
		border-radius: 15rpx;
		margin: 0 auto;
		margin-top: 17vh;
		padding-bottom: 24rpx;
		box-sizing: border-box;
		display: flex;
		flex-direction: column;
		justify-content: space-between;
		.privacy_model_title{
			height: 104rpx;
			font-size: 34rpx;
			font-family: Source Han Sans CN;
			font-weight: bold;
			color: #000000;
			line-height: 104rpx;
			text-align: center;
			border-bottom: 1rpx solid #F2F2F2;
		}
		.privacy_policy{
			width: 625rpx;
			height: 50vh;
			padding:0 43rpx;
			box-sizing: border-box;
		}
		.privacy_model_confirm{
			width: 542rpx;
			height: 72rpx;
			background: linear-gradient(90deg, #FC1C1C 0%, #FF7918 100%);
			border-radius: 36rpx;
			font-size: 28rpx;
			font-family: Source Han Sans CN;
			font-weight: 400;
			color: #FFFFFF;
			line-height: 72rpx;
			text-align: center;
			margin: 20rpx auto;
		}
		.privacy_model_cancel{
			font-size: 28rpx;
			font-family: Source Han Sans CN;
			font-weight: 400;
			color: #FF991E;
			text-align: center;
			line-height: 28rpx;
		}
	}
}
</style>
