<template>
	<view class="container">
		<!-- #ifndef MP -->
		<text class="back-btn iconfont iconziyuan2" @click="navBack"></text>
		<!-- #endif -->

		<!-- 设置白色背景防止软键盘把下部绝对定位元素顶上来盖住输入框等 -->
		<view class="wrapper">
			<view class="login-title">
				{{$L('密码登陆')}}
			</view>
			<view class="input-content">
				<view class="input-item">
					<input type="text" :value="mobile" placeholder="请输入账号/手机号" maxlength="20" data-key="mobile"
						@input="inputChange" @focus="setFocus" @blur="handleAcc" placeholder-class="placeStyle" />
					<text class="clear-account iconfont iconziyuan34" v-show="mobile&&curFocus=='mobile'"
						@click="clearContent('mobile')"></text>
				</view>
				<view class="input-item pwd_wrap">
					<input type="text" style="width: 56%;" :value="password" :placeholder="$L('请输入密码')" maxlength="20"
						:password="!showPwd" data-key="password" @input="inputChange" @confirm="toLogin"
						@focus="setFocus" placeholder-class="placeStyle" />
					<view class="pwd-right">
						<text class="clear-pwd iconfont iconziyuan34" v-show="password&&curFocus=='password'"
							@click="clearContent('password')"></text>
						<text :class="{'pwd-tab': true,iconfont: true,iconziyuan81: showPwd,iconziyuan9: !showPwd}"
							@click.stop="changePwdState"></text>
						<text class="forget-pwd" @click.stop="navTo('/pages/public/forgetPwd',2)">忘记密码</text>
					</view>

				</view>
			</view>
			<button class="confirm-btn" @click="toLogin"
				:style="{opacity: (!(mobile&&password)||logining)?0.5:1}">登录</button>
			<view class="login-register">
				<text class="mobile-login" @click="navTo('/pages/public/loginMobile',1)">验证码登录</text>
				<text class="register" @click="navTo('/pages/public/register',1)">用户注册</text>
			</view>
		</view>
		<view class="other-login">
			<!-- #ifdef H5 -->
			<view class="title" v-if="isWeiXinH5">
				<text>其他登录</text>
			</view>
			<!-- #endif -->

			<!-- #ifndef H5 -->
			<view class="title" v-if="isWxEnable==1">
				<text>其他登录</text>
			</view>
			<!-- #endif -->

			<view class="login-method">
				<!-- #ifdef MP-WEIXIN -->
				<button class="wechat-login" v-if="canIUseGetUserProfile" @tap="getUserProfile">
					<image class="wechat-icon" :src="imgUrl+'wechat.png'" mode="aspectFill" />
					<text>{{$L('微信登录')}}</text>
				</button>

				<button class="wechat-login" v-if="!canIUseGetUserProfile" open-type="getUserInfo"
					@getuserinfo="getUser">
					<image class="wechat-icon" :src="imgUrl+'wechat.png'" mode="aspectFill" />
					<text>{{$L('微信登录')}}</text>
				</button>
				<!-- #endif -->
				<!-- #ifdef H5-->
				<view class="wechat-login" @tap="quickLogin" v-if="isWeiXinH5">
					<image class="wechat-icon" :src="imgUrl+'wechat.png'" mode="aspectFill" />
					<text>微信登录</text>
				</view>
				<!-- #endif -->
				<!-- #ifdef APP-PLUS -->
				<view class="wechat-login" @tap="quickLogin" v-if="isWxEnable==1">
					<image class="wechat-icon" :src="imgUrl+'wechat.png'" mode="aspectFill" />
					<text>微信登录</text>
				</view>
				<!-- #endif -->
			</view>
		</view>
		<!-- #ifndef APP-PLUS -->
		<view class="agreement-part">
			{{$L('登录即代表您已同意')}}
			<text class="agreement" @click="agreement('register_agreement')">{{$L('《用户协议》')}}</text>
			{{$L('和')}}
			<text class="agreement" @click="agreement('privacy_policy')">{{$L('《隐私协议》')}}</text>
		</view>
		<!-- #endif -->
		<!-- #ifdef APP-PLUS -->
		<view class="agreement-part flex_row_center_center">
			<image @click="checkAgrement" class="register_icon" :src="show_check_icon" mode="aspectFill" />
			{{$L('我已阅读并同意')}}
			<text class="agreement" @click="agreement('register_agreement')">{{$L('《用户协议》')}}</text>
			{{$L('和')}}
			<text class="agreement" @click="agreement('privacy_policy')">{{$L('《隐私协议》')}}</text>
		</view>
		<!-- #endif -->

		<!-- #ifdef MP-WEIXIN -->
		<uni-popup ref="wt" type="center" :mask-click="false">
			<view class="sld-success flex_column_center_center">
				<view class="sld-success-title">是否允许获取该微信绑定的手机号？</view>
				<view class="sld-btns">
					<button @click="getBindCancle">取消</button>
					<button open-type="getPhoneNumber" @getphonenumber="getMobile" class="confirm">确定</button>
				</view>
			</view>
		</uni-popup>

		<uni-popup ref="bind" type="center" :mask-click="false">
			<view class="wrapper">
				<view class="bind_state_top">

					<text class="mobile_num">{{userPhone}}</text>
					<text class="mobile_binded">{{$L('该手机号已被绑定')}}</text>
				</view>
				<view class="bind_change_info">
					<view class="bind_change_info_text">{{$L('继续绑定：将解除与账号')}}<text
							class="change_info_mobile">{{bindedAccount}}</text>{{$L('的绑定关系')}}</view>
					<view class="bind_change_info_text">{{$L('更新信息：授权信息将绑定到账号')}}<text
							class="change_info_mobile">{{bindedAccount}}</text>{{$L('上')}}</view>
				</view>
				<view class="bind_state_btn_con">
					<view class="update_btn" @click="bindMobile(3)">{{$L('更新信息')}}</view>
					<view class="go_on_btn" @click="bindMobile(2)">{{$L('继续绑定')}}</view>
				</view>
			</view>
		</uni-popup>
		<!-- #endif -->




	</view>
</template>

<script>
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	import {
		mapMutations,
		mapState
	} from 'vuex';

	export default {
		data() {
			return {
				imgUrl: getApp().globalData.imgUrl,
				mobile: '',
				password: '',
				logining: false,
				showPwd: false,
				curFocus: '', //当前光标所在的位置
				client: 1, //终端类型， 1、H5(微信内部浏览器) 2、H5(微信小程序)；3、app
				oriUrl: '', //不带code的页面地址
				isWeiXinH5: true, //是否为微信浏览器h5
				check_agreement: false,
				show_check_icon: getApp().globalData.imgUrl + 'register_uncheck.png',
				canIUseGetUserProfile: false, //是否可以使用getUserProfile获取用户信息，用于微信小程序
				isWxEnable: 0,
				isClick: true,
				wtCode: '',
				userPhone: '',
				bindedAccount: '',
				bindKey: '',
				scanCode: false, //是否从app扫码授权登录跳转
			}
		},
		components: {
			uniPopup
		},
		onLoad(option) {
			this.client = this.$getLoginClient();
			//#ifdef MP-WEIXIN
			if (uni.getUserProfile) {
				this.canIUseGetUserProfile = true;
			}
			//#endif
			//#ifdef H5
			let code = this.$getQueryVariable('code');
			this.isWeiXinH5 = this.$isWeiXinBrower();
			if (code) {
				let oriUrl = this.$Route.query.ori_url;
				let tmp_data = '';
				for (let i in this.$Route.query) {
					if (i != 'ori_url') {
						tmp_data += i + '=' + this.$Route.query[i] + '&'
					}
				}
				oriUrl += '?' + tmp_data;
				this.oriUrl = oriUrl;

				if (this.$isWeiXinBrower()) {
					//微信浏览器的话要把浏览器地址里面的code去掉
					history.replaceState({}, '', this.oriUrl);
				}

				let tar_params = {};
				tar_params.source = this.client;
				tar_params.code = code;
				this.goLogin(tar_params);
			}
			//#endif
			// #ifdef APP-PLUS
			this.scanCode = this.$Route.query.scanCode ? true : false;
			this.getWxAuthority()
			// #endif
		},

		computed: {
			...mapState(['userCenterData'])
		},

		methods: {

			...mapMutations(['login', 'setUserCenterData']),
			//注册协议点击事件
			checkAgrement() {
				this.check_agreement = !this.check_agreement;
				this.show_check_icon = this.check_agreement ? getApp().globalData.imgUrl + 'register_checked.png' :
					getApp().globalData.imgUrl + 'register_uncheck.png';
			},
			getUser(e) {
				if (e.detail.errMsg == "getUserInfo:ok") {
					let userinfo = e.detail.userInfo;
					this.getWxXcxCoce(userinfo);
				}
			},

			handleAcc() {
				let regEn = /[`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/ig,
					regCn = /[·！#￥（——）：；“”‘、，|《。》？、【】[\]]/ig;
				if (regEn.test(this.mobile) || regCn.test(this.mobile)) {
					this.mobile = ""
					this.$api.msg("名称不能包含特殊字符.");
				}

			},

			//微信小程序根据用户信息获取code
			getWxXcxCoce(userinfo) {
				let {
					client
				} = this;
				let _this = this;
				uni.showLoading({
					title: '正在请求...',
					mask: true
				});
				uni.login({
					success: code => {
						let tar_params = {};
						tar_params.source = client;
						tar_params.code = code.code;
						tar_params.userInfo = JSON.stringify(userinfo);
						_this.goLogin(tar_params);
						this.wtCode = code.code
					}
				});
			},

			getUserProfile(e) {
				let that = this
				if (!this.isClick) {
					return
				}
				this.isClick = false
				// 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认
				// 开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
				uni.getUserProfile({
					desc: '用于完善个人信息', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
					success: (res) => {
						if (res.errMsg == "getUserProfile:ok") {
							let userinfo = res.userInfo;
							this.getWxXcxCoce(userinfo);
						}
					},
					complete() {
						that.isClick = true
					}
				})
			},

			//跳转协议页面
			agreement(type) {
				this.$Router.push({
					path: '/pages/privacyPolicy/privacyPolicy',
					query: {
						type: type
					}
				})
			},
			//光标聚焦事件
			setFocus(e) {
				this.curFocus = e.currentTarget.dataset.key;
			},
			inputChange(e) {
				const key = e.currentTarget.dataset.key;
				this[key] = e.detail.value;
			},
			navBack() {

				this.$Router.pushTab('/pages/user/user')
			},
			toLogin() {
				if (!(this.mobile && this.password) || this.logining) {
					uni.showToast({
						title: '请输入账号密码',
						icon: 'none',
						duration: 700
					})
					return;
				}
				// #ifdef APP-PLUS
				if (!this.check_agreement) {
					this.$api.msg('请同意用户隐私政策!');
					return false;
				}
				// #endif
				this.logining = true;
				const {
					mobile,
					password
				} = this;
				//密码的验证 6～20位，英文、数字或符号
				if (!this.$checkPwd(password)) {
					this.logining = false;
					return false
				}
				let param = {};
				param.url = 'v3/frontLogin/oauth/token';
				param.data = {};
				param.data.username = mobile; //登陆类型为1时：是用户名；为2时：是手机号
				param.data.password = password;
				param.data.loginType = 1; //登陆类型：1-账号密码登陆，2-手机验证码登陆

				//如果有缓存的购物车数据，登录需要把数据同步，并清除本地缓存
				let local_cart_list = uni.getStorageSync('cart_list')
				let cartInfo = []
				if (local_cart_list) {
					local_cart_list.storeCartGroupList.map(item => {
						item.promotionCartGroupList.map(item1 => {
							item1.cartList.map(item2 => {
								if (item2.isChecked == 1) {
									cartInfo.push({
										productId: item2.productId,
										buyNum: item2.buyNum
									})
								}
							})
						})
					})
					param.data.cartInfo = JSON.stringify(cartInfo);
				}
				param.method = 'POST';
				this.$request(param).then(res => {
					if (res.state == 200) {
						//更新登录时间
						uni.setStorage({
							key: 'sld_login_time',
							data: new Date().getTime(),
						});

						uni.removeStorage({
							key: 'cart_list'
						}); //清除购物车数据
						res.data.loginTime = Date.parse(new Date()); //登录时间
						this.login(res.data);
						//如果推手分享，则建立推手分享关系
						if (uni.getStorageSync('u')) {
							this.estabTs()
						}
						//获取个人中心的数据
						this.$request({
							url: 'v3/member/front/member/memberInfo',
						}).then(result => {
							this.setUserCenterData(result.data);
							this.$loginGoPage();
						}).catch((e) => {})
					} else {
						//错误提示
						this.$api.msg(res.msg);
					}
					this.logining = false;
				}).catch((e) => {})
			},

			//清空输入的内容
			clearContent(type) {
				this[type] = '';
			},

			//是否显示密码切换事件
			changePwdState() {
				this.showPwd = !this.showPwd;
			},

			//跳转事件 type:跳转类型，1为redirectTo 2为navigateTo
			navTo(url, type) {
				if (type == 1) {
					this.$Router.replace(url)
				} else if (type == 2) {
					this.$Router.push(url)
				}
			},
			//授权登录
			quickLogin() {
				// #ifdef APP-PLUS
				if (!this.check_agreement) {
					this.$api.msg('请同意用户隐私政策!');
					return false;
				}
				// #endif
				if(this.scanCode){
					uni.setStorageSync('fromurl', {
						url: '/pages/public/codeLogin'
					});
				}
				let {
					client
				} = this;
				let _this = this;
				//#ifdef APP-PLUS
				uni.login({
					provider: 'weixin',
					success: function(loginRes) {
						if (loginRes.errMsg == 'login:ok') {
							//授权登录成功
							// 获取用户信息
							uni.getUserInfo({
								provider: 'weixin',
								success: function(infoRes) {
									let tar_params = {};
									tar_params.unionid = loginRes.authResult.unionid;
									tar_params.openid = loginRes.authResult.openid;
									tar_params.userInfo = JSON.stringify(infoRes.userInfo);
									tar_params.source = client;
									_this.goLogin(tar_params);
								}
							});
						}
					}
				});
				//#endif
				//#ifdef H5
				let tar_url = location.href;
				tar_url += location.href.indexOf('?') > -1 ? '&' : '?';
				tar_url += 'ori_url=' + location.href;
				let uricode = encodeURIComponent(tar_url)
				window.location.href = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' +
					getApp().globalData.h5AppId +
					'&redirect_uri=' + uricode +
					'&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect';
				//#endif
			},

			//如果推手分享，则建立推手分享关系
			estabTs() {
				let {
					spreaderMemberId
				} = this
				this.$request({
					url: '/v3/spreader/front/spreaderShare/editRelation',
					method: "POST",
					data: {
						spreaderMemberId
					}
				}).then(res => {
					if (res.state = 200) {}
				})
			},

			//登录 data为除购物车信息外的接口参数，对象类型
			goLogin(data) {
				// #ifdef APP-PLUS
				if (!this.check_agreement) {
					this.$api.msg('请同意用户隐私政策!');
					return false;
				}
				// #endif
				let _this = this;
				let param = {};
				param.url = 'v3/member/front/login/wechat/login';
				param.data = {
					...data
				};

				//如果有缓存的购物车数据，登录需要把数据同步，并清除本地缓存
				let local_cart_list = uni.getStorageSync('cart_list')
				let cartInfo = []
				if (local_cart_list) {
					local_cart_list.storeCartGroupList.map(item => {
						item.promotionCartGroupList.map(item1 => {
							item1.cartList.map(item2 => {
								if (item2.isChecked == 1) {
									cartInfo.push({
										productId: item2.productId,
										buyNum: item2.buyNum
									})
								}
							})
						})
					})
					param.data.cartInfo = JSON.stringify(cartInfo);
				}
				param.method = 'POST';
				this.$request(param).then(res => {
					if (res.state == 200) {
						//更新登录时间
						uni.setStorage({
							key: 'sld_login_time',
							data: new Date().getTime(),
						});
						uni.removeStorage({
							key: 'cart_list'
						}); //清除购物车数据
						if (res.data.redirect == undefined) {
							res.data.loginTime = Date.parse(new Date()); //登录时间
							_this.login(res.data);
							//登录成功 获取个人中心的数据
							_this.$request({
								url: 'v3/member/front/member/memberInfo',
							}).then(result => {
								_this.setUserCenterData(result.data);
								//#ifdef H5
								let isWeiXinH5 = this.$isWeiXinBrower();
								if(isWeiXinH5){
									let fromurl = uni.getStorageSync('fromurl');
									if(fromurl.url){
										setTimeout(()=>{
											_this.$Router.back(2);
											// _this.$Router.replace({
											// 	path: fromurl.url,
											// 	query: fromurl.query
											// })
										},1000)
									}else{
										_this.$loginGoPage();
									}
								}else{
									_this.$loginGoPage();
								}
								//#endif
								//#ifndef H5
								_this.$loginGoPage();
								//#endif
							}).catch((e) => {})
						} else if (res.data.redirect != undefined) {
							//用户未注册，需要绑定手机号进行注册
							//#ifdef H5
							let isWeiXinH5 = this.$isWeiXinBrower();
							if (isWeiXinH5 && this.$getQueryVariable('code')) {
								//如果是微信浏览器，而且浏览器地址里有code，需要把code再跳转下一页，防止返回的时候再去验证code
								history.replaceState({}, '', location.href.split('?')[0]);
							}
							//#endif

							// #ifndef MP-WEIXIN
							this.$Router.push({
								path: '/pages/public/bindMobile',
								query: {
									code: res.data.bindKey
								}
							})
							// #endif

							// #ifdef MP-WEIXIN
							this.bindKey = res.data.bindKey
							this.$refs.wt.open()
							// #endif

						}

					} else {
						//错误提示
						// #ifndef MP-WEIXIN
						_this.$api.msg(res.msg);
						// #endif

						// #ifdef MP-WEIXIN
						uni.showToast({
							title: res.msg,
							icon: 'none',
							duration: 2000
						})
						// #endif

					}
					uni.hideLoading();
				}).catch((e) => {
					uni.hideLoading();
				})
			},

			//微信登录互联开关
			getWxAuthority() {
				this.$request({
					url: 'v3/system/front/setting/getSettings',
					data: {
						names: 'login_wx_app_is_enable'
					}
				}).then(res => {
					this.isWxEnable = res.data[0]
				})
			},



			// #ifdef MP-WEIXIN
			getMobile(e) {
				if (e.detail.errMsg == 'getPhoneNumber:ok') {
					this.$refs.wt.close()
					uni.login({
						success: code => {
							let {
								encryptedData,
								iv
							} = e.detail
							this.$request({
								url: 'v3/member/front/login/wechat/getMobile',
								method: 'POST',
								data: {
									code: code.code,
									encryptedData,
									iv
								}
							}).then(res => {
								if (res.state == 200) {
									this.userPhone = res.data.phoneNumber
									this.bindMobile(1)
								} else {
									this.$api.msg(res.msg)
								}
							})
						}
					})

				} else {

				}
			},

			bindMobile(bindType) {
				uni.showLoading({})
				let param = {};
				param.url = 'v3/member/front/login/wechat/bindMobile';
				param.data = {};
				param.data.bindType = bindType;
				param.data.mobile = this.userPhone;
				param.data.resource = 4;
				param.data.bindKey = this.bindKey;
				param.method = 'POST';
				this.$request(param).then(res => {
					uni.hideLoading()
					if (res.state == 200) {
						this.$refs.bind.close()
						//更新登录时间
						uni.setStorage({
							key: 'sld_login_time',
							data: new Date().getTime(),
						});

						uni.removeStorage({
							key: 'cart_list'
						}); //清除购物车数据
						res.data.loginTime = Date.parse(new Date()); //登录时间
						this.login(res.data);
						//如果推手分享，则建立推手分享关系
						if (uni.getStorageSync('u')) {
							this.estabTs()
						}
						//获取个人中心的数据
						this.$request({
							url: 'v3/member/front/member/memberInfo',
						}).then(result => {
							this.setUserCenterData(result.data);
							this.$loginGoPage();
						}).catch((e) => {})
						this.$api.msg(res.msg)
					} else if (res.state == 267) {
						//手机号已被绑定,提示用户
						this.$refs.bind.open()
						this.bindedAccount = res.data;
					} else {
						//错误提示
						this.$api.msg(res.msg);
					}
				})
			},
			getBindCancle() {
				this.$refs.wt.close()
				this.$Router.push({
					path: '/pages/public/bindMobile',
					query: {
						code: this.bindKey
					}
				})
			}
			// #endif













		},

	}
</script>

<style lang='scss'>
	page {
		background: #fff;
		width: 750rpx;
		margin: 0 auto;
	}

	.container {
		/* padding-top: 19.2vh; */
		position: relative;
		width: 750rpx;
		height: 100vh;
		overflow: hidden;
		background: #fff;
	}

	.placeStyle {
		color: #999999;
		/* #ifdef MP-BAIDU */
		/* font-size: 22rpx; */
		/* #endif */
	}

	.wrapper {
		position: relative;
		z-index: 90;
		background: #fff;
		padding-bottom: 40upx;
	}

	.back-btn {
		margin-left: 40rpx;
		margin-top: 40rpx;
		/* #ifndef H5 */
		margin-top: 88rpx;
		/* #endif */
		font-size: 32rpx;
		color: $main-font-color;
		display: inline-block;
	}

	.login-title {
		position: relative;
		margin-top: 90rpx;
		margin-bottom: 70rpx;
		margin-left: 65rpx;
		font-size: 36rpx;
		color: #333;
		font-weight: bold;

		&:after {
			position: absolute;
			left: 0;
			bottom: -10rpx;
			content: '';
			width: 76rpx;
			height: 6rpx;
			background: linear-gradient(90deg, rgba(252, 28, 28, 1) 0%, rgba(255, 138, 0, 0) 100%);
		}
	}

	.input-content {
		padding: 0 65rpx;
	}

	.input-item {
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		justify-content: center;
		height: 80rpx;
		margin-bottom: 50upx;
		border-bottom: 1px solid rgba(0, 0, 0, 0.1);
		position: relative;

		input {
			color: #2D2D2D;
		}

		.clear-account {
			position: absolute;
			right: 6rpx;
			top: 28rpx;
			font-size: 26rpx;
			color: #ddd;
		}

		&:last-child {
			margin-bottom: 0;

			.pwd-right {
				position: absolute;
				right: 6rpx;
				top: 14rpx;
				z-index: 999;

				.clear-pwd {
					font-size: 26rpx;
					color: #ddd;
				}



				.pwd-tab {
					font-size: 30rpx;
					color: #666;
					margin-left: 20rpx;
					margin-right: 28rpx;

					&.iconziyuan9 {
						font-size: 15rpx;
						transform: scale(0.1)
					}

					&.iconziyuan81 {
						font-size: 20rpx;
						transform: scale(0.1)
					}
				}

				.forget-pwd {
					color: #2D2D2D;
					font-size: 28rpx;
					line-height: 28rpx;
					font-weight: 400;
					border-left: 1px solid $border-color-split;
					padding-left: 28rpx;
				}
			}
		}

		input {
			height: 60upx;
			font-size: $font-base + 2upx;
			color: $font-color-dark;
			width: 80%;
		}
	}


	.confirm-btn {
		width: 620rpx;
		height: 88rpx;
		line-height: 88rpx;
		margin: 90rpx auto;
		background: linear-gradient(90deg, rgba(252, 31, 29, 1) 0%, rgba(253, 115, 38, 1) 100%);
		box-shadow: 0px 3rpx 14rpx 1rpx rgba(253, 38, 29, 0.26);
		border-radius: 44rpx;
		color: #fff !important;
		font-size: 36rpx;
		border: none !important;
		outline: none;

		&::after {
			border: none !important;
		}
	}

	.other-login {
		position: absolute;
		left: 0;
		bottom: 140rpx;
		width: 100%;
		display: flex;
		flex-direction: column;

		.title {
			display: flex;
			justify-content: center;
			align-items: center;

			&:before {
				content: ' ';
				width: 150rpx;
				height: 1rpx;
				background: #CBCBCB;
			}

			&:after {
				content: ' ';
				width: 150rpx;
				height: 1rpx;
				background: #CBCBCB;
			}

			text {
				color: #999999;
				font-size: 26rpx;
				margin: 0 20rpx;
			}
		}

		.login-method {
			display: flex;
			justify-content: center;
			margin-top: 20rpx;

			.wechat-login {
				display: flex;
				flex-direction: column;
				align-items: center;
				width: 100%;
				background: transparent;
				line-height: auto;
				height: auto;

				&::after {
					border: none;
				}

				image {
					width: 110rpx;
					height: 110rpx;
				}

				text {
					color: #666666;
					font-size: 26rpx;
				}
			}
		}

	}

	.agreement-part {
		position: absolute;
		left: 0;
		bottom: 60rpx;
		width: 100%;
		font-size: 26rpx;
		color: #999999;
		text-align: center;

		.register_icon {
			width: 46rpx;
			height: 46rpx;
		}

		.agreement {
			color: #FC1E1E;
			border-bottom: 1rpx solid $main-color;
		}
	}

	.login-register {
		display: flex;
		justify-content: center;
		margin-top: 33rpx;

		.mobile-login {
			color: #2D2D2D;
			font-size: 28rpx;
			line-height: 34rpx;
			border-right: 1px solid rgba(0, 0, 0, .1);
			padding-right: 30rpx;
			margin-right: 30rpx;
		}

		.register {
			color: #FC1C1C;
			font-size: 28rpx;
			line-height: 34rpx;
		}
	}



	.wrapper {
		background: #fff;
		padding: 30rpx;
		border-radius: 20rpx;
	}

	.bind_state_top {

		display: flex;
		flex-direction: column;
		align-items: center;

		.mobile_logo {
			width: 120rpx;
			height: 120rpx;
		}

		.mobile_num {
			font-size: 30rpx;
			font-weight: 500;
			color: #FC2624;
			margin-top: 39rpx;
		}

		.mobile_binded {
			font-size: 30rpx;
			font-weight: 500;
			color: #333333;
			margin-top: 19rpx;
		}

	}

	.bind_change_info {
		font-size: 24rpx;
		text-align: center;
		color: #666666;
		line-height: 39rpx;
		margin-top: 31rpx;

		.change_info_mobile {
			color: #333333;
		}
	}

	.bind_state_btn_con {
		width: 520rpx;
		height: 70rpx;
		margin: 0 auto;
		margin-top: 40rpx;
		font-size: 30rpx;
		display: flex;
		justify-content: center;

		.update_btn {
			width: 208rpx;
			height: 69rpx;
			line-height: 69rpx;
			color: #ff0000;
			text-align: center;
			border-radius: 35rpx 0 0 35rpx;
			border: 1px solid #ff0000;
		}

		.go_on_btn {
			width: 208rpx;
			height: 69rpx;
			line-height: 69rpx;
			text-align: center;
			background-color: #ff0000;
			color: white;
			border-radius: 0 35rpx 35rpx 0;
			border: 1px solid #ff0000;
		}
	}

	.sld-success-title {
		line-height: 42rpx;
		font-size: 32rpx;
		color: #666666;
		padding: 40rpx 30rpx;
		text-align: center;
	}

	.sld-success {
		background-color: #fff;
		color: #666666;
		font-size: 28rpx;
		width: 500rpx;
		border-radius: 20rpx;
		padding: 30rpx;

		.sld-success-content {
			line-height: 45rpx;
			margin-bottom: 30rpx;
			padding: 0 35rpx;
			color: #999;
			font-size: 26rpx;
		}

		.sld-btns {
			display: flex;
			align-items: center;
			justify-content: space-between;
			margin-top: 20rpx;
			width: 100%;

			button {
				width: 200rpx;
				height: 50rpx;
				border-radius: 40rpx;
				font-size: 28rpx;
				line-height: 50rpx;
				outline: none;
				background-color: #fff;
				color: #999;
				border: 1px solid #999999;
				margin: 0;

				&.confirm {
					color: #fff;
					background: linear-gradient(135deg, #FB3E31 0%, #FED600 0%, #FF4E00 0%, #FF001D 100%);
					;
					border: none;
				}

				&::after {
					border: none;
				}
			}
		}
	}
</style>
