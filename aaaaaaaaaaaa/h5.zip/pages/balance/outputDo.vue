<template>
	<view class="output_do">
		<view class="tips flex_row_between_center" v-if="showTip">
			<span>温馨提示：提现手续费为{{extra}}%，最低提现金额为￥{{minMoney ? Number(minMoney).toFixed(2) : 0}}。</span>
			<text class="iconfont iconziyuan51" @click="closeTip"></text>
		</view>
		<view class="money">
			<view class="top">提现金额</view>
			<view class="middle flex_row_start_center">
				<span>￥</span>
				<input v-model="cashAmount" maxlength="6"/>
			</view>
			<view class="bottom" :class="{err}">{{err ? err : '剩余可提现金额￥' + Number(userCenterData.memberBalance).toFixed(2)}}</view>
		</view>
		<view class="account">
			<view class="account_top">提现账号</view>
			<view class="account_bottom flex_row_between_center" @click="openPop">
				<block v-if="accInfo.accountId">
					<view class="left flex_row_start_center">
						<image class="logo" :src="imgUrl + (accInfo.accountCode == 'ALIPAY' ? 'pay/alipay_pay_icon.png' : 'pay/wx_pay_icon.png')"></image>
						<view class="middle" :class="accInfo.accountCode=='ALIPAY' ? 'flex_column_between_start' : 'flex_column_center_start'">
							<view v-if="accInfo.accountCode == 'ALIPAY'">
								<span>支付宝账号：</span>{{accInfo.accountNumber}}
							</view>
							<view>
								<span>真实姓名：</span>{{accInfo.accountName}}
							</view>
						</view>
					</view>
						<view class="right">
							<text class="iconfont iconziyuan11"></text>
						</view>
				</block>
				<block v-else>
					<view>请选择提现账号</view>
					<text class="iconfont iconziyuan11"></text>
				</block>
			</view>
		</view>
		<view class="btn" @click.stop="apply">申请提现</view>
		
		<uni-popup ref="accountPop" type="bottom">
			<view class="account_box">
				<view class="title">
					选择提现账号
					<text class="iconfont iconziyuan51" @click="closePop"></text>
				</view>
				<view v-for="(item,index) in account" :key="item.id" class="item flex_row_between_center"
					:class="{border:index!=0}" @click="changeAcc(index)">
					<view class="left flex_row_start_center">
						<image class="logo" :src="imgUrl + (item.accountCode == 'ALIPAY' ? 'pay/alipay_pay_icon.png' : 'pay/wx_pay_icon.png')"></image>
						<view class="middle" :class="item.accountCode=='ALIPAY' ? 'flex_column_between_start' : 'flex_column_center_start'">
							<view v-if="item.accountCode == 'ALIPAY'">
								<span>支付宝账号：</span>{{item.accountNumber}}
							</view>
							<view>
								<span>真实姓名：</span>{{item.accountName}}
							</view>
						</view>
					</view>
					<view class="right">
						<image v-if="accIndex == index" :src="imgUrl + 'checked.png'" mode="aspectFit" lazy-load></image>
					</view>
				</view>
				<block v-for="(item,index) in ['支付宝','微信']" :key="index">
					<view v-if="index==0&&noAli || index==1&&noWechat" class="item flex_row_between_center"
						:class="{border:index!=0}" @click="addType(index)">
						<view class="left flex_row_start_center">
							<image class="logo" :src="imgUrl + 'addAccount.png'"></image>
							<view class="middle flex_column_center_start">
								<view>
									<span>添加{{item}}提现账号</span>
								</view>
							</view>
						</view>
						<view class="right">
							<text class="iconfont iconziyuan11"></text>
						</view>
					</view>
				</block>
			</view>
		</uni-popup>
	
		<uni-popup ref="submitPop" @close="closeSubmit">
			<view class="submit">
				<view class="submit_title">
					提现金额
					<text class="iconfont iconziyuan51" @click="closeSubmit"></text>
				</view>
				<view class="submit_money flex_row_center_center">￥<span>{{cashAmount}}</span></view>
				<view class="submit_main">
					<view class="submit_item flex_row_between_center">
						<span class="submit_left">手续费：</span>
						<span class="submit_right">
							￥{{extra ? (Number(cashAmount)*Number(extra)/100).toFixed(2) : 0}}
						</span>
					</view>
					<view class="submit_item flex_row_between_center">
						<span class="submit_left">手续费比例：</span>
						<span class="submit_right">{{extra}}%</span>
					</view>
					<input type="password" v-model="payPwd" placeholder="请输入平台支付密码" maxlength="30"/>
				</view>
				<view class="submit_err" v-if="submitErr">{{submitErr}}</view>
				<view class="submit_btn" @click="submit">确定</view>
			</view>
		</uni-popup>
	</view>
</template>

<script>
	import uniPopup from '@/components/uni-popup/uni-popup.vue';
	import { mapState } from 'vuex';
	export default {
		components: {
			uniPopup
		},
		data() {
			return {
				imgUrl: getApp().globalData.imgUrl,
				showTip: true,
				minMoney: 0,
				extra: 0,
				cashAmount: '',
				err: '',
				account: [],
				accIndex: -1,
				accInfo: {},
				payPwd: '',
				submitErr: '',
				noAli: true,
				noWechat: true,
				outputAli: false,
				outputWx: false,
				isClick: false,
			}
		},
		computed: {
			...mapState(['userCenterData'])
		},
		onLoad() {
			// #ifdef H5
			let isWeiXinH5 = this.$isWeiXinBrower();
			if(!isWeiXinH5){
				this.noWechat = false;
			}
			// #endif
			this.getSet();
		},
		onShow() {
			this.getOutputSet();
		},
		methods: {
			getOutputSet() {
				let param = {}
				param.url = 'v3/system/front/setting/getSettings'
				param.method = 'GET'
				param.data={}
				param.data.names='withdraw_alipay_is_enable,withdraw_wxpay_is_enable'
				this.$request(param).then(res => {
					if (res.state == 200) {
						this.outputAli = (res.data[0]=='1') ? true : false;
						this.outputWx = (res.data[1]=='1') ? true : false;
					} else {
						this.$api.msg(res.msg);
					}
					this.getList();
				})
			},
			getSet() {
				let param = {};
				param.method = 'GET';
				param.url = 'v3/system/front/setting/getSettings';
				param.data = {};
				param.data.names = 'min_withdraw_amount,withdraw_fee';
				this.$request(param).then(res => {
					if (res.state == 200) {
						if(res.data[0]){
							this.minMoney = res.data[0];
						}
						if(res.data[1]){
							this.extra = res.data[1];
						}
					}
				})
			},
			getList() {
				let param = {};
				param.method = 'GET';
				param.url = 'v3/member/front/member/cash/list';
				param.data = {};
				param.data.current = this.current;
				param.data.pageSize = this.pageSize;
				this.$request(param).then(res => {
					if(res.state == 200){
						this.account = res.data.list;
						this.account.forEach(item=>{
							if(item.accountCode == 'ALIPAY'){
								this.noAli = false;
							}else if(item.accountCode == 'WXPAY'){
								this.noWechat = false;
							}
						})
						if(!this.outputAli){
							this.noAli = false;
						}
						if(!this.outputWx){
							this.noWechat = false;
						}
					}
				})
			},
			closeTip() {
				this.showTip = false;
			},
			openPop() {
				this.$refs.accountPop.open();
			},
			closePop() {
				this.$refs.accountPop.close();
			},
			changeAcc(index) {
				this.accIndex = index;
				this.accInfo = this.account[index];
				this.$refs.accountPop.close();
			},
			addType(type) {
				this.accIndex = -1;
				this.accInfo = {};
				this.$refs.accountPop.close();
				this.$Router.push({
					path: '/pages/balance/add',
					query: {
						type: type==0 ? 'ALIPAY' : 'WXPAY'
					}
				})
			},
			apply() {
				if(!this.cashAmount){
					this.err = '请输入提现金额';
				}else if(this.cashAmount < this.minMoney){
					this.err = '最低提现金额为￥' + Number(this.minMoney).toFixed(2);
				}else if(this.cashAmount > this.userCenterData.memberBalance){
					this.err = '剩余可提现金额不足';
				}else if(!this.accInfo.accountNumber){
					this.$api.msg('请选择提现账号');
				}else{
					this.err = ''
					this.$refs.submitPop.open();
				}
			},
			closeSubmit() {
				this.$refs.submitPop.close();
				this.payPwd = '';
				this.submitErr = '';
			},
			submit() {
				if(!this.payPwd){
					this.submitErr = '请输入平台支付密码'
				}else if(this.isClick){
					return;
				}else{
					this.isClick = true;
					let param = {};
					param.method = 'GET';
					param.url = 'v3/member/front/member/cash/log/verifyPwd';
					param.data = {};
					param.data.payPwd = this.payPwd;
					this.$request(param).then(res => {
						if (res.state == 200) {
							let params = {};
							params.method = 'POST';
							params.url = 'v3/member/front/member/cash/log/applyWithdraw';
							params.data = {};
							params.data.accountId = this.accInfo.accountId;
							params.data.cashAmount = this.cashAmount;
							params.data.payPwd = this.payPwd;
							params.data.accountName = this.accInfo.accountName;
							if(this.accInfo.accountNumber){
								params.data.accountNumber = this.accInfo.accountNumber;
							}
							this.$request(params).then(response => {
								if (response.state == 200) {
									this.closeSubmit();
									setTimeout(()=>{
										this.isClick = false;
										this.$Router.replace('/pages/balance/outputList');
									}, 1000)
								} else {
									this.isClick = false;
								}
								this.$api.msg(response.msg);
							})
						} else {
							this.isClick = false;
							this.$api.msg(res.msg);
						}
					})
				}
			},
		}
	}
</script>

<style lang="scss">
	page {
		overflow: auto;
		background-color: #F5F5F5;
	}
	.output_do {
		.tips {
			width: 100%;
			min-height: 70rpx;
			padding: 20rpx;
			background: rgba(255,0,0,.2);
			
			span {
				width: 670rpx;
				color: #000000;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 500;
				white-space: normal;
				word-break: break-all;
			}
			
			.iconziyuan51 {
				color: #333333;
				font-size: 24rpx;
				transform: scale(0.8);
			}
		}
		
		.money {
			overflow: hidden;
			margin-top: 20rpx;
			padding-left: 50rpx;
			padding-right: 50rpx;
			background-color: #FFFFFF;
			
			.top {
				line-height: 40rpx;
				color: #333333;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				margin-top: 38rpx;
				margin-bottom: 38rpx;
			}
			
			.middle {
				span {
					line-height: 40rpx;
					color: #000000;
					font-size: 46rpx;
					font-family: PingFang SC;
					font-weight: 800;
					margin-left: 20rpx;
				}
				
				input {
					width: 460rpx;
					height: 40rpx;
					line-height: 40rpx;
					font-size: 42rpx;
					margin-left: 20rpx;
				}
			}
			
			.bottom {
				line-height: 40rpx;
				color: #6B6B71;
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 500;
				border-top: 1rpx solid #DFDFDF;
				margin-top: 20rpx;
				padding-top: 24rpx;
				padding-bottom: 24rpx;
				
				&.err {
					color: #FA0000;
				}
			}
		}
		
		.account {
			overflow: hidden;
			margin-top: 20rpx;
			padding: 30rpx 50rpx;
			background-color: #FFFFFF;
			
			.account_top {
				line-height: 40rpx;
				color: #333333;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				margin-bottom: 30rpx;
			}
			
			.account_bottom {
				view {
					line-height: 40rpx;
					color: #999999;
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 500;
				}
				
				.iconziyuan11 {
					color: #333333;
					font-size: 24rpx;
					transform: scale(0.9);
				}
			}
		}
		
		.btn {
			position: fixed;
			bottom: 60rpx;
			left: 50%;
			margin-left: -303rpx;
			width: 606rpx;
			height: 78rpx;
			line-height: 78rpx;
			color: #FFFFFF;
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			text-align: center;
			background: linear-gradient(0deg, #FB4C58, #F6312C);
			box-shadow: 0 2rpx 10rpx 0 rgba(254, 56, 53, 0.3);
			border-radius: 40rpx;
		}
		
		.account_box {
			width: 100%;
			padding-left: 40rpx;
			padding-right: 40rpx;
			padding-bottom: 20rpx;
			background-color: #FFFFFF;
			border-top-left-radius: 28rpx;
			border-top-right-radius: 28rpx;
			overflow: hidden;
			
			.title {
				position: relative;
				line-height: 40rpx;
				color: #000000;
				font-size: 34rpx;
				font-family: PingFang SC;
				font-weight: 700;
				text-align: center;
				margin-top: 44rpx;
				margin-bottom: 44rpx;
				
				.iconziyuan51 {
					position: absolute;
					top: -18rpx;
					right: 0;
					z-index: 9;
					color: #666666;
					font-size: 24rpx;
				}
			}

			.item {
				height: 140rpx;
				
				&.border {
					border-top: 1rpx solid #D1D1D1;
				}
			}
		}
		
		
		.item,
		.account_bottom {
			.left {
				.logo {
					width: 64rpx;
					height: 64rpx;
					margin-right: 24rpx;
				}
				
				.middle {
					height: 90rpx;
					
					view {
						line-height: 40rpx;
						color: #666666;
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 500;
						
						span {
							color: #333333;
							margin-right: 10rpx;
						}
					}
				}
			}
			
			.right {
				image {
					width: 36rpx;
				}
				
				.iconziyuan11 {
					font-size: 24rpx;
				}
			}
		}
		
		.submit {
			position: relative;
			width: 580rpx;
			padding: 44rpx 30rpx 50rpx;
			background-color: #FFFFFF;
			border-radius: 20rpx;
			
			.submit_title {
				line-height: 44rpx;
				color: #111111;
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: 500;
				text-align: center;
				margin-bottom: 46rpx;
				
				.iconziyuan51 {
					position: absolute;
					right: 36rpx;
					top: 26rpx;
					z-index: 8;
					color: #333333;
					font-size: 28rpx;
				}
			}
			.submit_money {
				color: #000000;
				font-size: 46rpx;
				font-family: PingFang SC;
				font-weight: 800;
				margin-bottom: 50rpx;
				
				span {
					font-size: 66rpx;
				}
			}
			.submit_main {
				padding: 30rpx 10rpx;
				border-top: 1rpx solid #E7E1E1;
				border-bottom: 1rpx solid #E7E1E1;
				
				.submit_item {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 500;
					margin-bottom: 20rpx;
					
					.submit_left {
						color: #7F7F7F;
					}
					.submit_right {
						color: #000001;
					}
				}
				
				input {
					line-height: 42rpx;
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 500;
					margin-top: 50rpx;
				}
			}
			.submit_err {
				height: 0;
				line-height: 42rpx;
				color: #F50202;
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				margin-top: 10rpx;
				margin-left: 10rpx;
			}
			.submit_btn {
				width: 250rpx;
				height: 70rpx;
				line-height: 70rpx;
				color: #FFFFFF;
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: 500;
				text-align: center;
				background: linear-gradient(0deg, #FA464E, #F6312C);
				border-radius: 34rpx;
				margin: 56rpx auto 0;
			}
		}
	}
</style>
