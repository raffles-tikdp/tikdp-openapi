<template>
	<view class="balance_add">
		<view class="item flex_row_start_center" v-if="type == 'ALIPAY'">
			<view><span>支付宝账号：</span></view>
			<input v-model="accountNumber" placeholder="请输入支付宝账号" maxlength="20" />
		</view>
		<view class="item flex_row_start_center">
			<view><span>真实姓名：</span></view>
			<input v-model="accountName" placeholder="请输入账号使用者的真实姓名" maxlength="20" />
		</view>
		<view class="btn" @click="submit">确认{{isEdit?'修改':'添加'}}</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				isEdit: false, //是否是编辑
				type: 'ALIPAY',
				accountId: '',
				accountName: '',
				accountNumber: '',
				wxCode: '', //微信h5端获取code
				isWeiXinH5: false,
			}
		},
		onLoad() {
			if(this.$Route.query.name){
				this.isEdit = true;
				this.accountId = this.$Route.query.id;
				this.accountNumber = this.$Route.query.card;
				this.accountName = this.$Route.query.name;
			}
			this.type = this.$Route.query.type;
			
			// #ifdef H5
			let code = this.$getQueryVariable('code');
			let isWeiXinH5 = this.$isWeiXinBrower();
			this.isWeiXinH5 = isWeiXinH5;
			if(isWeiXinH5 && this.type == 'WXPAY' && !code){
				let tar_url = location.href;
				tar_url += location.href.indexOf('?') > -1 ? '&' : '?';
				tar_url += 'ori_url=' + location.href;
				let uricode = encodeURIComponent(tar_url)
				window.location.href = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' +
					getApp().globalData.h5AppId +
					'&redirect_uri=' + uricode +
					'&response_type=code&scope=snsapi_userinfo&state=STATE#wechat_redirect';
				return;
			}else if(isWeiXinH5 && code){
				this.type = 'WXPAY';
				this.wxCode = code;
				
				let oriUrl = this.$Route.query.ori_url + 'pages/balance/add';
				let tmp_data = '';
				for (let i in this.$Route.query) {
					if (i != 'ori_url') {
						tmp_data += i + '=' + this.$Route.query[i] + '&'
					}
				}
				oriUrl += '?' + tmp_data;
				this.oriUrl = oriUrl;
				//微信浏览器的话要把浏览器地址里面的code去掉
				history.replaceState({}, '', this.oriUrl);
			}
			// #endif
			
			let title = ''
			if(this.type == 'ALIPAY'){
				title = '支付宝'
			}else{
				title = '微信'
			}
			uni.setNavigationBarTitle({
				title: (this.isEdit ? '编辑' : '添加') + '提现' + title
			})
		},
		onBackPress(){
			if(this.wxCode){
				window.history.go(-2);
				return true;
			}else{
				return false;
			}
		},
		methods: {
			submit() {
				if(!this.accountNumber && this.type=='ALIPAY'){
					this.$api.msg('请输入支付宝账号');
				}else if(!this.accountName){
					this.$api.msg('请输入账号使用者的真实姓名');
				}else if(this.accountId){
					let param = {};
					param.method = 'POST';
					param.url = 'v3/member/front/member/cash/update';
					param.data = {};
					param.data.accountId = this.accountId;
					param.data.accountName = this.accountName;
					param.data.accountNumber = this.accountNumber;
					this.$request(param).then(res => {
						if (res.state == 200) {
							if (res.state == 200) {
								setTimeout(()=>{
									this.$Router.back();
								}, 500)
							}
							this.$api.msg(res.msg);
						}
					})
				}else{
					let _this = this;
					let param = {};
					param.method = 'POST';
					param.url = 'v3/member/front/member/cash/add';
					param.data = {};
					param.data.accountCode = this.type;
					param.data.accountName = this.accountName;
					if(this.type == 'WXPAY'){
						// #ifdef H5
						if(this.isWeiXinH5){
							param.data.codeSource = 2; //用户code来源：1==小程序，2==微信内部浏览器， 3==APP
							param.data.accountNumber = this.wxCode;
						}else{
							return;
						}
						// #endif
						// #ifdef MP-WEIXIN
						uni.login({
							success: code => {
								param.data.codeSource = 1;
								param.data.accountNumber = code.code;
								this.$request(param).then(res => {
									if (res.state == 200) {
										setTimeout(()=>{
											this.$Router.back();
										}, 500)
									}
									this.$api.msg(res.msg);
								})
							}
						})
						return;
						// #endif
						// #ifdef APP-VUE
						uni.login({
							provider: 'weixin',
							success: function(loginRes) {
								if (loginRes.errMsg == 'login:ok') {
									//授权登录成功
									param.data.codeSource =3;
									param.data.accountNumber = loginRes.authResult.openid;
									_this.$request(param).then(res => {
										if (res.state == 200) {
											setTimeout(()=>{
												_this.$Router.back();
											}, 500)
										}
										_this.$api.msg(res.msg);
									})
								}
							},
						})
						return;
						// #endif
					}else{
						param.data.accountNumber = this.accountNumber;
					}
					this.$request(param).then(res => {
						this.$api.msg(res.msg);
						if (res.state == 200) {
							setTimeout(()=>{
								if(this.wxCode){
									// #ifdef H5
									window.history.go(-2);
									// #endif
								}else{
									this.$Router.back();
								}
							}, 1000)
						}
					})
				}
			},
		}
	}
</script>

<style lang="scss">
	page {
		padding-top: 20rpx;
		background-color: #F5F5F5;
	}
	.balance_add {
		.item {
			width: 100%;
			background-color: #FFFFFF;
			padding: 22rpx 48rpx;
			view {
				width: 180rpx;
				height: 40rpx;
				line-height: 40rpx;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				text-align: right;
				margin-right: 20rpx;
				span {
					position: relative;
					&:before {
						content: '*';
						color: #FF0000;
						position: absolute;
						top: 4rpx;
						left: -14rpx;
						z-index: 9;
					}
				}
			}
			input {
				width: 440rpx;
				height: 40rpx;
				line-height: 40rpx;
				font-size: 28rpx;
			}
			&:nth-child(2) {
				border-top: 1rpx solid #D1D1D1;
			}
		}
		.btn {
			position: fixed;
			bottom: 60rpx;
			left: 50%;
			margin-left: -303rpx;
			width: 606rpx;
			height: 78rpx;
			line-height: 78rpx;
			color: #FFFFFF;
			font-size: 30rpx;
			font-family: PingFang SC;
			font-weight: 500;
			text-align: center;
			background: linear-gradient(0deg, #FB4C58, #F6312C);
			box-shadow: 0 2rpx 10rpx 0 rgba(254, 56, 53, 0.3);
			border-radius: 40rpx;
		}
	}
</style>
