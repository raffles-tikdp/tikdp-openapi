//用户协议、隐私协议页面
<template>
<view class="container_pri">
<!-- #ifdef MP-ALIPAY -->
<jyfParser :isAll="true" :html="h5_wx_html"></jyfParser>
<!-- #endif -->
<!-- #ifndef MP-ALIPAY -->
<rich-text :nodes="h5_wx_html"></rich-text>
<!-- #endif -->
</view>
</template>

<script>
import jyfParser from '@/components/jyf-parser/jyf-parser.vue'
import { quillEscapeToHtml } from '@/utils/common.js'
export default {
  data() {
    return {
      type: '',
      // banance: 余额   points: 积分
      key: '',
      imgUrl: getApp().globalData.imgUrl,
      isLoading: true,
      title: '',
      num: "",
      list: "",
	  pn: 1,//当前页
	  hasmore: true,
	  h5_wx_html:''
    };
  },
  components: {jyfParser},
  props: {},
  onLoad(){
  	  this.getPrivacyPolicy();
	  let title = this.$Route.query.type == 'register_agreement' ? this.$L('用户协议') : this.$L('隐私协议')
	  uni.setNavigationBarTitle({
	  	title: title
	  })
  },
  methods:{
  	  getPrivacyPolicy(){
	    let param = {}
	    param.data = {}
	    // register_agreement 用户协议  privacy_policy 隐私协议
	    param.data.agreementCode= this.$Route.query.type;
	    param.url = 'v3/system/front/agreement/detail'
	    this.$request(param).then(res=>{
			this.h5_wx_html = res.data.content ? quillEscapeToHtml(res.data.content) : '';
	    })
  	  }
  }
};
</script>
<style>
	page{
		width: 750rpx;
		margin: 0 auto;
	}
.container_pri{
	width: 90%;
	height: 100vh;
	margin: 0 auto;
}
p{
	margin-top: 20px;
}
</style>
