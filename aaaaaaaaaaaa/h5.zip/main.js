import Vue from 'vue'
import store from './store'
import App from './App'
import router from './router'
import { RouterMount } from 'uni-simple-router'
import request from './utils/request'
import loginPop from '@/components/loginPop/loginPop.vue'
import {
	checkPaginationHasMore,
	checkSpace,
	replaceConByPosition,
	getPartNumber,
	checkMobile,
	checkPwd,
	loginGoPage,
	formatW,
	checkEmail,
	diyNavTo,
	setCookie,
	setStoreIsCookie,
	weiXinBrowerShare,
	getQueryVariable,
	weiXinBrowerPay,
	sldCommonTip,
	getLoginClient,
	formatPercent,
	setPointIsCookie,
	frequentyleClick,
	back,
	isShowTime,
	formatChatTime,
	checkTel,
	checkIdentity,
	WXBrowserShareThen
} from './utils/common.js'
import {getCurLanguage,weiXinAppShare,isWeiXinBrower,} from './utils/base.js'
import {sldStatEvent} from './utils/stat.js'

const msg = (title, duration = 1500, mask = false, icon = 'none') => {
	//统一提示方便全局修改
	if (Boolean(title) === false) {
		return;
	}
	
	// #ifndef MP-TOUTIAO
	uni.showToast({
		title,
		duration,
		mask,
		icon
	});
	// #endif
	// #ifdef MP-TOUTIAO
	tt.showToast({
		title,
		icon
	});
	// #endif
	
}

const prePage = () => {
	let pages = getCurrentPages();
	let prePage = pages[pages.length - 2];
	// // #ifdef H5
	return prePage;
	// // #endif
	return prePage.$vm;
}

Vue.component('loginPop',loginPop)

const updateToken = () => {
	App.methods.updateAccessToken();
}

Vue.config.productionTip = false
Vue.prototype.$fire = new Vue();
Vue.prototype.$store = store;
Vue.prototype.$request = request;
Vue.prototype.$checkPaginationHasMore = checkPaginationHasMore;
Vue.prototype.$checkSpace = checkSpace;
Vue.prototype.$replaceConByPosition = replaceConByPosition;
Vue.prototype.$getPartNumber = getPartNumber;
Vue.prototype.$checkMobile = checkMobile;
Vue.prototype.$checkPwd = checkPwd;
Vue.prototype.$loginGoPage = loginGoPage;
Vue.prototype.$formatW = formatW;
Vue.prototype.$checkEmail = checkEmail;
Vue.prototype.$diyNavTo = diyNavTo;
Vue.prototype.$setCookie = setCookie;
Vue.prototype.$formatPercent = formatPercent;
Vue.prototype.$setStoreIsCookie = setStoreIsCookie;
Vue.prototype.$setPointIsCookie = setPointIsCookie;
Vue.prototype.$frequentyleClick = frequentyleClick;
Vue.prototype.$L = getCurLanguage;
Vue.prototype.$api = {
	msg,
	prePage
};
Vue.prototype.$isWeiXinBrower = isWeiXinBrower;
Vue.prototype.$weiXinBrowerShare = weiXinBrowerShare;
Vue.prototype.$weiXinAppShare = weiXinAppShare;
Vue.prototype.$getQueryVariable = getQueryVariable;
Vue.prototype.$weiXinBrowerPay = weiXinBrowerPay;
Vue.prototype.$sldCommonTip = sldCommonTip;
Vue.prototype.$getLoginClient = getLoginClient;
Vue.prototype.$back= back;
Vue.prototype.$isShowTime = isShowTime;
Vue.prototype.$formatChatTime = formatChatTime;
Vue.prototype.$sldStatEvent = sldStatEvent;
Vue.prototype.$checkTel = checkTel
Vue.prototype.$checkIdentity = checkIdentity
Vue.prototype.$WXBrowserShareThen = WXBrowserShareThen
App.mpType = 'app'



const app = new Vue({
	...App
})
//v1.3.5起 H5端 你应该去除原有的app.$mount();使用路由自带的渲染方式
// #ifdef H5
	RouterMount(app,'#app');
// #endif
// #ifndef H5
	app.$mount(); //为了兼容小程序及app端必须这样写才有效果
// #endif