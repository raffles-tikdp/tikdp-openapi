<template>
	<view class="rank_banner" :style="'background-image:url('+bannerBg+')'">
		<view class="fixed_top_bar"></view>
		<view :class="{top_bar:true,fixed_top:fixed}">
			<view class="top_header">
				<view class="top_header_left" >
					<!-- #ifndef MP -->
					<image :src="imgUrl + 'index/back.png'" mode="aspectFit" @click="goBack"></image>
					<!-- #endif -->
				</view>
				<view :class="{top_header_cen:true,header_show:showHeader}">{{info.rankName}}</view>
				<view class="top_white_space" @click.stop="$emit('share')">
					<image :src="imgUrl + 'rank/rank_share.png'"></image>
				</view>
			</view>
		</view>
		<view :class="{banner_title:true,banner_by_fixed:fixed}">
			<view class="title_main">{{info.rankName}}</view>
			<view class="title_sub">{{info.description?info.description:''}}</view>
		</view>
	</view>
</template>

<script>
	export default {
		// props: ['fixed','info','showHeader'],
		props:{
			fixed:{
				type:Boolean,
				default:false
			},
			info:{
				type:Object,
				default:{}
			},
			showHeader:{
				type:Boolean,
				default:false
			},
			bannerBg: {
				String: String,
				default: getApp().globalData.imgUrl+'rank/rank_bg.png'
			}
		},
		data() {
			return {
				imgUrl: getApp().globalData.imgUrl
			}
		},
		methods: {
			goBack() {
				this.$back()
			}
		}
	}
</script>

<style lang="scss">
	/* #ifdef APP-PLUS */
	.fixed_top_bar {
		width: 100%;
		height: var(--status-bar-height);
		position: fixed;
		top: 0;
		z-index: 9999;
		background: #D20505;
	}
	/* #endif */
	

	.rank_banner {
		position: relative;
		top:var(--status-bar-height);
		/* #ifdef MP */
		top:0;
		/* #endif */
		background-position: 0 0;
		background-repeat: no-repeat;
		background-size: cover;
		width: 100%;
		height: 350rpx;
	}

	.fixed_top {
		position: fixed;
		top: var(--status-bar-height);
		/* #ifdef MP */
		top:0;
		/* #endif */
		padding: 20rpx;
		background-color: #D20505;
		z-index: 999;
	}
	
	.banner_by_fixed{
		padding-top: 130rpx !important;
	}
	
	.header_show{
		opacity:1!important;
		animation: pageLoading 0.2s ease-in; 
	}
	
	@keyframes pageLoading{
		0%{
	        opacity: 0;
	    }
		
		20%{
			opacity: 0.2
		}
		
		40%{
			opacity: 0.4
		}
		
		60%{
			opacity: 0.6
		}
		
		80%{
			opacity: 0.9
		}
	    100%{
	        opacity: 1;
	    }
	}

	.top_bar {

		width: 100%;
		padding: 20rpx;
		.top_header {
			display: flex;
			align-items: center;
			justify-content: space-between;

			.top_header_left {
				width: 17rpx;
				height: 29rpx;
				image {
					width: 17rpx;
					height: 29rpx;
				}
			}

			.top_header_cen {
				margin: 0 50rpx;
				font-size: 32rpx;
				font-family: PingFangSC-Medium, PingFang SC;
				color: #FFFFFF;
				opacity: 0;
			}

			.top_white_space {
				width: 40rpx;
				height: 49rpx;

				image {
					width: 40rpx;
					height: 40rpx;
				}
			}
		}
	}

	.banner_title {
		width: 100%;
		padding-top: 20rpx;
		padding-bottom: 20rpx;
		text-align: center;

		.title_main {
			font-size: 60rpx;
			font-family: PingFangSC-Medium, PingFang SC;
			background: linear-gradient(143deg, #FFFFFF 0%, #FFB431 100%);
			color: #FFFFFF;
			-webkit-background-clip: text;
			-webkit-text-fill-color: transparent;
			line-height: 90rpx;
			/* #ifdef MP || APP-PLUS */
			font-weight: 500;
			/* #endif */
			/* #ifdef H5 */
			font-weight: 600;
			/* #endif */
			word-break: break-all;
		}

		.title_sub {
			font-size: 24rpx;
			font-family: PingFangSC-Regular, PingFang SC;
			font-weight: 400;
			color: #FFFFFF;
			line-height: 54rpx;
			opacity: 0.8;
		}
	}
</style>
