<template>
	<view class="top_header">
		<view class="fixed_top_bar"></view>
		<view class="header_v">
			<!-- #ifdef MP -->
			<image></image>
			<!-- #endif -->
			<!-- #ifndef MP -->
			<image :src="imgUrl+'lotte_back.png'" @click="back"></image>
			<!-- #endif -->
			<image :src="imgUrl+'lotte_share.png'"@click="openShareVo"></image>
		</view>
	</view>
</template>

<script>
	export default{
		data(){
			return{
				imgUrl:getApp().globalData.imgUrl+'lottery/',
			}
		},
		methods:{
			openShareVo(){
				console.log('pppppp')
				this.$emit('openShare')
			},
			back(){
				console.log('oooooo')
				const page = getCurrentPages()
				if(page.length>1){
					this.$Router.back(1)
				}else{
					this.$Router.replace('/pages/index/index')
				}
				
			}
		}
	}
</script>

<style lang="scss">
	
	.top_header{
		position: absolute;
		top: 0;
		width: 100%;
	}
	
	
	
	
	/* #ifdef APP-PLUS */
	.fixed_top_bar {
		width: 100%;
		height: var(--status-bar-height);
		top: 0;
		z-index: 9999;
	}
	/* #endif */
	
	.header_v{
		padding: 20rpx 20rpx 0rpx 20rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		image{
			width: 50rpx;
			height: 50rpx;
		}
	}
</style>
