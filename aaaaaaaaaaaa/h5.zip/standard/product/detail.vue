<template>
	<view class="container" v-if="isLoading" id="deContainer" @touchstart="dis=false">
		<!-- #ifndef MP -->
		<block v-if="!isNavShow">
			<view class="go_back" @click="goBack">
				<image :src="imgUrl + '/point/goods/go_back.png'"></image>
			</view>
			<view class="go_more" @tap="tipsShow">
				<image :src="imgUrl + '/goods_detail/more_tips.png'"></image>
				<block v-if="tips_show">
					<view class="triangle-up"> </view>
					<view class="tips">
						<button v-for="(item, index) in tips" :key="index" class="tips_pre" @tap="handleLink"
							:data-link="item.tips_link" :open-type="item.type" :data-type="item.type" plain="true">
							<image :src="item.tips_img"></image>
							<text>{{item.tips_name}}</text>
						</button>
					</view>
				</block>
			</view>
		</block>
		<!-- #endif -->
		<!-- 透明遮罩层 -->
		<view class="transparent_mask" v-if="transparent_mask" @tap="hideMask"></view>
		<!-- #ifdef APP-PLUS -->
		<view class="fixed_top_status_bar" :class="{fixed_top_status_bar_no_opcity:noOpcity}"></view>
		<!-- #endif -->
		<view class="nav_list" v-if="isNavShow" :class="{nav_list_no_opcity:noOpcity}">
			<!-- #ifndef MP -->
			<view class="go_back_nav flex_row_center_center" @click="goBack">
				<image :src="imgUrl + '/point/goods/back.png'"></image>
			</view>
			<!-- #endif -->
			<view class="nav_list_pre" v-if="recommendedList && recommendedList.length > 0"
				:class="{nav_list_pre_active:currentNav == item.id}" v-for="(item,index) in navList" :key="index"
				@click="clickNav(item.id)">
				{{item.text}}
			</view>
			<view class="nav_list_pre" v-if="recommendedList && recommendedList.length == 0"
				:class="{nav_list_pre_active:currentNav == item.id}" v-for="(item,index) in navListNoRecommend"
				:key="index" @click="clickNav(item.id)">
				{{item.text}}
			</view>
			<view class="more_tips" @tap="tipsShow">
				<image class="more" :src="imgUrl + 'goods_detail/more.png'"></image>
				<block v-if="tips_show">
					<view class="triangle-up"> </view>
					<view class="tips">
						<view v-for="(item, index) in tips" :key="index" class="tips_pre" @tap="handleLink"
							:data-link="item.tips_link" :open-type="item.type" :data-type="item.type" plain="true">
							<image :src="item.tips_img"></image>
							<text>{{item.tips_name}}</text>
						</view>
					</view>
				</block>
			</view>
		</view>

		<view class="carousel" id="nav1">
			<uni-swiper-dot :info="isChoice == 'default'?defaultProduct.goodsPics:choiceSpecDes.goodsPics"
				:current="goodsVideo?(current-1):current" :showControls='showControls' field="content" :mode="mode">
				<swiper class="swiper-box" @change="change">
					<!-- #ifdef H5 || APP-PLUS-->
					<swiper-item v-if="goodsVideo">
						<!-- 	<image :src="isChoice == 'default'?defaultProduct.goodsPics[0]:choiceSpecDes.goodsPics[0]"
							class="slide-image"></image> -->
						<view
							:style="{backgroundImage:'url('+(isChoice == 'default'?defaultProduct.goodsPics[0]:choiceSpecDes.goodsPics[0])+')'}"
							class="videoImage"></view>
						<image :src="imgUrl+'play.png'" class="play_btn" @click="toPlayPage"></image>
					</swiper-item>
					<!-- #endif -->
					<!-- #ifdef MP  -->
					<swiper-item v-if="goodsVideo">
						<block v-if="!playVFlag">
							<image :src="isChoice == 'default'?defaultProduct.goodsPics[0]:choiceSpecDes.goodsPics[0]"
								class="slide-image"></image>
							<image :src="imgUrl+'play.png'" class="play_btn" @click="playVideo('on')"></image>
						</block>
						<block v-else>
							<video controls :src="goodsVideo" class="video_btn"
								:poster="isChoice == 'default'?defaultProduct.goodsPics[0]:choiceSpecDes.goodsPics[0]"
								autoplay="true" @ended="playVideo('end')">
							</video>
						</block>
					</swiper-item>
					<!-- #endif -->
					<!-- 默认规格 图  start-->
					<block
						v-if="defaultProduct && defaultProduct.goodsPics && defaultProduct.goodsPics.length > 0 && isChoice == 'default'">
						<swiper-item class="swiper-item" v-for="(item,index) in defaultProduct.goodsPics" :key="index">
							<view class="image-wrapper">
								<image :src="item" class="loaded" mode="aspectFit"></image>
							</view>
						</swiper-item>
					</block>
					<!-- 默认规格 图  end-->
					<!-- 选择规格的图 start-->
					<block
						v-else-if="choiceSpecDes && choiceSpecDes.goodsPics && choiceSpecDes.goodsPics.length > 0 && isChoice == 'choice'">
						<swiper-item class="swiper-item" v-for="(item,index) in choiceSpecDes.goodsPics" :key="index">
							<view class="image-wrapper">
								<image :src="item" class="loaded" mode="aspectFit"></image>
							</view>
						</swiper-item>
					</block>
					<!-- 选择规格的图 end-->
				</swiper>
			</uni-swiper-dot>
		</view>

		<!-- 秒杀活动 start -->
		<view class="second_kill" v-if="secKillInfo && (secKillInfo.state == 1 || secKillInfo.state == 2)">
			<!-- 秒杀活动  secKillInfo.state ：1未开始   2进行中 3结束-->
			<!-- 秒杀活动进行中 start -->
			<view class="second_kill_con"
				:style="'background-image:url('+imgUrl+'goods_detail/second_kill_bg.png);background-size:100% 100%;background-repeat:no-repeat;'">
				<!-- 活动进行中 start -->
				<view class="second_kill_left" v-if="secKillInfo.state == 2">
					<!-- 秒杀价 -->
					<view class="second_kill_goods_price"
						v-if="filters.toSplit(filters.toFix(secKillInfo.seckillPrice))[0] && filters.toSplit(filters.toFix(secKillInfo.seckillPrice))[1]">
						<text>￥</text><text>{{filters.toSplit(filters.toFix(secKillInfo.seckillPrice))[0]}}</text>.<text>{{filters.toSplit(filters.toFix(secKillInfo.seckillPrice))[1]}}</text>
					</view>
					<!-- 在售价 -->
					<view class="second_kill_price line_through">
						<text>{{$L('原价')}}:￥{{filters.toFix(secKillInfo.productPrice)}}</text>
					</view>
				</view>
				<!-- 活动进行中 end -->
				<!-- 活动未开始 start -->
				<view class="second_kill_left" v-else>
					<!-- 在售价 -->
					<view class="second_kill_goods_price"
						v-if="filters.toSplit(filters.toFix(secKillInfo.productPrice))[0] && filters.toSplit(filters.toFix(secKillInfo.productPrice))[1]">
						<text>￥</text><text>{{filters.toSplit(filters.toFix(secKillInfo.productPrice))[0]}}</text>.<text>{{filters.toSplit(filters.toFix(secKillInfo.productPrice))[1]}}</text>
					</view>
					<!-- 秒杀价 -->
					<view class="second_kill_price">
						<text>{{$L('秒杀价')}}:￥ {{filters.toFix(secKillInfo.seckillPrice)}}</text>
					</view>
				</view>
				<!-- 活动未开始 end -->

				<view class="second_kill_right">
					<view class="second_kill_text">
						{{secKillInfo.state == 1 ? $L('距开始') : secKillInfo.state == 2 ? $L('距结束') : ''}}
					</view>
					<view class="sec_kill_countdown">
						<text class="day" v-show="secKillDay != '00'">{{secKillDay}}天</text>
						<text class="time">{{secKillHr}}</text>
						<text class="time_tips">:</text>
						<text class="time">{{secKillMin}}</text>
						<text class="time_tips">:</text>
						<text class="time">{{secKillSec}}</text>
					</view>
				</view>
			</view>
			<!-- 秒杀活动进行中 end -->
			<view class="sec_kill_preview" v-if="secKillInfo.state == 1">
				<view class="sec_kill_preview_left">
					{{$L('秒杀预告')}}: {{secKillInfo.startTime + ' '+$L("开始")}}
				</view>

				<view class="sec_kill_preview_right flex_row_center_center" v-if="!secKillInfo.isRemind"
					@click="secKillPreview">
					<image :src="imgUrl + 'goods_detail/time.png'" mode="aspectFit"></image>
					<view class="tip" style="line-height: 12px">{{$L('提醒我')}}</view>
				</view>
				<view class="cancel_preview" v-else @click="secKillPreview">
					{{$L('取消提醒')}}
				</view>
			</view>
		</view>
		<!-- 秒杀活动 end -->

		<!-- 阶梯团活动start -->
		<view class="ladder" v-if="valiInfo(ladderInfo)">
			<ladderInfo :ladderInfo="ladderInfo" :ladderProcess="ladderProcess" @getGoodsDetail="getGoodsDetail">
			</ladderInfo>
		</view>
		<!-- 阶梯团活动end -->

		<!-- 预售 start -->
		<view v-if="valiInfo(preSellInfo)&&preSellInfo.pre_run!=3">
			<preInfo :preSellInfo="preSellInfo" @getGoodsDetail="getGoodsDetail"></preInfo>
		</view>
		<!-- 预售 end -->

		<!-- 拼团start -->
		<view v-if="valiInfo(pinInfo)">
			<pinInfo :pinInfo="pinInfo" @getGoodsDetail="getGoodsDetail" ref="pinInfo"></pinInfo>
		</view>
		<!-- 拼团end -->

		<!-- 有活动商品样式 start -->
		<!-- <template>里不能够v-if用函数返回值做多个或判断 -->
		<view class="introduce_section_activity" v-if="activityState">
			<view class="activity_goods_des">
				<view class="activity_goods_name">
					{{goodsData.goodsName}}
				</view>
				<view class="activity_share_collection">
					<view class="activity_goods_collection" @click="collectGoods">
						<text class="iconfont iconaixin1" v-if="goodsData.followGoods"></text>
						<text class="iconfont iconaixin" v-else></text>
						<text class="show_text">{{goodsData.followGoods ? $L("已收藏") : $L("收藏")}}</text>
					</view>
					<view class="activity_goods_share" @click="goShare">
						<text class="iconfont iconfenxiang"></text>
						<text class="show_text">{{$L('分享')}}</text>
					</view>
				</view>
			</view>
			<view class="activity_goods_brief" v-if="goodsData.goodsBrief">
				{{goodsData.goodsBrief}}
			</view>
		</view>
		<!-- 有活动商品样式 end -->

		<!-- 无活动商品 start-->
		<view class="introduce_section" v-else>
			<view class="price_part flex_row_between_center">
				<view class="left">
					<view class="sell_price" v-if="defaultProduct.productPrice || choiceSpecDes.productPrice">
						<text class="unit">¥ </text>
						<text class="price_int">{{isChoice == 'default' ?
							$getPartNumber(defaultProduct.productPrice,'int') :
							$getPartNumber(choiceSpecDes.productPrice,'int')}}</text>
						<text class="price_decimal">{{isChoice == 'default' ?
							$getPartNumber(defaultProduct.productPrice,'decimal') :
							$getPartNumber(choiceSpecDes.productPrice,'decimal')}}</text>
					</view>
					<view class="original_price" v-if="defaultProduct.marketPrice">
						¥
						{{isChoice == 'default' ? filters.toFix(defaultProduct.marketPrice) :
						filters.toFix(choiceSpecDes.marketPrice)}}
					</view>
				</view>
				<view class="right flex_row_end_center" v-if="goodsData.state==3">
					<view class="flex_column_center_center collection" @click="collectGoods">
						<text class="iconfont iconaixin1" v-if="goodsData.followGoods"></text>
						<text class="iconfont iconaixin" v-else></text>
						<text class="show_text">{{goodsData.followGoods ? $L("已收藏") : $L("收藏")}}</text>
					</view>
					<view class="flex_column_center_center" @click="goShare">
						<text class="iconfont iconfenxiang"></text>
						<text class="show_text">{{$L('分享')}}</text>
					</view>
				</view>
			</view>
			<text class="goods_name">{{goodsData.goodsName}}</text>
			<view class="goods_ad" v-if="goodsData.goodsBrief">{{goodsData.goodsBrief}}</view>
		</view>
		<!-- 无活动商品 end -->

		<!-- 排行榜start -->
		<block v-if="rankData.length>0">
			<gDRank :data="rankData"></gDRank>
		</block>
		<!-- 排行榜end -->


		<!-- 阶梯团 进度 start -->
		<view v-if="valiInfo(ladderInfo)&&ladderInfo.ruleList&&ladderInfo.ladder_run==2">
			<ladderProgress :ladderInfo="ladderInfo"></ladderProgress>
		</view>

		<!-- 阶梯团 进度 end -->

		<!-- 选择规格 start -->
		<view class="spec_con" @click="showSpecModel(goodsData.isVirtualGoods==1?'':'buy')">
			<view class="spec_left">
				<view class="spec_left_title">{{$L('已选')}}</view>
				<view class="spec_left_content" v-if="defaultProduct.getSpecValues || choiceSpecDes.getSpecValues">
					{{isChoice == 'default' ? defaultProduct.getSpecValues : choiceSpecDes.getSpecValues}}
				</view>
				<view class="spec_left_content" v-else>{{$L('默认')}}</view>
			</view>
			<image :src="imgUrl+'goods_detail/right_down.png'" class="spec_right"></image>
		</view>
		<!-- 选择规格 end -->

		<!-- 发货地址,及运费 start -->
		<view class="deliver_goods" v-if="deliverInfo" @click="showAddress">
			<view class="deliver_goods_con" 
				v-if="(!curAddress || curAddress.length<10) 
				  && (filters.toFix(deliverInfo.expressFee)<10000 && goodsData.sales<10000 )">
				<view class="deliver_goods_left">
					<view class="deliver_goods_title">{{$L('送至')}}</view>
					<view class="deliver_goods_address">
						<image :src="imgUrl+'location_on.png'"></image>
						<text :class="{addressDefault:!curAddress}">{{curAddress?curAddress:'请选择地址'}}</text>
					</view>
				</view>
				<view class="deliver_goods_center" v-if="deliverInfo.expressFee!=undefined">
					{{$L('快递')}}:{{filters.toFix(deliverInfo.expressFee)}}元
				</view>
				<view class="deliver_goods_right">{{$L('已销')}}{{goodsData.sales ? goodsData.sales : 0}}</view>
			</view>
			<view class="deliver_goods_con" v-else>
				<view class="deliver_goods_left">
					<view class="deliver_goods_title">{{$L('送至')}}</view>
				</view>
				<view class="deliver_goods_right_main">
					<view class="deliver_goods_address">
						<image :src="imgUrl+'location_on.png'"></image>
						<text :class="{addressDefault:!curAddress}">{{curAddress?curAddress:'请选择地址'}}</text>
					</view>
					<view class="deliver_goods_right_bottom">
						<view class="deliver_goods_center" v-if="deliverInfo.expressFee!=undefined">
							{{$L('快递')}}:{{filters.toFix(deliverInfo.expressFee)}}元
						</view>
						<view class="deliver_goods_right">{{$L('已销')}}{{goodsData.sales ? goodsData.sales : 0}}</view>
					</view>
				</view>
			</view>
		</view>
		<!-- 发货地址,及运费 end -->

		<!-- 拼团成员列表start -->
		<view class="pin_group_con" v-if="valiInfo(pinInfo)">
			<pinGroupList :goodsId="pinInfo.goodsId" :spellId="pinInfo.spellId" @handleJoinGroup="handleJoinGroup"
				@make_group_more_fun="make_group_more_fun" ref="pinGroup"></pinGroupList>
		</view>
		<!-- 拼团成员列表end -->

		<!-- 活动  start-->
		<view class="activity" v-if="(couponList && couponList.length > 0)||(fullDisList && fullDisList.length > 0)">
			<!-- 领券 start -->
			<view class="" v-if="couponList && couponList.length > 0">
				<view class="activity_coupons" @click.prevent="openCouponModel">
					<view class="activity_coupons_left">
						<view class="activity_coupons_tips">{{$L('活动')}}</view>
						<view class="activity_coupons_center">
							<text class="activity_coupons_title">{{$L('领券')}}</text>
							<view class="activity_coupons_list">
								<view class="activity_coupons_pre" :class="{activity_coupons_pre_short:item.couponContent.length>10}"
									:style="{backgroundImage: 'url('+imgUrl +'goods_detail/activity_coupon_bg.png)'}"
									v-for="(item,index) in couponList" v-if="index < 2">
									{{item.couponContent}}
								</view>
							</view>
						</view>
					</view>
					<view class="activity_conpons_right">
						<image :src="imgUrl+'goods_detail/right_down.png'" mode="aspectFit"></image>
					</view>
				</view>

			</view>
			<!-- 领券 end -->
			<!-- 满优惠 start -->
			<view class="" v-if="fullDisList && fullDisList.length > 0" @click="openFullDisModel">
				<view :class="{full_discount:true,padd20:!(couponList && couponList.length > 0)}" v-for="(item,index) in fullDisList" :key="index">
					<view class="activity_coupons_tips" v-if="item.descriptionList.length">{{$L('活动')}}
					</view>
					<block v-if="item.descriptionList.length">
						<text :class="{full_discount_title:true,discount_title_no_ma:!(couponList && couponList.length > 0)}">{{item.promotionName}}</text>
						<view class="full_discount_list">
							<block v-for="(item1,index1) in item.descriptionList" :key="index1">
								<jyfParser :html="item1" style="width:100%;overflow:hidden;flex-shrink:0;"></jyfParser>
							</block>
						</view>
					</block>
				</view>
			</view>
			<!-- 满优惠 end -->
		</view>
		<!-- 活动  end-->

		<!-- 优惠券弹框 start -->
		<uni-popup ref="couponModel" type="bottom" @touchmove.stop.prevent="moveHandle" class="popup_container">
			<view class="coupon_model">
				<view class="coupon_model_title">
					<text>{{$L('领取优惠券')}}</text>
					<image :src="imgUrl+'goods_detail/close.png'" mode="aspectFit" @click="closeModel"></image>
				</view>
				<scroll-view class="coupon_model_list" scroll-y="true">
					<view class="my_coupon_pre" v-for="(item,index) in couponList" :key="index">
						<view class="coupon_pre_top" :style="{backgroundImage:'url(' + item.couponBg + ')'}">
							<view class="coupon_pre_left">
								<!-- 固定券 start -->
								<view class="coupon_pre_price" :class="{coupon_pre_price_high:item.publishValue.toString().length>6}" v-if="item.couponType == 1">
									<text class="unit">¥ </text>
									<text class="price_int" v-if="item.publishValue.toString().indexOf('.')!=-1 && item.publishValue.toString().split('.')[1]>0">{{item.publishValue}}</text>
									<text class="price_int" v-else>{{$getPartNumber(item.publishValue,'int')}}</text>
								</view>
								<!-- 固定券 end -->
								<!-- 折扣券 start -->
								<view class="coupon_pre_price" v-if="item.couponType == 2">
									<view class=""></view>
									<text
										class="price_int">{{filters.toSplit(filters.toFixNum(item.publishValue,1))[0]}}</text>.
									<text
										class="price_decimal">{{filters.toSplit(filters.toFixNum(item.publishValue,1))[1]}}</text>
									<text class="price_decimal">{{$L('折')}}</text>
								</view>
								<!-- 折扣券 end -->
								<!-- 随机券 start -->
								<view class="coupon_pre_price" v-if="item.couponType == 3">
									<text class="unit">¥ </text>
									<text class="price_int">{{$getPartNumber(item.randomMax,'int')}}</text>
								</view>
								<!-- 随机券 end -->
								<view class="coupon_pre_active">{{item.couponContent}}</view>
							</view>
							<view class="coupon_pre_cen">
								<view class="coupon_pre_title">{{item.useTypeValue}}</view>
								<view class="coupon_pre_time">{{item.publishStartTime}}~{{item.publishEndTime}}
								</view>
								<view class="coupon_pre_rules" @click="descriptionOpen(item.couponId)">
									<text>{{$L('使用规则')}}</text>
									<image :src="item.isOpen ? imgUrl + 'coupon/up.png' : imgUrl + 'coupon/down.png'"
										mode="aspectFit"></image>
								</view>
							</view>
							<view class="coupon_pre_right" v-if="item.isReceive == 3">{{$L('已抢完')}}</view>
							<view class="coupon_pre_right" v-if="item.isReceive == 2">{{$L('已领')}}</view>
							<view class="coupon_pre_right" v-if="item.isReceive == 1" @click="goReceive(item)">
								{{$L('立即领取')}}
							</view>
						</view>
						<view class="coupon_rules" v-if="item.isOpen == true">
							<view class="coupon_rules_title">{{$L('使用规则')}}:{{item.description}}</view>
						</view>
						<view class="coupon_type">{{item.couponTypeValue}}</view>
						<view class="coupon_progress" v-if="item.isReceive != 3">
							{{$L('已抢')}}{{item.receivePercent}}%
							<view class="progress_con">
								<progress :percent="item.receivePercent" stroke-width="3" activeColor="#FFFFFF"
									backgroundColor="#FF1919" border-radius='2px' />
							</view>
						</view>
					</view>
				</scroll-view>
			</view>
		</uni-popup>
		<!-- 优惠券弹框 end -->

		<!-- 满优惠弹框 start -->
		<uni-popup ref="fullDisModel" type="bottom" @touchmove.stop.prevent="moveHandle">
			<view class="fulldis_model">
				<view class="fulldis_model_title">
					<text>{{$L('满优惠')}}</text>
					<image :src="imgUrl+'goods_detail/close.png'" mode="aspectFit" @click="closeModel"></image>
				</view>
				<scroll-view class="fulldis_model_list" scroll-y="true">
					<view v-for="(item,index) in fullDisList" :key="index">
						<view class="fulldis_model_pre" v-for="(item1,index1) in item.descriptionList" :key="index1">
							<view class="fulldis_pre_tips"></view>
							<view class="fulldis_pre_con">
								<jyfParser :html="item1"></jyfParser>
							</view>
						</view>
					</view>
				</scroll-view>
				<view class="full_dis_tips">
					{{$L('以上优惠仅为初步预估，实际以结算最终价格为准！')}}
				</view>
			</view>
		</uni-popup>
		<!-- 满优惠弹框 end -->



		<!-- 服务 start -->
		<view class="service" v-if="goodsData && goodsData.serviceLabels && goodsData.serviceLabels.length > 0"
			@click="serviceModel">
			<view class="service_left">
				<view class="service_title">
					{{$L('服务')}}
				</view>
				<view class="service_con">
					<view class="service_pre" v-for="(item,index) in goodsData.serviceLabels" :key="index"
						v-if="index < 3">
						<text class="service_pre_tips"></text>
						<text>{{item.labelName}}</text>
					</view>
				</view>
			</view>
			<view class="service_right">
				<image :src="imgUrl+'goods_detail/right_down.png'" mode="aspectFit"></image>
			</view>
		</view>
		<!-- 服务 end -->
		<!-- 服务弹框 start -->
		<uni-popup ref="serviceModel" type="bottom" @touchmove.stop.prevent="moveHandle">
			<view class="service_model">
				<view class="service_model_top">
					<text>{{$L('服务')}}</text>
					<image :src="imgUrl+'goods_detail/close.png'" mode="aspectFit" @click="closeModel"></image>
				</view>
				<scroll-view class="uni-list service_model_list" scroll-y="true">
					<view class="service_list_pre" v-for="(item,index) in goodsData.serviceLabels" :key="index">
						<view class="service_list_title">{{item.labelName}}</view>
						<view class="service_list_des">{{item.description}}</view>
					</view>
				</scroll-view>
			</view>
		</uni-popup>
		<!-- 服务弹框 end -->

		<!-- 评价 start-->
		<view class="eva_section" id="nav2">
			<view class="e_header flex_row_between_center">
				<view class="left flex_row_start_end">
					<text class="tit">{{$L('商品评价')}}</text>
					<text class="e_num"
						v-if="goodsCommentsInfo && goodsCommentsInfo.commentsCount">({{goodsCommentsInfo.commentsCount}})</text>
					<text class="e_rate"
						v-if="goodsCommentsInfo && goodsCommentsInfo.highPercent">{{goodsCommentsInfo.highPercent
						!=
						'0%' ? '好评率'+goodsCommentsInfo.highPercent : $L("暂无好评")}}</text>
				</view>
				<view class="right flex_row_end_center" @click="goEvaluation">
					<text class="view_more">{{$L('查看更多')}}</text>
					<image :src="imgUrl+'goods_detail/right_down.png'" mode="aspectFit" class="right_down"></image>
				</view>
			</view>
			<view class="eva_box flex_column_start_start"
				v-if="goodsCommentsInfo && goodsCommentsInfo.list && goodsCommentsInfo.list.length > 0">
				<view class="e_member_info flex_row_start_center">
					<image class="portrait" :src="goodsCommentsInfo.list[0].memberAvatar" mode="aspectFill">
					</image>
					<text class="name">{{filters.toAnonymous(goodsCommentsInfo.list[0].memberName)}}</text>
					<!-- 只读状态 -->
					<uni-rate :readonly="true" :value="goodsCommentsInfo.list[0].score" active-color="red"
						disabledColor="#ccc" :size="18" />
				</view>
				<text class="con" v-if="goodsCommentsInfo.list[0].content">{{goodsCommentsInfo.list[0].content}}</text>
				<text class="con" v-else>{{goodsCommentsInfo.list[0].score>=4?$L("好评"):(goodsCommentsInfo.list[0].score
					<2?$L("差评"):$L("中评"))}}</text>
			</view>
		</view>
		<!-- 评价end -->
		<!-- 店铺 start -->
		<view class="shop">
			<view class="shop_des" @click="goShopHome()">
				<view class="shop_des_image">
					<image :src="storeInf.storeLogo" mode="aspectFit" class=""></image>
				</view>
				<view class="shop_des_con">
					<view class="shop_con_title">{{storeInf.storeName}}</view>
					<view class="shop_con_type">
						<view class="shop_type" v-if="storeInf.isOwnStore == 1">{{$L('自营')}}</view>
						<view class="shop_follow_num">
							{{storeInf.followNumber ? storeInf.followNumber : 0 }}{{$L('人关注')}}
						</view>
					</view>
				</view>
			</view>
			<view class="shop_des_list">
				<view class="shop_des_pre">
					<text>{{$L('描述相符')}}</text>
					<text>{{filters.toFixNum(storeInf.descriptionScore,1)}}{{$L('分')}}</text>
					<image
						:src="storeInf.descriptionScore > 4 ? imgUrl + 'goods_detail/high.png' : storeInf.descriptionScore < 2 ? imgUrl + 'goods_detail/low.png' : imgUrl + 'goods_detail/middle.png'"
						mode="aspectFit"></image>
				</view>
				<view class="shop_des_pre">
					<text>{{$L('服务态度')}}</text>
					<text>{{filters.toFixNum(storeInf.serviceScore,1)}}{{$L('分')}}</text>
					<image
						:src="storeInf.serviceScore > 4 ? imgUrl + 'goods_detail/high.png' : storeInf.serviceScore < 2 ? imgUrl + 'goods_detail/low.png' : imgUrl + 'goods_detail/middle.png'"
						mode="aspectFit"></image>
				</view>
				<view class="shop_des_pre">
					<text>{{$L('发货速度')}}</text>
					<text>{{filters.toFixNum(storeInf.deliverScore,1)}}{{$L('分')}}</text>
					<image
						:src="storeInf.deliverScore > 4 ? imgUrl + 'goods_detail/high.png' : storeInf.deliverScore < 2 ? imgUrl + 'goods_detail/low.png' : imgUrl + 'goods_detail/middle.png'"
						mode="aspectFit"></image>
				</view>
			</view>
			<view class="shop_links">
				<image :src="imgUrl + 'goods_detail/contact_service.png'" mode="aspectFit" @click="toKefu"></image>
				<image :src="imgUrl + 'goods_detail/go_store.png'" mode="aspectFit" @click="goShopHome()"></image>
			</view>
		</view>
		<!-- 店铺 end -->

		<!-- 店铺推荐 start-->
		<view class="store_recommend" id="nav3" v-if="recommendedList && recommendedList.length > 0">
			<view class="store_recommend_top">
				<view class="store_recommend_title">{{$L('店铺推荐')}}</view>
				<!-- <view class="store_recommend_more" @click="toStoreGoodList()">
					<text>查看更多</text>
					<image :src="imgUrl+'goods_detail/right_down_red.png'" mode="aspectFit" class="right_down"></image>
				</view> -->
			</view>
			<view class="store_recommend_list">
				<view class="store_recommend_pre" v-for="(item,index) in recommendedList" :key="index"
					@click="goProductDetail(item.defaultProductId)" v-if="index < 6">
					<view class="store_reco_pre_image">
						<!-- <coverImage :src="item.goodsImage" width='223' height='223'></coverImage> -->
						<view class="image" :style="'background-image:url('+item.goodsImage+')'"></view>
						<view class="store_reco_pre_price">
							<text class="unit">¥</text>
							<text class="price_int">{{$getPartNumber(item.goodsPrice,'int')}}</text>
							<text class="price_decimal">{{$getPartNumber(item.goodsPrice,'decimal')}}</text>
						</view>
					</view>
					<view class="store_reco_pre_name">{{item.goodsName}}</view>
				</view>
			</view>
		</view>
		<!-- 店铺推荐 end -->

		<!-- 规格参数 start -->
		<view class="spec_param" v-if="goodsParameterList && goodsParameterList.length > 0">
			<view class="spec_param_title">
				<text>{{$L('规格参数')}}</text>
				<view class="image" :style="'background-image:url('+imgUrl+'goods_detail/spec_param_bg.png)'">
				</view>
			</view>
			<view class="spec_param_list" :class="{open_param:openGoodsParam}">
				<view class="spec_param_pre" v-for="(item,index) in goodsParameterList">
					<view>{{item.parameterName}}</view>
					<view>{{item.parameterValue}}</view>
				</view>
			</view>
			<view class="spec_param_fold" @click="handleGoodsParam" v-if="goodsParameterList.length > 5">
				<text>{{openGoodsParam ? $L("收起") :$L("展开")}}</text>
				<image :src="openGoodsParam ? imgUrl + 'goods_detail/up.png' : imgUrl + 'goods_detail/down.png'"
					mode="aspectFit"></image>
			</view>
		</view>
		<!-- 规格参数 end -->

		<view class="detail-desc" id="nav4">
			<view class="detail-desc_title">
				<text>{{$L('商品详情')}}</text>
				<view class="image" :style="'background-image:url('+imgUrl+'goods_detail/spec_param_bg.png)'">
				</view>
				</image>
			</view>
			<jyf-parser :pHidden="false" :isAll="true" :html="goodsData.goodsDetails" ref="description"></jyf-parser>
			<view class="bottom_block"/>
		</view>

		<!-- 底部操作菜单 -->
		<view class="page_bottom">
			<view class="p_b_btn" @click="goShopHome()">
				<image :src="imgUrl + 'goods_detail/store.png'" mode="aspectFit"></image>
				<text class="show_text">{{$L('店铺')}}</text>
			</view>
			<view url="/pages/index/index" open-type="switchTab" @click="toKefu" class="p_b_btn">
				<image :src="imgUrl + 'goods_detail/service.png'" mode="aspectFit" class="service_img"></image>
				<text class="show_text">{{$L('客服')}}</text>
			</view>
			<navigator url="/pages/cart/cart" open-type="switchTab" class="p_b_btn">
				<image :src="imgUrl + 'goods_detail/cart.png'" mode="aspectFit" class="cart_img"></image>
				<text class="show_text">{{$L('购物车')}}</text>
				<text class="cart_num" v-if="cartNumShow && cartNum > 0">{{cartNum}}</text>
			</navigator>
			<!-- 活动商品 start -->
			<block v-if="valiInfo(secKillInfo)&& secKillInfo.state == 2">
				<!-- 秒杀活动  立即秒杀 已抢完 start -->
				<view class="action_btn_group">
					<view class="action_btn instant_second_kill flex_row_center_center" @click="showSpecModel"
						v-if="(isChoice == 'default' && defaultProduct && defaultProduct.productStock!=0) || (isChoice == 'choice' && choiceSpecDes && choiceSpecDes.productStock != 0)">
						{{$L('立即秒杀')}}
					</view>
					<view class="action_btn seckill_finished flex_row_center_center" @click="showSpecModel" v-else>
						{{$L('已抢完')}}
					</view>
				</view>
				<!-- 秒杀活动 立即秒杀 已抢完 end -->
			</block>
			<block v-else-if="valiInfo(preSellInfo)&&preSellInfo.pre_run!=1">
				<!-- 预售活动 立即付定金，全款支付 start -->
				<view class="action_btn_group">
					<block
						v-if="(isChoice == 'default' && defaultProduct && defaultProduct.productStock==0) || (isChoice == 'choice' && choiceSpecDes && choiceSpecDes.productStock == 0)">
						<view class="action_btn not_stock flex_row_center_center" @click="showSpecModel">
							{{$L('库存不足')}}
						</view>
					</block>
					<block v-else>
						<view class="action_btn preSale_btn_deposit flex_row_center_center" @click="showSpecModel">
							{{preSellInfo.type==1?'立即付定金':'立即支付'}}
						</view>
						<!-- {{preSellInfo.type==1?`￥${preSellInfo.firstMoney}`:''}} -->
					</block>
				</view>
			</block>

			<block v-else-if="valiInfo(ladderInfo)&&ladderInfo.ladder_run==2">
				<view class="action_btn_group">
					<view class="action_btn not_stock flex_row_center_center" @click="showSpecModel"
						v-if="(isChoice == 'default' && defaultProduct && defaultProduct.productStock==0) || (isChoice == 'choice' && choiceSpecDes && choiceSpecDes.productStock == 0)">
						{{$L('库存不足')}}
					</view>
					<view @tap.stop="showSpecModel" class="ladder_btn" data-type="jtt" v-else>{{$L('立即付定金')}}
					</view>
				</view>
			</block>

			<block v-else-if="valiInfo(pinInfo)&&pinInfo.state==1">
				<block
					v-if="(isChoice == 'default' && defaultProduct && defaultProduct.productStock==0) || (isChoice == 'choice' && choiceSpecDes && choiceSpecDes.productStock == 0)">
					<view class="action_btn_group">
						<view class="action_btn not_stock flex_row_center_center" @click="showSpecModel">
							{{$L('库存不足')}}
						</view>
					</view>
				</block>
				<block v-else>
					<view class="pinGroup_btn">
						<view class="group_shopping_alone" @tap="showSpecModel('pinAlone')" data-alonePin="true">
							<view class="group_alone_price">￥{{pinInfo.productPrice}}</view>
							<view class="group_alone_title">单独买</view>
						</view>
						<view class="go_group" @tap="showSpecModel('pinLeague')" data-alonePin="false">
							<view class="go_group_price">
								￥{{pinInfo.leaderPrice?pinInfo.leaderPrice:pinInfo.spellPrice}}
							</view>
							<view class="go_group_title">{{'去开团'}}</view>
						</view>
					</view>
				</block>
			</block>

			<!-- 活动商品 end -->

			<!-- 正常商品 start -->
			<block v-else>
				<!--商品已下架 start -->
				<view class="action_btn_group" v-if="goodsData.state != 3">
					<view class="action_btn not_stock flex_row_center_center">{{$L('商品已下架')}}</view>
				</view>
				<!--商品已下架 end -->
				<!--库存不足start -->
				<view class="action_btn_group"
					v-else-if="(isChoice == 'default' && defaultProduct && defaultProduct.productStock==0) || (isChoice == 'choice' && choiceSpecDes && choiceSpecDes.productStock == 0)">
					<view class="action_btn not_stock flex_row_center_center" @click="showSpecModel">{{$L('库存不足')}}
					</view>
				</view>
				<!--库存不足 end -->
				<!-- 普通商品 start -->
				<view class="action_btn_group" v-else>
					<block v-if="goodsData.isVirtualGoods==1">
						<view class="action_btn add_cart_btn flex_row_center_center" @click="showSpecModel('add')">
							{{$L('加入购物车')}}
						</view>
						<view class="action_btn buy_now_btn flex_row_center_center" @click="showSpecModel('buy')">
							{{$L('立即购买')}}
						</view>
					</block>
					<block v-else>
						<view class="action_btn virtual_buy flex_row_center_center" @click="showSpecModel('buy')">
							{{$L('立即购买')}}
						</view>
					</block>

				</view>
				<!-- 普通商品 end -->
			</block>
			<!-- 正常商品 end -->
		</view>

		<!-- 分享 -->
		<share ref="share" :contentHeight="580" :shareList="shareList"></share>


		<!-- 分享弹框 start -->
		<view class="share_model" v-if="share_model" @touchmove.stop.prevent="moveHandle">
			<view class="share_model_list">
				<!-- #ifdef H5 -->
				<view class="share_model_pre" @tap.stop="sldShareBrower(1)" v-if="isWeiXinBrower">
					<image :src="imgUrl+'goods_detail/wx_share.png'" mode="aspectFit"></image>
					<text>{{$L('微信好友')}}</text>
				</view>
				<view class="share_model_pre" @tap.stop="sldShareBrower(2)" v-if="isWeiXinBrower">
					<image :src="imgUrl+'goods_detail/wechat_moments.png'" mode="aspectFit"></image>
					<text>{{$L('微信朋友圈')}}</text>
				</view>
				<!-- #endif -->
				<!-- #ifdef MP-WEIXIN -->
				<button class="share_model_pre" open-type="share" @click="showShareMenu">
					<image :src="imgUrl+'goods_detail/wx_share.png'" mode="aspectFit"></image>
					<text>{{$L('微信好友')}}</text>
				</button>

				<!-- #endif -->
				<!-- #ifdef APP-PLUS -->
				<view class="share_model_pre" @tap.stop="sldShare(0,'WXSceneSession')">
					<image :src="imgUrl+'goods_detail/wx_share.png'" mode="aspectFit"></image>
					<text>{{$L('微信好友')}}</text>
				</view>
				<view class="share_model_pre" @tap.stop="sldShare(0,'WXSenceTimeline')">
					<image :src="imgUrl+'goods_detail/wechat_moments.png'" mode="aspectFit"></image>
					<text>{{$L('微信朋友圈')}}</text>
				</view>
				<!-- #endif -->
				<view class="share_model_pre">
					<image :src="imgUrl+'goods_detail/poster.png'" mode="aspectFit" @click="getPoster"></image>
					<text>{{$L('生成海报')}}</text>
				</view>
			</view>
			<view class="share_model_close" @click="closeShareModel">
				<image :src="imgUrl+'goods_detail/share_close.png'" mode="aspectFit"></image>
			</view>
		</view>
		<!-- 分享弹框 end -->



		<!-- 生成海报  start-->
		<view class="poster" v-if="poster" @touchmove.stop.prevent="moveHandle">
			<!-- 分享海报弹框 start -->
			<view class="share_model" :class="{poster_share_model:poster}">
				<!-- #ifndef H5 -->
				<image :src="sharePoster" mode="aspectFit" class="poster_image" @tap="prevImg" @longtap.stop="downloadPoster"></image>
				<!-- #endif -->
				<!-- #ifdef H5 -->
				<block v-if="isWeiXinBrower">
					<image :src="sharePoster" mode="aspectFit" class="poster_image" @tap="prevImg" @longtap.stop="downloadPoster"></image>
				</block>
				<block v-else>
					<canvas class="poster_image" @tap="prevImg">
						<img :src="sharePoster" width="100%" height="100%" style="-webkit-touch-callout: default;" />
					</canvas>
				</block>
				<!-- #endif -->
				<view class="share_model_list">
					<!-- #ifdef MP -->
					<view class="share_model_pre" @tap.stop="downloadPoster">
						<image :src="imgUrl+'goods_detail/poster.png'" mode="aspectFit"></image>
						<text>{{$L('下载海报')}}</text>
					</view>
					<!-- #endif -->
					<!-- #ifdef APP-PLUS -->
					<view class="share_model_pre" @tap.stop="saveImgAPP">
						<image :src="imgUrl+'goods_detail/poster.png'" mode="aspectFit"></image>
						<text>{{$L('保存海报')}}</text>
					</view>
					<view class="share_model_pre" @tap.stop="sldShare(2,'WXSceneSession')">
						<image :src="imgUrl+'goods_detail/wx_share.png'" mode="aspectFit"></image>
						<text>{{$L('微信好友')}}</text>
					</view>
					<view class="share_model_pre" @tap.stop="sldShare(2,'WXSenceTimeline')">
						<image :src="imgUrl+'goods_detail/wechat_moments.png'" mode="aspectFit"></image>
						<text>{{$L('微信朋友圈')}}</text>
					</view>
					<!-- #endif -->
				</view>
				<!-- #ifndef H5 -->
				<view class="share_model_close" @click="closeShareModel">
					<image :src="imgUrl+'goods_detail/share_close.png'" mode="aspectFit"></image>
				</view>
				<!-- #endif -->
				<!-- #ifdef H5 -->
				<image :src="imgUrl+'goods_detail/poster_share.png'" mode="aspectFit" class="poster_share_img"
					@longtap.stop="downloadPoster"></image>
				<image :src="imgUrl+'goods_detail/poster_share_close.png'" mode="aspectFit" class="poster_share_close"
					@click.stop="closePoster"></image>
				<!-- #endif -->
			</view>
			<!-- 分享海报弹框 end -->

		</view>
		<!-- 生成海报  end-->
		<!-- 微信浏览器分享提示  start-->
		<view class="wx_brower_share_mask" v-if="showWeiXinBrowerTip">
			<view class="wx_brower_share_top_wrap">
				<image :src="imgUrl+'wx_share_tip.png'" mode="widthFix" @tap="closeShareModel"
					class="wx_brower_share_img"></image>
			</view>
		</view>
		<!-- 微信浏览器分享提示  end-->
		<!-- 规格弹框 start -->
		<uni-popup class="spec_model" ref="specModel" type="bottom">
			<view class="spec_model_con">
				<view class="spec_model_content">
					<view class="spec_model_top">
						<view class="spec_model_goods">
							<view class="spec_goods_image"
								v-if="defaultProduct && defaultProduct.goodsPics && defaultProduct.goodsPics[0] && isChoice == 'default'">
								<image :src="defaultProduct.goodsPics[0]" mode="aspectFit"></image>
							</view>
							<view class="spec_goods_image"
								v-else-if="choiceSpecDes && choiceSpecDes.goodsPics && choiceSpecDes.goodsPics[0] && isChoice == 'choice'">
								<image :src="choiceSpecDes.goodsPics[0]" mode="aspectFit"></image>
							</view>
							<view class="spec_goods_right">
								<view class="spec_goods_price_con">
									<view class="spec_prices">
										<!-- 立即秒杀进行中 start -->
										<view class="spec_goods_price" v-if="secKillInfo && secKillInfo.state == 2">
											<text>￥</text>
											<text>{{$getPartNumber(secKillInfo.seckillPrice,'int')}}</text>
											<text>{{$getPartNumber(secKillInfo.seckillPrice,'decimal')}}</text>
										</view>
										<!-- 立即秒杀进行中 end -->

										<!-- 预售 start -->
										<!-- 立即付定金 start -->
										<view class="spec_goods_price"
											v-else-if="preSellInfo && preSellInfo.type == 1&&preSellInfo.pre_run==2">
											<text>￥</text>
											<text>{{$getPartNumber(preSellInfo.firstMoney,'int')}}</text>
											<text>{{$getPartNumber(preSellInfo.firstMoney,'decimal')}}</text>
										</view>
										<!-- 立即付定金 end -->
										<!-- 全款 start -->
										<view class="spec_goods_price"
											v-else-if="preSellInfo && preSellInfo.type == 2&&preSellInfo.pre_run==2">
											<text>￥</text>
											<text>{{$getPartNumber(preSellInfo.presellPrice,'int')}}</text>
											<text>{{$getPartNumber(preSellInfo.presellPrice,'decimal')}}</text>
										</view>
										<!-- 全款 end -->
										<!-- 预售 end -->

										<!-- 阶梯团start -->
										<view class="spec_goods_price" v-else-if="JSON.stringify(ladderInfo)!='{}'">
											<text>￥</text>
											<text>{{$getPartNumber(ladderInfo.advanceDeposit,'int')}}</text>
											<text>{{$getPartNumber(ladderInfo.advanceDeposit,'decimal')}}</text>
										</view>
										<!-- 阶梯团end -->

										<!-- 拼团start -->
										<view class="spec_goods_price"
											v-else-if="JSON.stringify(pinInfo)!='{}'&&pinButState">
											<text>￥</text>
											<text>{{$getPartNumber(pinInfo.leaderPrice?(pinButState==3?pinInfo.spellPrice:pinInfo.leaderPrice):pinInfo.spellPrice,'int')}}</text>
											<text>{{$getPartNumber(pinInfo.leaderPrice?(pinButState==3?pinInfo.spellPrice:pinInfo.leaderPrice):pinInfo.spellPrice,'decimal')}}</text>
										</view>
										<!-- 拼团end -->

										<!-- 正常商品start -->
										<view class="spec_goods_price"
											v-else-if="isChoice == 'default' && defaultProduct.productPrice">
											<text>￥</text>
											<text>{{$getPartNumber(defaultProduct.productPrice,'int')}}</text>
											<text>{{$getPartNumber(defaultProduct.productPrice,'decimal')}}</text>
										</view>
										<view class="spec_goods_price" v-else-if="choiceSpecDes.productPrice">
											<text>￥</text>
											<text>{{$getPartNumber(choiceSpecDes.productPrice,'int')}}</text>
											<text>{{$getPartNumber(choiceSpecDes.productPrice,'decimal')}}</text>
										</view>
										<!-- 正常商品end -->
									</view>
									<!-- 活动标识 start -->
									<view class="sec_kill_tips"
										v-if="secKillInfo && (secKillInfo.state == 2 || secKillInfo.state == 1)">
										{{$L('限时秒杀')}}
									</view>
									<view class="pre_sale_tips"
										v-if="JSON.stringify(preSellInfo)!='{}'&&preSellInfo.pre_run==2">
										{{$L("预售")}}
									</view>
									<text class="ladder_regiment_tips"
										v-if="JSON.stringify(ladderInfo)!='{}'">{{$L('阶梯团')}}</text>
									<text class="pin_tips"
										v-if="JSON.stringify(pinInfo)!='{}'&&pinButState">{{$L('拼团')}}</text>
									<!-- 活动标识 end -->
								</view>
								<!-- 已下架商品 start -->
								<view class="spec_goods_des" v-if="goodsData.state!=3">
									{{$L('商品已下架')}}
								</view>
								<!-- 已下架商品 end -->
								<!-- 普通商品 start -->
								<view class="spec_goods_des" v-else>
									{{$L('已选规格')}}：
									<text v-if="defaultProduct.getSpecValues || choiceSpecDes.getSpecValues">{{isChoice
										== 'default' ? defaultProduct.getSpecValues :
										choiceSpecDes.getSpecValues}}</text>
									<text v-else>{{$L('默认')}}</text>
								</view>
								<!-- 普通商品 end -->
							</view>
						</view>
						<image :src="imgUrl+'goods_detail/close.png'" mode="aspectFit" class="close_spec"
							@click="closeSpecModel"></image>
					</view>
					<scroll-view scroll-y="true" class="spec_content">
						<view class="spec_list" v-if="specs && specs.length > 0">
							<view class="spec_list_pre" v-for="(item,index) in specs" :key="index">
								<view class="spec_list_pre_name">{{item.specName}}</view>
								<block v-if="item && item.specValueList && item.specValueList.length > 0"
									v-for="(item1,index1) in item.specValueList" :key='index1'>
									<!-- checkState : 1-选中，2-可选，3-禁用 -->
									<view class="spec_list_pre_desc"
										:class="{spec_list_pre_desc_disabled:item1.checkState == '3'}"
										v-if="item1.checkState == '3'">
										<view class="spec_list_pre_con">
											<image :src="item1.image" mode="aspectFit" v-if="item1.image">
											</image>
											<text>{{item1.specValue}}</text>
										</view>
									</view>
									<view class="spec_list_pre_desc"
										:class="{spec_list_pre_desc_active:item1.checkState == '1'}"
										@click="selectSpecVal('choice',item.specId,item1.specValueId)" v-else>
										<view class="spec_list_pre_con">
											<image :src="item1.image" mode="aspectFit" v-if="item1.image">
											</image>
											<text>{{item1.specValue}}</text>
										</view>
									</view>
								</block>
							</view>
						</view>
						<view class="spec_num">
							<view class="spec_num_left">
								{{$L('购买数量')}}
							</view>
							<view class="spec_num_right">
								<text @click="editNum('reduce')" :class="{no_edit:currentSpecNum==1}">-</text>
								<input type="number" v-model="currentSpecNum" @blur="editNum('edit',$event)"
									cursor-spacing="0" :cursor="currentSpecNum.toString().length" />
								<text @click="editNum('add')" :class="{no_edit:noEdit}">+</text>
							</view>
						</view>
					</scroll-view>
				</view>
				<!-- 规格弹框的底部按钮 start -->
				<!-- 秒杀商品start -->
				<block v-if="JSON.stringify(secKillInfo) != '{}'  && secKillInfo.state == 2 ">
					<!-- 秒杀已抢完 start -->
					<view class="spec_btn"
						v-if="(isChoice == 'default' && defaultProduct && defaultProduct.productStock==0) || (isChoice == 'choice' && choiceSpecDes && choiceSpecDes.productStock == 0)">
						<button class="spec_not_stock spec_btn_only">{{$L('已抢完')}}</button>
					</view>
					<!-- 秒杀已抢完 end -->
					<!--立即秒杀 start -->
					<view class="spec_btn" @click="buy" v-else>
						<button class="spec_seckill_btn spec_btn_only">{{$L('立即秒杀')}}</button>
					</view>
					<!--立即秒杀 end -->
				</block>
				<!-- 秒杀商品end -->
				<!-- 预售活动 start -->
				<block v-else-if="valiInfo(preSellInfo)&&preSellInfo.pre_run!=1">
					<view class="spec_btn"
						v-if="(isChoice == 'default' && defaultProduct && defaultProduct.productStock==0) || (isChoice == 'choice' && choiceSpecDes && choiceSpecDes.productStock == 0)">
						<button class="spec_not_stock spec_btn_only">{{$L('库存不足')}}</button>
					</view>
					<!--立即付定金/全款支付 start -->
					<view class="spec_btn" v-else @click="buy">
						<button
							:class="{spec_deposit_btn:preSellInfo.type == 1,spec_seckill_btn:preSellInfo.type == 2,spec_btn_only:true}">{{preSellInfo.type
							== 1?`${$L("立即付定金")}`:$L("立即购买")}}</button>
						<!-- {{preSellInfo.type==1?`￥${preSellInfo.firstMoney}`:''}} -->
					</view>
					<!--立即付定金/全款支付 end -->
				</block>
				<!-- 预售活动 end -->
				<!-- 阶梯团活动start -->
				<block v-else-if="valiInfo(ladderInfo)&&ladderInfo.ladder_run==2">
					<view class="spec_btn"
						v-if="(isChoice == 'default' && defaultProduct && defaultProduct.productStock==0) || (isChoice == 'choice' && choiceSpecDes && choiceSpecDes.productStock == 0)">
						<button class="spec_not_stock spec_btn_only">{{$L('库存不足')}}</button>
					</view>
					<view class="spec_btn" v-else>
						<view @click="buy" class="specifications_btn2">
							<text>{{$L('立即付定金')}}</text>
						</view>
					</view>
				</block>
				<!-- 阶梯团活动end -->
				<!-- 拼团活动start -->
				<block v-else-if="JSON.stringify(pinInfo)!='{}'&&pinInfo.state == 1">
					<view class="spec_btn"
						v-if="(isChoice == 'default' && defaultProduct && defaultProduct.productStock==0) || (isChoice == 'choice' && choiceSpecDes && choiceSpecDes.productStock == 0)">
						<button class="spec_not_stock spec_btn_only">{{$L('库存不足')}}</button>
					</view>
					<block v-else>
						<view class="spec_btn" v-if="!pinButState" @click="buy('aloneBuy')">
							<button class="specifications_bottom_btn3">
								<text>{{$L("单独买")}}</text>
								<text>(￥{{pinInfo.productPrice}})</text>
							</button>
						</view>
						<view class="spec_btn" v-if="pinButState==1" @click="buy">
							<button class="specifications_bottom_btn4">
								<text>{{$L("去开团")}}</text>
								<text>￥{{pinInfo.leaderIsPromotion==1?pinInfo.leaderPrice:pinInfo.spellPrice}}</text>
							</button>
						</view>
						<view class="spec_btn" v-if="pinButState==2">
							<view class="specification_add" @tap="buy('aloneBuy')">
								<text>￥{{pinInfo.productPrice}}</text>
								<text>{{$L("单独买")}}</text>
							</view>
							<view class="specification_buy" @tap="buy">
								<text>￥{{pinInfo.leaderIsPromotion==1?pinInfo.leaderPrice:pinInfo.spellPrice}}</text>
								<text>{{$L("去开团")}}</text>
							</view>
						</view>
						<view class="spec_btn" v-if="pinButState==3" @click="buy">
							<button class="specifications_bottom_btn4">
								<text>{{$L("去参团")}}</text>
								<text>(￥{{pinInfo.spellPrice}})</text>
							</button>
						</view>
					</block>

				</block>
				<!-- 拼团活动end -->
				<block v-else>
					<!-- 商品下架 start -->
					<text>{{showSpecModelType}}</text>
					<view class="spec_btn" v-if="goodsData.state!=3">
						<button class="spec_not_stock spec_btn_only">{{$L('商品已下架')}}</button>
					</view>
					<!-- 商品下架 end -->
					<!--库存不足 start -->
					<view class="spec_btn"
						v-else-if="(isChoice == 'default' && defaultProduct && defaultProduct.productStock==0) || (isChoice == 'choice' && choiceSpecDes && choiceSpecDes.productStock == 0)">
						<button class="spec_not_stock spec_btn_only">{{$L('库存不足')}}</button>
					</view>
					<!--库存不足 end -->
					<!-- 普通商品 start-->
					<block v-else>
						<view class="spec_btn" v-if="showSpecModelType == ''">
							<text class="spec_add_cart_btn" @click="addCart">{{$L('加入购物车')}}</text>
							<text class="spec_buy_btn" @click="buy">{{$L('立即购买')}}</text>
						</view>
						<view class="spec_btn" v-if="showSpecModelType == 'add'">
							<text class="spec_add_cart_btn spec_btn_only" @click="addCart">{{$L('加入购物车')}}</text>
						</view>
						<view class="spec_btn" v-if="showSpecModelType == 'buy'">
							<text class="spec_buy_btn spec_btn_only" @click="buy">{{$L('立即购买')}}</text>
						</view>
					</block>

					<!-- 普通商品 end-->
				</block>

			</view>
			<!-- 规格弹框的底部按钮 end -->
		</uni-popup>
		<!-- 规格弹框 end -->

		<uni-popup ref="addressModel" type="bottom" @touchmove.stop.prevent="moveHandle">
			<view class="address_list_con">
				<view class="address_top">
					<view class="back_view">
						<image src="" mode="aspectFit"></image>
					</view>
					<view class="address_top_text">配送至</view>
					<image :src="imgUrl+'goods_detail/close.png'" mode="aspectFit" @click="addressClose"></image>
				</view>
				<scroll-view scroll-y="true" class="address_list" @touchmove.stop.prevent="moveHandle">
					<view v-for="(item, index) in addressList" :key="index" @click="checkAddress(item)"
						:class="{'list':true}">
						<view class="wrapper flex_row_start_center">
							<image v-if="sourceId==item.addressId" :src="imgUrl+'location_on.png'"></image>
							<image :src="imgUrl+'location.png'" v-else></image>
							<image src="" mode="aspectFit" v-else></image>
							<view class="flex_column_start_start">
								<view class="address-box">
									<text
										:class="{address:true,address_on:sourceId==item.addressId}">{{item.addressAll}}
										{{item.detailAddress}}</text>
								</view>
							</view>
						</view>
						<view class="wrapper_right">
							<image v-if="sourceId==item.addressId" :src="imgUrl+'checked.png'" class="checkedIcon">
							</image>
						</view>
					</view>

				</scroll-view>
				<view class="other_address">
					<view class="other_btn" @click="chooseArea">选择其他地址</view>
				</view>
			</view>

		</uni-popup>

		<uni-popup ref="popLogin" type="dialog">
			<uni-popup-dialog type="input" title="提示" content="请登录" :duration="2000" @confirm="confirmLogin">
			</uni-popup-dialog>
		</uni-popup>

		<selectAddress ref='selectAddress' :sel_data='selAddressData' @selectAddress="successSelectAddress"
			:isBack="isBack" @backToAdd="backToAdd">
		</selectAddress>

	</view>
</template>
<script>
	import filters from "../../utils/filter.js"
	import selectAddress from '@/components/yixuan-selectAddress/yixuan-selectAddress';
	import share from '@/components/share';
	import uniPopup from '@/components/uni-popup/uni-popup.vue'
	import uniPopupMessage from '@/components/uni-popup/uni-popup-message.vue'
	import uniPopupDialog from '@/components/uni-popup/uni-popup-dialog.vue'
	import uniRate from '@/components/uni-rate/uni-rate.vue'
	import jyfParser from "@/components/jyf-parser/jyf-parser";
	import uniSwiperDot from "@/components/uni-swiper-dot/uni-swiper-dot.vue";
	import pinInfo from '@/components/activityDetail/pinGroup/pinInfo.vue'
	import pinGroupList from '@/components/activityDetail/pinGroup/pinGroupList.vue'
	import preInfo from '@/components/activityDetail/preSale/preInfo.vue'
	import ladderInfo from '@/components/activityDetail/ladderGroup/ladderInfo.vue'
	import ladderProgress from '@/components/activityDetail/ladderGroup/ladderProgress.vue'
	import gDRank from '../rank/components/gD_rank.vue'
	import { quillEscapeToHtml } from '@/utils/common.js';
	import {
		mapState,
		mapMutations
	} from 'vuex';
	import {
		weBtoa
	} from '@/utils/base.js'
	export default {
		components: {
			selectAddress,
			share,
			uniPopup,
			uniPopupMessage,
			uniPopupDialog,
			jyfParser,
			uniSwiperDot,
			pinInfo,
			pinGroupList,
			preInfo,
			ladderInfo,
			ladderProgress,
			uniRate,
			gDRank,

		},
		data() {
			return {
				filters,
				imgUrl: getApp().globalData.imgUrl,
				dialogTitle: '温馨提示!',
				dialogCon: '您需要先登录哦～',
				goodsData: {},
				specSelected: [],
				statistics: {}, //商品评价数据
				shareList: [],
				selAddressData: [],
				addressAll: '请选择所在地区',
				addressList: [], //地址列表
				goodsId: '', //商品id
				curFreight: '', //当前运费
				currentSelId: '', //默认选中第一个地址
				share_model: false, //分享弹框
				isNavShow: false, //是否显示导航
				navList: [{
						text: '商品',
						id: 0,
					},
					{
						text: '评价',
						id: 1
					},
					{
						text: '推荐',
						id: 2
					},
					{
						text: '详情',
						id: 3
					}
				],
				navListNoRecommend: [{
						text: '商品',
						id: 0,
					},
					{
						text: '评价',
						id: 1
					},
					{
						text: '详情',
						id: 3
					}
				],
				currentNav: 0, //当前点击的默认是第一项
				nav1ScrollTop: 0, //商品模块距离顶部的距离
				nav2ScrollTop: 0, //评价模块距离顶部的距离
				nav3ScrollTop: 0, //推荐模块距离顶部的距离
				nav4ScrollTop: 0, //详情模块距离顶部的距离
				codeImg: '', //海报图片
				poster: false, //生成海报
				specModel: false, //规格弹框
				currentSpecNum: 1, //当前规格弹框中的购买数量
				couponList: [], //优惠券列表
				defaultProduct: {}, //默认货品信息
				specs: [], //商品规格列表
				choiceSpecDes: {}, //选择规格之后,要修改的数据信息
				isChoice: 'default', //是默认选中的,还是点击选择规格之后的  default:默认  choice:选择
				productId: '', //货品id
				sharePoster: '',
				isWeiXinBrower: false, //是否微信浏览器
				showWeiXinBrowerTip: false, //微信浏览器分享的提示操作
				source: '', //来源，终端类型，1、pc 2、app；3、公众号或微信内部浏览器；4、小程序
				mode: 'nav', //轮播图的显示样式类型
				current: 0, //轮播图默认显示第一页
				showSpecModelType: '', //规格弹框的底部按钮的显示类型	默认：加入购物车及立即购买都有	add：加入购物车	buy：立即购买		nosocket库存不足	offshelf商品下架
				noOpcity: false, //顶部导航的背景是否有透明度，轮播图以上有，以下没有
				isLoading: false,
				cartNum: 0, //购物车数量
				cartNumShow: false, //购物车数量的角标是否显示
				storeInf: {}, //店铺信息
				goodsCommentsInfo: {}, //评价信息
				recommendedList: [], //店铺推荐列表
				deliverInfo: {}, //发货地及运费信息
				transparent_mask: false, //透明遮罩蒙层
				tips_show: false, //分享链接弹框
				tips: [{
						tips_img: getApp().globalData.imgUrl + 'goods_detail/home.png',
						tips_name: '首页',
						tips_link: '/pages/index/index',
						type: 'switchTab'
					},
					{
						tips_img: getApp().globalData.imgUrl + 'goods_detail/go_cart.png',
						tips_name: '购物车',
						tips_link: '/pages/cart/cart',
						type: 'switchTab'
					},
					{
						tips_img: getApp().globalData.imgUrl + 'goods_detail/preson.png',
						tips_name: '个人中心',
						tips_link: '/pages/user/user',
						type: 'switchTab'
					}
				],
				storeInf: {}, //店铺信息
				goodsParameterList: [], //规格参数列表
				openGoodsParam: false, //规格参数超出5行，点击展开，收起
				pageCurrent: 1, //优惠券列表，页
				pageSize: 10, //优惠券列表 每页的条数
				goReceiveBg: getApp().globalData.imgUrl + 'coupon/coupon_pre_bg.png', //立即领取背景
				finishReceiveBg: getApp().globalData.imgUrl + 'coupon/finishReceiveBg.png', //已抢完背景
				hasReceiveBg: getApp().globalData.imgUrl + 'coupon/hasReceiveBg.png', //已领取背景
				fullDisList: [], //满优惠列表
				promotionId: '', //活动id
				secKillInfo: {}, //秒杀活动详情信息
				secKillDay: '00', //秒杀活动倒计时 天
				secKillHr: '00', //秒杀活动倒计时 时
				secKillMin: '00', //秒杀活动倒计时 分
				secKillSec: '00', //秒杀活动倒计时 秒
				preSellInfo: {}, // 预售商品详情信息
				noEdit: false, //不可编辑
				ladderInfo: {}, //阶梯团信息
				ladderDay: 0, //天
				ladderHour: 0, //时
				ladderMinute: 0, //分钟
				ladderSecond: 0, //秒
				ladderProcess: '', //阶梯团进度
				pinInfo: {}, //拼团信息
				spellTeamId: 0, //拼团团队Id
				pinButState: null, //拼团按钮状态,
				showState: 0, //当当前页面进入到下一个页面时，将此值置为1，上一个页面回退到当前页面时，再onShow里判断，防止onShow触发过多
				spreaderMemberId: 0, //专门的推手分享ID设置
				goodsVideo: '',
				showControls: true, //是否显示轮播角标
				playVFlag: false,
				address_list: [],
				curAddress: '',
				sourceId: '',
				selAddressData: [],
				isBack: true,
				dis: false,
				rankData: []
			};
		},
		computed: {
			...mapState(['hasLogin', 'userInfo', 'userCenterData']),
			activityState() {
				let {
					secKillInfo,
					ladderInfo,
					preSellInfo,
					pinInfo
				} = this
				return JSON.stringify(secKillInfo) != '{}' || JSON.stringify(ladderInfo) != '{}' || JSON.stringify(
					preSellInfo) != '{}' || JSON.stringify(pinInfo) != '{}'
			},
			actiState(){
				let now = new Date().getTime()
				switch(this.defaultProduct.promotionType){
					case 104:{
						return this.valiInfo(this.secKillInfo)&&this.secKillInfo.state==2
						break
					}
					case 103:{
						let st = new Date(this.preSellInfo.startTime).getTime()
						let et = new Date(this.preSellInfo.endTime).getTime()
						return this.valiInfo(this.preSellInfo)&&now>st&&et>now
						break
					}
					case 105:{
						let st = new Date(this.ladderInfo.startTime).getTime()
						let et = new Date(this.ladderInfo.endTime).getTime()
						return this.valiInfo(this.ladderInfo)&&now>st&&et>now
						break
					}
					case 102:{
						let st = new Date(this.pinInfo.startTime).getTime()
						let et = new Date(this.pinInfo.endTime).getTime()
						return this.valiInfo(this.pinInfo)&&now>st&&et>now
						break
					}
				}
			}
		},
		// 监听返回事件

		async onLoad(options) {
			uni.showLoading({
				title: '加载中！'
			})
			this.showState = 0
			this.productId = this.$Route.query.productId;
			this.goodsId = this.$Route.query.goodsId;
			if (options && options.scene) {
				let url = decodeURIComponent(options.scene);
				let url_param_array = url.split(',');
				this.productId = url_param_array[0];
				this.goodsId = url_param_array[1];
				this.spreaderMemberId = url_param_array[2] ? url_param_array[2] : 0
			}
			this.getGoodsDetail(this.productId);
			this.addLook(this.productId);

			//#ifdef MP-WEIXIN
			this.source = 4;
			//#endif
			// #ifdef MP-BAIDU
			this.source = 3;
			// #endif
			// #ifdef MP-ALIPAY
			this.source = 2;
			// #endif
			// #ifdef MP-TOUTIAO
			this.source = 1;
			// #endif


			// this.sharePoster = getApp().globalData.apiUrl + 'v3/goods/front/goods/share/sharePosters?productId=' + this
			// 	.productId +
			// 	'&source=' + this.source;
			if (this.$Route.query.videoId) {
				//更新视频商品点击量
				this.updateVideoClick(this.$Route.query.videoId, this.goodsId)
			}
			uni.getSystemInfo({
				success: (res) => {
					let clientHeight = res.windowHeight,
						clientWidth = res.windowWidth,
						rpxR = 750 / clientWidth;
					let calc = clientHeight * rpxR;
					this.winHeight = calc;
				}
			})
			// #ifdef H5
			this.isWeiXinBrower = this.$isWeiXinBrower();
			// #endif
			this.goTop(); //一键回到页面顶部
			//如果路由参数有推手ID,则是推手分享的商品，建立关系
			if (this.$Route.query.u && this.hasLogin) {
				this.spreaderMemberId = this.$Route.query.u
				this.estabTs()
			} else if (this.$Route.query.u && !this.hasLogin) {
				uni.setStorageSync('u', this.spreaderMemberId)
			}
			// #ifdef H5
			window.addEventListener('mousewheel', () => {
				this.dis = false
			}, false)
			// #endif

			this.getGoodsPoster()
		},
		onShow() {
			if (this.showState == 1) {
				this.getGoodsDetail(this.productId);
			}
		},
		onShareAppMessage: function() {
			return {
				title: this.goodsData.goodsName,
				path: '/standard/product/detail?productId=' + this.productId + '&goodsId=' + this.goodsId,
				imageUrl: this.goodsData.shareImage
			};
		},

		onShareTimeline: function() {
			return {
				title: this.goodsData.goodsName,
				path: 'productId=' + this.productId + '&goodsId=' + this.goodsId,
				imageUrl: this.goodsData.shareImage
			};
		},
		
			
		

		//页面滚动事件
		onPageScroll(res) {
			//监听滚动事件，获取滚动条的当前位置
			this.tips_show = false
			this.transparent_mask = false
			if (this.dis) {
				return
			}

			if (res.scrollTop > 50) {
				this.isNavShow = true
				this.noOpcity = Boolean(res.scrollTop > 350)
				if (res.scrollTop < this.nav2ScrollTop) {
					this.currentNav = 0;
				} else {
					if (this.recommendedList && this.recommendedList.length > 0) { //有推荐
						if (res.scrollTop >= this.nav2ScrollTop && res.scrollTop < this.nav3ScrollTop) {
							this.currentNav = 1
						} else if (res.scrollTop >= this.nav3ScrollTop && res.scrollTop < this.nav4ScrollTop) {
							this.currentNav = 2
						} else if (res.scrollTop >= this.nav4ScrollTop) {
							this.currentNav = 3;
						}
					} else { //无推荐
						if (res.scrollTop >= this.nav2ScrollTop && res.scrollTop < this.nav4ScrollTop) {
							this.currentNav = 1
						} else if (res.scrollTop >= this.nav4ScrollTop) {
							this.currentNav = 2
						}
					}
				}
			} else {
				this.isNavShow = false;
			}
		},
		methods: {
			...mapMutations(['saveChatBaseInfo']),
			//更新视频商品点击量
			updateVideoClick(videoId, goodsId) {
				let param = {}
				param.data = {}
				param.url = 'v3/video/front/video/updateGoodsClickNum'
				param.method = 'POST'
				param.data.videoId = videoId
				param.data.goodsId = goodsId
				this.$request(param).then(res => {
					if (res.state == 200) {}
				})
			},

			//进入详情时请求足迹接口，加入足迹
			addLook(productId) {
				this.$request({
					url: 'v3/member/front/productLookLog/add',
					data: {
						productId: this.productId, //货品id
					},
					method: 'POST'
				}).then(res => {
					if (res.state == 200) {} else {
						this.$api.msg(res.msg);
					}
				})
			},

			showShareMenu() {
				this.share_model = false
				uni.showShareMenu({
					withShareTicket: true,
					menus: ['shareAppMessage', 'shareTimeline'],
					success(res) {
						console.log(res)
					},
					fail(e) {
						console.log(e)
					}
				})
			},

			//如果推手分享，则建立推手分享关系
			estabTs() {
				let {
					spreaderMemberId
				} = this
				this.$request({
					url: '/v3/spreader/front/spreaderShare/editRelation',
					method: "POST",
					data: {
						spreaderMemberId
					}
				}).then(res => {
					if (res.state = 200) {}
				})
			},

			successSelectAddress(address) { //选择成功回调
				this.curAddress = ''
				address.map((item) => {
					this.curAddress += item.name;
				})
				let regionCode = address[address.length - 2].code
				this.getUserEx(regionCode)
			},



			// 获取分享海报
			getGoodsPoster() {
				this.$request({
					url: 'v3/goods/front/goods/share/sharePosters',
					data: {
						productId: this.productId,
						source: this.source
					},
					responseType: 'arraybuffer',
					dataType: 'arraybuffer'
				}).then(res => {
					// #ifdef H5
					this.sharePoster = 'data:image/png;base64,' + btoa(new Uint8Array(res).reduce((data, byte) =>
						data + String.fromCharCode(byte), ''))
					// #endif
					//#ifdef MP
					this.sharePoster = 'data:image/png;base64,' + weBtoa(new Uint8Array(res).reduce((data, byte) =>
						data + String.fromCharCode(byte), ''))
					// #endif
					// #ifdef APP-PLUS
					this.sharePoster = 'data:image/png;base64,' + weBtoa(new Uint8Array(res).reduce((data, byte) =>
						data + String.fromCharCode(byte), '')).replace(/[\r\n]/g, "");
					// #endif
				})
			},

			//获取页面元素模块距离顶部的距离
			getSelectorQuery() {
				let query = uni.createSelectorQuery().in(this);
				// 获取状态栏的高度
				let statusBarHeight = 0;
				// #ifdef APP-PLUS
				let systemInfo = uni.getSystemInfoSync();

				statusBarHeight = systemInfo.statusBarHeight;
				// #endif
				//获取对应模块到顶部的距离
				query.select('#nav1').boundingClientRect((res) => {
					if (res) {
						this.nav1ScrollTop = res.top - (50 + statusBarHeight);
					}
				}).exec()
				query.select('#nav2').boundingClientRect((res) => {
					if (res) {
						this.nav2ScrollTop = res.top - (50 + statusBarHeight);
					}
				}).exec()
				this.$nextTick(function() {
					if (this.recommendedList && this.recommendedList.length > 0) { //有店铺推荐模块
						query.select('#nav3').boundingClientRect((res) => {
							if (res) {
								this.nav3ScrollTop = res.top - (50 + statusBarHeight);
							}
						}).exec()
					}
				})
				query.select('#nav4').boundingClientRect((res) => {
					if (res) {
						this.nav4ScrollTop = res.top - (50 + statusBarHeight);
					}
				}).exec()
			},
			//点击导航
			clickNav(navId) {
				this.currentNav = navId;
				this.dis = true
				if (navId == 0) {
					this.isNavShow = true;
					uni.pageScrollTo({
						scrollTop: 0,
						duration: 300
					})
					this.isNavShow = false;
				} else if (navId == 1) {
					uni.pageScrollTo({
						scrollTop: this.nav2ScrollTop,
						duration: 300
					})

				} else if (navId == 2) {
					uni.pageScrollTo({
						scrollTop: this.nav3ScrollTop,
						duration: 300
					})
				} else if (navId == 3) {
					uni.pageScrollTo({
						scrollTop: this.nav4ScrollTop,
						duration: 300
					})
				}
			},

			goBack() {
				let pages = getCurrentPages()
				let prepage = pages[pages.length - 2]
				if (prepage && prepage.route == 'extra/svideo/myVideo' && prepage.$vm.curTab == 'goods') {
					prepage.$vm.curTab = 'goods'
				}
				this.$back()
			},


			//轮播图切换
			change(e) {
				this.current = e.detail.current;
				if (this.goodsVideo && e.detail.current == 0) {
					this.showControls = false
				} else {
					this.showControls = true
				}
			},
			//跳转客服页面
			toKefu() {
				if (!this.hasLogin) {
					uni.showToast({
						title: '请登录',
						icon: 'none'
					})
					return;
				}
				let chatBaseInfo = {};
				chatBaseInfo.memberId = this.userCenterData.memberId;
				chatBaseInfo.memberName = this.userCenterData.memberName;
				chatBaseInfo.memberNickName = this.userCenterData.memberNickName;
				chatBaseInfo.memberAvatar = this.userCenterData.memberAvatar;
				chatBaseInfo.storeId = this.goodsData.storeInf.storeId;
				chatBaseInfo.storeLogo = this.goodsData.storeInf.storeLogo;
				chatBaseInfo.storeName = this.goodsData.storeInf.storeName;
				chatBaseInfo.source = 'goods';
				chatBaseInfo.showData = {
					'productId': this.goodsData.defaultProduct.productId,
					'goodsName': this.goodsData.goodsName,
					'goodsImage': this.goodsData.shareImage,
					'goodsPrice': this.goodsData.defaultProduct.productPrice,
				}
				this.saveChatBaseInfo(chatBaseInfo);
				this.$Router.push({
					path: '/standard/chat/detail',
					query: {
						vid: this.goodsData.storeInf.storeId
					}
				})
			},
			//浏览器分享
			sldShareBrower(type) {
				this.showWeiXinBrowerTip = true;
				this.share_model = false;
				this.$WXBrowserShareThen(type, {
					title: this.goodsData.goodsName,
					desc: this.goodsData.goodsBrief,
					link: this.goodsData.shareLink,
					imgUrl: this.goodsData.shareImage,
				});

			},

			backToAdd() {
				this.$refs.selectAddress.hidden()
				this.$refs.addressModel.open()
			},

			showAddress() {
				if (!this.hasLogin || this.addressList.length == 0) {
					this.$refs.selectAddress.showNoMask()
					this.isBack = false
				} else {
					this.$refs.addressModel.open()
					this.isBack = true
				}

			},

			chooseArea() {
				this.$refs.addressModel.close()
				this.$refs.selectAddress.showNoMask()
			},

			// 点击播放按钮,或者视频播放结束隐藏视频组件
			playVideo(type) {
				if (type == 'on') {
					this.playVFlag = true
				} else if (type == 'end') {
					this.playVFlag = false
				}

			},

			//分享 type：分享类型 0 图文 2图片，scene 场景 WXSceneSession：分享朋友  WXSenceTimeline：分享朋友圈
			sldShare: function(type, scene) {
				let shareData = {};
				let {
					goodsData,
					sharePoster
				} = this;
				if (type == 0) {
					shareData.href = goodsData.shareLink;
					shareData.title = goodsData.goodsName;
					shareData.summary = goodsData.goodsBrief;
					shareData.imageUrl = goodsData.shareImage;
				} else if (type == 2) {
					shareData.imageUrl =  getApp().globalData.apiUrl + 'v3/goods/front/goods/share/sharePosters?productId=' +this.productId + '&source=' + this.source;
				}
				console.log(shareData,'share')
				this.$weiXinAppShare(type, scene, shareData);
				this.closeShareModel(); //关闭分享
			},

			//回到页面顶部
			goTop() {
				uni.pageScrollTo({
					scrollTop: 0,
					duration: 300
				});
				this.currentNav = 0;
			},
			//获取商品详情信息
			getGoodsDetail(productId) {
				this.$request({
					url: 'v3/goods/front/goods/details',
					data: {
						productId: this.productId, //货品id
						goodsId: this.goodsId, //商品id
						source: this.source,
					}
				}).then(res => {
					if (res.state == 200) {
						if(res.data.goodsDetails){
							res.data.goodsDetails = quillEscapeToHtml(res.data.goodsDetails);
						}
						this.goodsData = res.data; //详情信息
						this.goodsId = res.data.goodsId
						this.$sldStatEvent({
							behaviorType: 'gpv',
							goodsId: this.goodsId,
							storeId: res.data.storeInf.storeId
						});
						this.goodsVideo = res.data.goodsVideo
						this.showControls = this.goodsVideo ? false : true;
						this.goodsParameterList = [];
						if (this.goodsData.brandName) {
							this.goodsParameterList.push({
								parameterName: '品牌',
								parameterValue: this.goodsData.brandName
							})
						}
						this.goodsParameterList = this.goodsParameterList.concat(res.data
							.goodsParameterList); //规格参数列表
						this.isLoading = true;
						uni.hideLoading();
					} else {
						//错误提示
						this.$api.msg(res.msg);
						this.$Router.back(1)
					}
				}).then(() => {
					this.getGoodsDetailDynamic()
					this.getRecommend(); //获取店铺推荐商品列表
					this.getGoodsComment(); //评价信息
					this.getCouponList(); //获取优惠券列表
					this.fullDiscountList(); //获取满优惠列表
					this.getCartNum(); //获取购物车数据
					this.getAddressList()
					this.getRank()
				})
			},


			getGoodsDetailDynamic() {
				this.$request({
					url: 'v3/goods/front/goods/details2',
					data: {
						productId: this.productId, //货品id
						goodsId: this.goodsId, //商品id
						source: this.source,
					}
				}).then(res => {
					if (res.state == 200) {
						let dynamicData = ['effectSpecValueIds', 'followGoods', 'sales', 'state', 'shareLink',
							'shareImage', 'isVirtualGoods'
						]
						dynamicData.forEach((item) => {
							this.goodsData[item] = res.data[item]
						})
						this.defaultProduct = res.data.defaultProduct; //默认货品信息
						this.specs = res.data.specs; //规格列表
						this.storeInf = res.data.storeInf; //店铺信息
						this.deliverInfo = res.data.deliverInfo; //发货地及运费信息
						this.promotionId = this.defaultProduct.promotionId; //活动id
						if (this.promotionId && this.defaultProduct.promotionType == 104) { // 秒杀
							this.getSecKill();
						} else if (this.defaultProduct.promotionType == 103) { // 预售
							this.getPreSell();
						} else {
							this.secKillInfo = {};
							this.preSellInfo = {};
						}
						if (this.promotionId && this.defaultProduct.promotionType == 102) { //拼团
							this.getPinInfo()
						} else {
							this.pinInfo = {}
						}
						if (this.promotionId && this.defaultProduct.promotionType == 105) {
							this.getLadder()
						} else {
							this.ladderInfo = {}
						}

					} else {
						this.$api.msg(res.msg);
					}
				}).then(() => {
					this.getSelectorQuery();
				})
			},

			//获取预售商品详情
			getPreSell() {
				let param = {};
				param.url = 'v3/promotion/front/preSell/detail';
				param.method = 'GET';
				param.data = {};
				param.data.productId = this.productId;
				param.data.promotionId = this.promotionId;
				this.$request(param).then(res => {
					if (res.state == 200) {
						let now = new Date()
						let preStartDate = new Date(res.data.startTime.replace(/-/g, '/'))
						let preEndDate = new Date(res.data.endTime.replace(/-/g, '/'))
						let result = res.data;
						this.preSellInfo = result;
						this.productId = this.preSellInfo.productId;
						this.preSellInfo.endTime = res.data.endTime.substring(0, this.preSellInfo.endTime.length -
							3)
						this.preSellInfo.startTime = res.data.startTime.substring(0, this.preSellInfo.startTime
							.length - 3)
						if (now > preStartDate && now < preEndDate) {
							this.preSellInfo.pre_run = 2 //活动进行中
						} else if (now < preStartDate) {
							this.preSellInfo.pre_run = 1 //活动未开始
						} else if (now > preEndDate) {
							this.preSellInfo.pre_run = 3 //活动已结束
						}

					} else {
						this.$api.msg(res.msg);
					}
				}).catch((e) => {
					//异常处理
				})
			},

			//获取拼团商品信息
			getPinInfo() {
				if (this.secInterval) {
					clearInterval(this.secInterval);
				}
				let param = {};
				param.url = 'v3/promotion/front/spell/detail';
				param.method = 'GET';
				param.data = {};
				param.data.productId = this.productId;
				param.data.promotionId = this.promotionId;
				this.$request(param).then(res => {
					if (res.state == 200) {
						let result = res.data;
						this.pinInfo = result;
						if (this.showState == 1) {
							this.$refs.pinGroup.getPinTeam()
						}
					} else {
						this.$api.msg(res.msg);
					}
				})
			},

			make_group_more_fun() {
				this.transparent_mask = true
			},

			handleJoinGroup(e) {
				if (e.pinState == 1) {
					this.transparent_mask = true
					this.spellTeamId = e.spellTeamId
				} else if (e.pinState == 2) {
					this.transparent_mask = false
				} else if (e.pinState == 3) {
					this.transparent_mask = false
					this.showSpecModel('joinLeague')
				}
			},

			getRank() {
				this.$request({
					url: '/v3/goods/front/goods/rankList',
					data: {
						goodsId: this.goodsId
					}
				}).then(res => {
					if (res.state == 200) {
						this.rankData = res.data
					}
				})
			},

			//获取秒杀商品详情
			getSecKill() {
				if (this.secInterval) {
					clearInterval(this.secInterval);
				}
				let param = {};
				param.url = 'v3/promotion/front/seckill/detail';
				param.method = 'GET';
				param.data = {};
				param.data.productId = this.productId;
				param.data.promotionId = this.promotionId;
				this.$request(param).then(res => {
					if (res.state == 200) {
						let result = res.data;
						this.secKillInfo = result;
						this.productId = this.secKillInfo.productId;
						if (this.secKillInfo.state == 1 || this.secKillInfo.state == 2) {
							let countTime = 0;
							countTime = this.secKillInfo.distanceEndTime; //剩余时间	秒
							this.secInterval = setInterval(() => {
								if (countTime == 0) {
									//倒计时结束，清除倒计时
									clearInterval(this.secInterval);
									this.getGoodsDetail(this.secKillInfo.productId)
								} else {
									countTime--;
									let day = parseInt(countTime / 60 / 60 / 24);
									let hours = parseInt(countTime / 60 / 60 % 24);
									let minutes = parseInt(countTime / 60 % 60);
									let seconds = parseInt(countTime % 60);
									this.secKillDay = day;
									this.secKillHr = hours > 9 ? hours : '0' + hours;
									this.secKillMin = minutes > 9 ? minutes : '0' + minutes;
									this.secKillSec = seconds > 9 ? seconds : '0' + seconds;
								}
							}, 1000)
						}
					} else {
						this.$api.msg(res.msg);
					}
				}).catch((e) => {
					//异常处理
				})
			},

			// 阶梯团商品详情
			getLadder() {
				if (this.secInterval) {
					clearInterval(this.secInterval);
				}
				let param = {};
				param.url = 'v3/promotion/front/ladder/group/detail';
				param.method = 'GET';
				param.data = {};
				param.data.productId = this.productId;
				param.data.promotionId = this.promotionId;
				this.$request(param).then(res => {
					if (res.state == 200) {
						let result = res.data;
						this.ladderInfo = result;
						this.productId = this.ladderInfo.productId;
						this.ladderProcess = result.joinedNum < result.ruleList[result.ruleList.length - 1]
							.joinGroupNum ? (result.joinedNum / result.ruleList[result.ruleList.length - 1]
								.joinGroupNum) * 100 : 100
						let now = new Date()
						let start = new Date(this.ladderInfo.startTime.replace(/-/g, '/'))
						let end = new Date(this.ladderInfo.endTime.replace(/-/g, '/'))
						if (now < start) {
							this.ladderInfo.ladder_run = 1
						} else if (now > start && now < end) {
							this.ladderInfo.ladder_run = 2
						} else {
							this.ladderInfo.ladder_run = 3
						}
					} else {
						this.$api.msg(res.msg);
					}
				}).catch((e) => {
					//异常处理
				})
			},

			//秒杀活动提醒我及取消提醒
			secKillPreview() {
				if (!this.hasLogin) {
					//提示登陆
					this.
					return;
				} else {
					let param = {};
					param.url = 'v3/promotion/front/seckill/isRemind';
					param.method = 'POST';
					param.data = {};
					param.data.key = this.userInfo.access_token;
					param.data.stageProductId = this.secKillInfo.stageProductId; //秒杀商品id
					this.$request(param).then(res => {
						if (res.state == 200) {
							this.$api.msg(res.msg);
							this.secKillInfo.isRemind = !this.secKillInfo.isRemind;
						} else {
							this.$api.msg(res.msg);
						}
					}).catch((e) => {
						//异常处理
					})
				}
			},
			/**选择规格值
			 * @param {Object} type 类型   值：choice,规格选择    default:默认
			 * @param {Object} specId 父级规格值
			 * @param {Object} specValueId   点击的当前的规格值
			 */
			selectSpecVal(type, specId, specValueId) {
				let that = this;
				this.isChoice = type == 'choice' ? 'choice' : 'default';
				let curParSpec = []; //当前点击的规格的父级id的当前项
				curParSpec = that.specs.filter(item => item.specId == specId);
				let curSPec = []; //当前点击的规格的规格id的当前项
				curSPec = curParSpec[0].specValueList.filter(item1 => item1.specValueId == specValueId);
				curSPec[0].checkState = 1;
				//被选择的规格值的id
				let choiceSpecIds = [];
				that.specs.forEach(item => {
					if (item.specId != specId) {
						item.specValueList.forEach(item1 => {
							if (item1.checkState == '1') { // checkState: 1-选中，2-可选，3-禁用
								choiceSpecIds.push(item1.specValueId)
							}
						})
					} else {
						choiceSpecIds.push(specValueId);
					}
				})

				let param = {};
				param.url = 'v3/goods/front/goods/productInfo';
				param.method = 'GET';
				param.data = {};
				param.data.goodsId = that.goodsId;
				param.data.specValueIds = choiceSpecIds.join(',');
				that.$request(param).then(res => {
					if (res.state == 200) {
						let result = res.data;
						that.choiceSpecDes = result.defaultProduct;
						that.productId = result.defaultProduct.productId;
						that.deliverInfo = result.deliverInfo; //地址及运费
						that.specs = result.specs; //规格列表
						that.goodsData.shareLink = result.shareLink;
						that.current = 0;
						that.promotionId = that.choiceSpecDes.promotionId; //活动id
						that.currentSpecNum = 1;
						// that.getGoodsDetailDynamic();
					} else {
						this.$api.msg(res.msg);
					}
				}).catch((e) => {
					//异常处理
				})
			},
			//获取商品评价
			getGoodsComment() {
				let param = {};
				param.url = 'v3/goods/front/goods/comment';
				param.method = 'GET';
				param.data = {};
				param.data.productId = this.productId;
				this.$request(param).then(res => {
					if (res.state == 200) {
						let result = res.data;
						this.goodsCommentsInfo = result;
					} else {
						this.$api.msg(res.msg);
					}
				}).catch((e) => {
					//异常处理
				})
			},
			//分享
			share() {
				this.$refs.share.toggleMask();
			},
			//加入购物车功能
			addCart() {
				if (!this.hasLogin) {
					let specValues = ''; // 存储商品多规格值
					if(this.specs && this.specs.length>0){
						this.specs.forEach(item=>{
							item.specValueList.forEach(items=>{
								if(items.checkState == 1){
									specValues += items.specValue +' '
								}
							})
						})
					}
					let cart_list = {
						storeCartGroupList: [{
							promotionCartGroupList: [{
								cartList: [{
									buyNum: this.currentSpecNum,
									goodsId: this.goodsId - 0,
									productId: this.productId - 0,
									productImage: this.isChoice == 'default' ? this
										.defaultProduct.goodsPics[0] : this.choiceSpecDes
										.goodsPics[
											0],
									goodsName: this.goodsData.goodsName,
									isChecked: 1,
									productPrice: this.isChoice == 'default' ? this
										.defaultProduct.productPrice : this.choiceSpecDes
										.productPrice,
									productStock: this.isChoice == 'default' ? this
										.defaultProduct.productStock : this.choiceSpecDes
										.productStock,
									specValues: specValues
								}],
							}],
							storeId: this.storeInf.storeId,
							storeName: this.storeInf.storeName,
							checkedAll: true
						}],
						checkedAll: true,
						invalidList: []
					}
					//未登录加入本地缓存
					let local_cart_list = uni.getStorageSync('cart_list') //购物车列表本地缓存
					if (local_cart_list) { //如果不是第一次存储
						let tmp_list1 = []
						let tmp_list2 = []
						cart_list.storeCartGroupList.forEach(item => {
							item.promotionCartGroupList.forEach(item1 => {
								item1.cartList.forEach(item2 => {
									local_cart_list.storeCartGroupList.forEach(v => {
										v.promotionCartGroupList.forEach(v1 => {
											v1.cartList.forEach(v2 => {
												if (v2.productId == item2
													.productId && v
													.storeId == item
													.storeId) {
													tmp_list1.push(v)
												}
											})
										})
									})
									tmp_list2 = local_cart_list.storeCartGroupList.filter(v => {
										return v.storeId == item.storeId
									})
								})
							})
						})
						if (tmp_list1.length > 0 && tmp_list2.length > 0) { //同一店铺同一商品
							local_cart_list.storeCartGroupList.map(item => {
								item.promotionCartGroupList.map(item1 => {
									item1.cartList.map(item2 => {
										if (item2.productId == this.productId && item.storeId ==
											this.storeInf.storeId) {
											item2.buyNum += this.currentSpecNum
										}
									})
								})
							})

						} else if (tmp_list1.length == 0 && tmp_list2.length > 0) { //同一店铺不同商品
							local_cart_list.storeCartGroupList.map(item => {
								if (item.storeId == this.storeInf.storeId) {
									item.promotionCartGroupList.map(item2 => {
										item2.cartList.push(cart_list.storeCartGroupList[0]
											.promotionCartGroupList[0].cartList[0])
									})
								}
							})
						} else { //不同店铺不同商品
							local_cart_list.storeCartGroupList.push(cart_list.storeCartGroupList[0])
						}

						// 未登录购物车展示数据
						uni.setStorage({
							key: 'cart_list',
							data: local_cart_list,
							success: function() {
								//更新购物车数量和购物车数据
							}
						});

					} else {
						uni.setStorage({
							key: 'cart_list',
							data: cart_list,
							success: function() {
								//更新购物车数量和购物车数据
							}
						});
					}
					uni.showToast({
						title: '加入购物车成功！',
						icon: 'none',
						duration: 700
					})
					this.$sldStatEvent({
						behaviorType: 'cart',
						goodsId: this.goodsId,
						storeId: this.storeInf.storeId
					})
					this.$refs.specModel.close();
					this.getNoLoginCartNum();
				} else { //已登录
					this.$request({
						url: 'v3/business/front/cart/add',
						data: {
							productId: this.productId,
							number: this.currentSpecNum,
						},
						method: 'POST'
					}).then(res => {
						if (res.state == 200) {
							//更新购物车数量
							this.$refs.specModel.close();
							this.$sldStatEvent({
								behaviorType: 'cart',
								goodsId: this.goodsId,
								storeId: this.storeInf.storeId
							})
							this.$api.msg(res.msg);
							this.getCartNum();

						} else {
							this.$api.msg(res.msg);
						}
					})
				}
			},
			//确认下单
			buy(arg) {
				if (!this.hasLogin) {
					this.$refs.popLogin.open()
					return
				} else {
					this.editNum('edit');
					this.$refs.specModel.close();

					let param = {
						url: 'v3/business/front/orderOperate/check',
						method: 'POST',
						header: {
							"Content-Type": "application/json"
						},
						data: {
							isCart: false,
							productId: this.productId,
							number: this.currentSpecNum,
							source: 1
						}
					}

					if (typeof arg == 'string' && arg == 'aloneBuy') {
						param.data.isAloneBuy = true
					}
					uni.showLoading()
					uni.setStorageSync('addressId', this.sourceId)
					this.$request(param).then(res => {
						uni.hideLoading()
						if (res.state == 200) {

							//从这里跳转页面后置为1，从一个页面返回回来，将在onShow里调用getGoodsDetail
							this.showState = 1
							let query = {
								orderType: 1,
								goodsId: this.goodsId,
								productId: this.productId,
								numbers: this.currentSpecNum,
								ifcart: 2,
							}
							if (JSON.stringify(this.pinInfo) != '{}' && this.pinButState == 0) {
								query.isAloneBuy = true

							} else if (this.valiInfo(this.pinInfo) && (this.pinButState == 1)) {
								query.isAloneBuy = false
							} else if (this.valiInfo(this.pinInfo) && this.pinButState == 3) {
								query.isAloneBuy = false
								query.spellTeamId = this.spellTeamId
							}

							this.$Router.push({
								path: '/pages/order/confirmOrder',
								query
							})

						} else if (res.state == 267) {
							this.$api.msg(res.data.stateValue)
						} else {
							this.$api.msg(res.msg)
						}
					})


				}
			},
			moveHandle() {},

			confirmLogin() {
				let url = this.$Route.path;
				const query = this.$Route.query;
				this.$refs.popLogin.close()
				uni.setStorageSync('fromurl', {
					url,
					query
				});
				this.$Router.push('/pages/public/login')
			},


			//收藏、取消收藏事件
			collectGoods() {
				if (!this.hasLogin) {
					//提示登陆
					this.$refs.popLogin.open();
					return;
				} else {
					this.$request({
						url: 'v3/member/front/followProduct/edit',
						data: {
							productIds: this.defaultProduct.productId,
							isCollect: !this.goodsData.followGoods
						},
						method: 'POST',
					}).then(res => {
						if (res.state == 200) {
							this.goodsData.followGoods = this.goodsData.followGoods == undefined ? true : !this
								.goodsData.followGoods;
							if (this.goodsData.followGoods) {
								this.$sldStatEvent({
									behaviorType: 'fav',
									goodsId: this.goodsId,
									storeId: this.storeInf.storeId
								})
							}
							this.$api.msg(res.msg);
						} else {
							this.$api.msg(res.msg);
						}
					}).catch((e) => {
						//异常处理
					})
				}
			},

			//去商品评价页面
			goEvaluation() {
				this.$Router.push({
					path: '/standard/product/evaluation',
					query: {
						productId: this.productId
					}
				})
			},
			//服务弹框
			serviceModel() {
				this.$refs.serviceModel.open();
			},
			//满优惠弹框
			openFullDisModel() {
				this.$refs.fullDisModel.open();
			},
			//关闭弹框
			closeModel() {
				this.$refs.serviceModel.close();
				this.$refs.couponModel.close();
				this.$refs.fullDisModel.close();
			},
			//获取商品详情页，店铺优惠券
			getCouponList() {
				this.$request({
					url: 'v3/promotion/front/coupon/storeCouponList',
					data: {
						storeId: this.goodsData.storeInf.storeId, //店铺id
						current: this.pageCurrent,
						pageSize: this.pageSize,
					}
				}).then(res => {
					if (res.state == 200) {
						this.couponList = res.data.list; //优惠券列表
						this.couponList.forEach((item, index) => {
							item.isOpen = false;
							if (item.isReceive == 3) {
								item.couponBg = this.finishReceiveBg;
							}
							if (item.isReceive == 2) {
								item.couponBg = this.hasReceiveBg;
							}
							if (item.isReceive == 1) {
								item.couponBg = this.goReceiveBg;
							}
						})
					} else {
						//错误提示
						this.$api.msg(res.msg);
					}
				}).catch((e) => {})
			},
			//领券弹框
			openCouponModel() {
				this.$refs.couponModel.open();
			},
			//规则展开
			descriptionOpen(couponId) {
				this.couponList.map(item => {
					if (item.couponId == couponId) {
						if (item.description != '') {
							item.isOpen = !item.isOpen
							this.$forceUpdate()
						}
					}
				})
			},
			//立即领取
			goReceive(item) {
				let couponId = item.couponId
				let param = {};
				param.url = 'v3/promotion/front/coupon/receiveCoupon';
				param.method = 'GET';
				param.data = {};
				param.data.couponId = couponId;
				this.$request(param).then(res => {
					if (res.state == 200) {
						let result = res.data;
						this.$api.msg('领取成功!');
						this.getCouponList();
					} else {
						this.$api.msg(res.msg);
						this.getCouponList();
					}
				}).catch((e) => {
					//异常处理
				})
			},
			//获取满优惠列表
			fullDiscountList() {
				let that = this;
				let param = {};
				param.url = 'v3/goods/front/goods/activityList';
				param.method = 'GET';
				param.data = {};
				param.data.productId = this.productId;
				this.$request(param).then(res => {
					if (res.state == 200) {
						let result = res.data;
						this.fullDisList = result
						result.map(item => {
							// item.descriptionList = item.descriptionList ? quillEscapeToHtml(item.descriptionList) : ''
							item.descriptionList = item.descriptionList.map(i => i.replace(/<(.+?)>/g,
								function(num) {
									return "<text style='color:red'>" + num.slice(1, num.length -
										1) + "</text>"
								}))
							item.descriptionList = item.descriptionList.map(i => i.replace(/x[\d]/g,
								function(num) {
									return "<text style='color:red'>" + num + "</text>"
								}))
						})
					} else {
						this.$api.msg(res.msg);
					}
				}).catch((e) => {
					//异常处理
				})
			},
			//获取店铺推荐商品信息
			getRecommend() {
				let that = this;
				let param = {};
				param.url = 'v3/goods/front/goods/recommendList';
				param.method = 'GET';
				param.data = {};
				param.data.queryType = 'goods';
				param.data.productId = this.productId;
				this.$request(param).then(res => {
					if (res.state == 200) {
						let result = res.data;
						this.recommendedList = result.list;
						this.getSelectorQuery();
					} else {
						this.$api.msg(res.msg);
					}
				}).catch((e) => {
					//异常处理
				})
			},
			//去分享
			goShare() {
				this.share_model = true;
			},
			//关闭分享弹框
			closeShareModel() {
				this.share_model = false;
				this.showWeiXinBrowerTip = false;
				this.poster = false;
			},
			//获取海报
			getPoster() {
				this.share_model = false;
				this.showWeiXinBrowerTip = false;
				this.poster = true;
			},
			//下载海报
			downloadPoster() {
				let sharePosterLink = getApp().globalData.apiUrl + 'v3/goods/front/goods/share/sharePosters?productId=' +
					this.productId + '&source=' + this.source

				let _this = this;
				let fileName = new Date().valueOf();
				// #ifdef MP-WEIXIN
				let filePath1 = wx.env.USER_DATA_PATH + '/' + fileName + '.png'
				// #endif
				// #ifdef MP-TOUTIAO
				let filePath1 = tt.env.USER_DATA_PATH + '/' + fileName + '.png'
				// #endif
				// #ifdef MP-ALIPAY
				let filePath1 = my.env.USER_DATA_PATH + '/' + fileName + '.png'
				// #endif
				// #ifdef MP-BAIDU
				let filePath1 = swan.env.USER_DATA_PATH + '/' + fileName + '.png'
				// #endif

				uni.downloadFile({
					url: sharePosterLink,
					filePath: filePath1,
					success: res_info => {
						if (res_info.statusCode == 200) {
							// #ifdef MP
							uni.getSetting({
								success(res_down) {
									if (!res_down.authSetting['scope.writePhotosAlbum']) {
										uni.showModal({
											title: '提示',
											content: '您好,需要开启相册权限',
											showCancel: false,

											success(res) {
												if (res.confirm) {
													uni.authorize({
														scope: 'scope.writePhotosAlbum',

														success() {
															// 用户已经同意,后续调用时不会弹窗询问
															_this.saveHb(filePath1);
														},

														fail() {
															//拒绝授权
															uni.showToast({
																title: '抱歉，没有授权无法下载海报',
																icon: 'none'
															});
														}

													});
												}
											}

										});
									} else {
										_this.saveHb(filePath1);
									}
								}

							});
							// #endif

						} else {
							uni.showToast({
								title: '下载失败',
								icon: 'none'
							});
							_this.poster = true;
						}
					}
				})
				//#ifdef H5
				//阻止浏览器默认行为 
				document.oncontextmenu = function(e) {
					e.preventDefault()
				}
				//#endif
			},

			/**
			 * 保存图片
			 */
			saveHb: function(img) {
				let _this = this;
				uni.saveImageToPhotosAlbum({
					filePath: img,
					success: function(data) {
						_this.poster = false;
						uni.showToast({
							title: '已保存到本地',
							icon: 'success',
							duration: 2000
						});
					},
					complete: function(res) {}
				});
			},
			
			prevImg() {
				uni.previewImage({
					urls: [this.sharePoster]
				})
			},


			//APP端保存图片的方法
			saveImgAPP() {

				this.$request({
					url: 'v3/goods/front/goods/share/sharePosters?productId=' + this.productId + '&source=' + this
						.source,
					method: 'GET',
					responseType: 'arraybuffer'
				}).then((res) => {
					let base64 = 'data:image/png;base64,' + weBtoa(new Uint8Array(res).reduce((data, byte) =>
						data + String.fromCharCode(byte), '')).replace(/[\r\n]/g, "");
					const bitmap = new plus.nativeObj.Bitmap("test");
					bitmap.loadBase64Data(base64, function() {
						const url = "_doc/" + new Date().getTime() + ".png"; // url为时间戳命名方式

						bitmap.save(url, {
							overwrite: true, // 是否覆盖
							// quality: 'quality'  // 图片清晰度
						}, (i) => {
							uni.saveImageToPhotosAlbum({
								filePath: url,
								success: function() {
									uni.showToast({
										title: '图片保存成功',
										icon: 'none'
									})
									bitmap.clear()
								}
							});
						}, (e) => {
							uni.showToast({
								title: '图片保存失败',
								icon: 'none'
							})
							bitmap.clear()
						});
					}, (e) => {
						uni.showToast({
							title: '图片保存失败',
							icon: 'none'
						})
						bitmap.clear()
					});
				})





			},

			//关闭海报
			closePoster() {
				this.poster = false;
			},
			//打开规格弹框
			showSpecModel(type) {
				//如果是购买操作，并且商品总库存为0
				if ((type === 'buy' || typeof type !== 'string') && !this.defaultProduct.productStock) {
					return;
				}
				if (type == 'add') {
					this.showSpecModelType = 'add'
				} else if (type == 'buy') {
					this.showSpecModelType = 'buy'
				} else if (type == 'offshelf') {
					this.showSpecModelType = 'offshelf'
				} else if (type == 'nosocket') {
					this.showSpecModelType = 'nosocket'
				} else if (type == 'pinAlone' && this.valiInfo(this.pinInfo)) {
					this.pinButState = 0
				} else if (type == 'pinLeague' && this.valiInfo(this.pinInfo)) {
					this.pinButState = 1
				} else if ((!type) && this.valiInfo(this.pinInfo)) {
					this.pinButState = 2
				} else if (type == 'joinLeague') {
					this.pinButState = 3
				} else {
					this.showSpecModelType = ''
				}
				this.$forceUpdate()
				this.$refs.specModel.open();
			},
			//统一处理活动商品的数量的加及编辑
			activityAddEdit(type) {
				let that = this;

				that.currentSpecNum = that.currentSpecNum.toString().replace(/\D/g, '');
				if (that.currentSpecNum == '' || that.currentSpecNum < 0) {
					setTimeout(() => {
						that.currentSpecNum = 1;
					}, 0)
					return;
				}

				let activityLimitNumber = 0; //活动的限购数量 0代表不限购
				let activityProductStock = 0; //活动的库存
				if (this.isChoice == 'default') {
					activityProductStock = this.defaultProduct.productStock
				} else if (this.isChoice == 'choice') {
					activityProductStock = this.choiceSpecDes.productStock
				}

				if (that.secKillInfo && that.secKillInfo.state == 2) { //秒杀活动进行中
					activityLimitNumber = that.secKillInfo.upperLimit;
				} else if (this.valiInfo(that.preSellInfo) && that.preSellInfo.startTime) { //预售进行中
					activityLimitNumber = that.preSellInfo.buyLimit;
				} else if (this.valiInfo(that.pinInfo)) {
					activityLimitNumber = that.pinInfo.buyLimit;
				} else if (this.valiInfo(that.ladderInfo)) {
					activityLimitNumber = that.ladderInfo.buyLimitNum;
				}
				if ((activityLimitNumber < activityProductStock) && activityLimitNumber > 0) { // 限购数 < 库存
					if (that.currentSpecNum >= activityLimitNumber) {
						setTimeout(() => {
							that.currentSpecNum = activityLimitNumber;
							that.noEdit = true;
						}, 0)
						return;
					} else {
						setTimeout(() => {
							type == 'add' ? that.currentSpecNum++ : that.currentSpecNum;
						}, 0)
						that.noEdit = false;
						return;
					}
				} else { //限购数 > 库存
					if (that.currentSpecNum < activityProductStock) {
						if (that.currentSpecNum == 0 || that.currentSpecNum < 0) {
							setTimeout(() => {
								that.currentSpecNum = 1;
							}, 0)
							return;
						} else {
							if (that.currentSpecNum > 999) {
								setTimeout(() => {
									that.currentSpecNum = 999;
								}, 0)
								that.noEdit = true;
								return;
							} else {
								setTimeout(() => {
									type == 'add' ? that.currentSpecNum++ : that.currentSpecNum;
								}, 0)
								that.noEdit = false;
								return;
							}
						}
					} else {
						setTimeout(() => {
							that.currentSpecNum = activityProductStock;
						}, 0)
						that.noEdit = true;
						return;
					}
				}
			},

			//编辑数量
			editNum(type, e) {
				let that = this;

				let reg = /\./g
				let reg0 = /0+\d/
				
				console.log(reg0.test(this.currentSpecNum.toString()),'sss')

				if (reg.test(this.currentSpecNum.toString()) || this.currentSpecNum <= 0) {
					setTimeout(() => {
						that.currentSpecNum = 1;
					}, 0)
				}

				if (type == 'add') {
					if (this.actiState) {
						that.activityAddEdit('add');
					} else {
						if ((that.isChoice == 'default' && that.currentSpecNum >= that.defaultProduct.productStock) || (
								that.isChoice =='choice' && that.currentSpecNum >= that.choiceSpecDes.productStock)) {
							if (that.defaultProduct.productStock == 0 || that.choiceSpecDes.productStock == 0) {
								that.currentSpecNum = 1;
							} else {
								that.currentSpecNum = that.isChoice == 'default' ? that.defaultProduct.productStock : that
									.choiceSpecDes.productStock;
							}
							that.noEdit = true;
						} else {
							if (that.currentSpecNum > 999) {
								that.currentSpecNum = 999;
								that.noEdit = true;
							} else {
								that.currentSpecNum++;
								that.noEdit = false;
							}
						}
					}
				} else if (type == 'edit') {
					if (that.currentSpecNum == '' || that.currentSpecNum < 0) {
						setTimeout(() => {
							that.currentSpecNum = 1;
						}, 0)
						return;
					}
					if (this.actiState) {
						that.activityAddEdit('edit');
					} else {
						if ((that.isChoice == 'default' && that.currentSpecNum > that.defaultProduct.productStock) || (that
								.isChoice == 'choice' && that.currentSpecNum > that.choiceSpecDes.productStock)) {
							setTimeout(() => {
								this.currentSpecNum = that.isChoice == 'default' ? that.defaultProduct
									.productStock : that.choiceSpecDes.productStock;
							}, 0)
							that.noEdit = true;
							return;
						} else {
							that.currentSpecNum = e && e.detail.value ? e.detail.value : that.currentSpecNum;
							if (that.currentSpecNum == 0 || that.currentSpecNum < 0) {
								setTimeout(() => {
									that.currentSpecNum = 1;
								}, 0)
								return;
							} else {
								that.currentSpecNum = that.currentSpecNum.toString().replace(/\D/g, '');
								if (that.currentSpecNum > 999) {
									setTimeout(() => {
										that.currentSpecNum = 999;
									}, 0)
									that.noEdit = true;
									return;
								} else {
									setTimeout(() => {
										that.currentSpecNum = Number(that.currentSpecNum);
									}, 0)
									that.noEdit = false;
								}
							}
						}
					}
				} else if (type == 'reduce') {
					if (that.currentSpecNum > 1) {
						that.currentSpecNum--;
						that.noEdit = false;
					} else {
						that.currentSpecNum = 1;
					}
				}
			},
			//关闭规格弹框
			closeSpecModel() {
				this.$refs.specModel.close();
			},
			//去商品详情页面
			goGoodsDetail(defaultProductId, goodsId) {
				this.$Router.push({
					path: '/standard/product/detail',
					query: {
						productId: defaultProductId,
						goodsId
					}
				})
			},
			//获取购物车数据
			getCartNum() {
				if (this.hasLogin) {
					let param = {};
					param.url = 'v3/business/front/cart/cartNum';
					param.method = 'GET';
					param.data = {};
					// param.data.key = this.userInfo.access_token;
					this.$request(param).then(res => {
						if (res.state == 200) {
							this.cartNum = res.data;
							this.cartNumShow = true;
						} else {
							this.$api.msg(res.msg);
						}
					}).catch((e) => {
						//异常处理
					})
				} else {
					this.getNoLoginCartNum();
				}
			},
			//获取未登录，购物车数量
			getNoLoginCartNum() {
				this.cartNum = 0;
				let cart_list = uni.getStorageSync('cart_list');
				if (cart_list && cart_list.storeCartGroupList) {
					cart_list.storeCartGroupList.map(item => {
						item.promotionCartGroupList.map(item1 => {
							item1.cartList.map(item2 => {
								this.cartNum++;
							})
						})
					})
				}
				this.cartNumShow = true;
			},
			//去店铺页面
			goShopHome() {
				this.$Router.push({
					path: '/standard/store/shopHomePage',
					query: {
						vid: this.goodsData.storeInf.storeId
					}
				})
			},
			//去店铺商品列表页面
			toStoreGoodList() {
				this.$Router.push({
					path: '/standard/store/shopHomePage',
					query: {
						vid: this.goodsData.storeInf.storeId,
						goods_list: 1
					}
				})
			},
			//分享链接的弹框展示
			tipsShow() {
				this.tips_show = !this.tips_show;
				this.transparent_mask = !this.transparent_mask;
			},
			//三点分享链接
			handleLink(e) {
				let link = e.currentTarget.dataset.link;
				let type = e.currentTarget.dataset.type;
				if (type != 'share') {
					// wx.switchTab({
					// 	url: link
					// });
					this.$Router.pushTab(link)
				}
				this.setData({
					tips_show: false
				})
			},
			//隐藏透明遮罩层
			hideMask() {
				this.transparent_mask = false;
				this.tips_show = false;
				this.$refs.pinGroup.join_group = false
				this.$refs.pinGroup.make_group_more = false
			},


			//展开规格参数
			handleGoodsParam() {
				this.openGoodsParam = !this.openGoodsParam;
			},
			//去商品详情页
			goProductDetail(defaultProductId) {
				this.$Router.push({
					path: '/standard/product/detail',
					query: {
						productId: defaultProductId
					}
				})
			},

			valiInfo(info) {
				return JSON.stringify(info) != '{}'
			},
			//h5跳转新页面播放视频
			toPlayPage() {
				uni.navigateTo({
					url: '/standard/product/video?video_url=' + this.goodsVideo + '&posterImage=' + this
						.defaultProduct.goodsPics[0],
				});
			},

			//获取地址列表
			getAddressList() {
				if (!this.hasLogin) {
					return false
				}
				this.$request({
					url: 'v3/member/front/memberAddress/list',
					method: 'GET'
				}).then(res => {
					if (res.state == 200) {
						if (res.data.list.length > 0) {
							this.addressList = res.data.list = res.data.list;
							if (this.addressList.findIndex(i => i.isDefault == 1) > 0) {
								let index = this.addressList.findIndex(i => i.isDefault == 1)
								this.curAddress = this.addressList[index].addressAll + "" + this.addressList[index]
									.detailAddress
								this.sourceId = this.addressList[index].addressId
							} else {
								this.curAddress = this.addressList[0].addressAll + "" + this.addressList[0]
									.detailAddress
								this.sourceId = this.addressList[0].addressId
							}
							if (uni.getStorageSync('addressId')) {
								let addressID = uni.getStorageSync('addressId')
								if (res.data.list.filter(i => i.addressId == addressID)[0]) {
									let tmp = res.data.list.filter(i => i.addressId == addressID)[0]
									this.curAddress = tmp.addressAll + "" + tmp.detailAddress
									this.sourceId = tmp.addressId
								}
							}
						}
					}
				})
			},
			checkAddress(item) {
				this.sourceId = item.addressId
				this.$refs.addressModel.close()
				this.curAddress = item.addressAll + "" + item.detailAddress
				uni.setStorageSync('addressId', this.sourceId)
				let cityCode = item.cityCode
				this.getUserEx(cityCode)
			},
			addressClose() {
				this.$refs.addressModel.close()
			},
			//用于切换地址，获取运费
			getUserEx(cityCode) {
				this.$request({
					url: '/v3/goods/front/goods/calculateExpress',
					data: {
						cityCode,
						productId: this.productId
					}
				}).then(res => {
					if (res.state == 200) {
						this.deliverInfo.expressFee = res.data
					} else {
						this.$api.msg(res.msg)
					}
				})
			},
		}
	}
</script>

<style lang='scss'>
	page {
		background: $bg-color-split;
		/* padding-bottom: 100rpx; */
		width: 750rpx;
		margin: 0 auto;
	}

	button::after {
		border: none;
	}

	.container {
		position: relative;
	}

	.go_back {
		width: 50rpx;
		height: 50rpx;
		position: absolute;
		/* #ifdef H5 */
		top: 28rpx;
		/* #endif */
		/* #ifdef APP-PLUS */
		top: 28rpx;
		/* #endif */
		left: 25rpx;
		z-index: 99;

		image {
			width: 50rpx;
			height: 50rpx;
		}
	}

	.go_more {
		width: 50rpx;
		height: 50rpx;
		position: absolute;
		/* #ifdef H5 */
		top: 28rpx;
		/* #endif */
		/* #ifdef APP-PLUS */
		top: 28rpx;
		/* #endif */
		right: 25rpx;
		z-index: 99;

		image {
			width: 50rpx;
			height: 50rpx;
		}

		.triangle-up {
			position: absolute;
			display: block;
			top: 40rpx;
			right: -15rpx;
			width: 0rpx;
			height: 0rpx;
			background: #FFFFFF;
			border: 1px solid #CCCCCC;

			&::before {
				box-sizing: content-box;
				width: 0;
				height: 0;
				position: absolute;
				top: -2px;
				right: 25rpx;
				padding: 0;
				border-bottom: 8px solid #ffffff;
				border-top: 8px solid transparent;
				border-left: 8px solid transparent;
				border-right: 8px solid transparent;
				display: block;
				content: '';
				z-index: 12;
			}

			&::after {
				box-sizing: content-box;
				width: 0px;
				height: 0px;
				position: absolute;
				top: -5px;
				right: 20rpx;
				padding: 0;
				border-bottom: 9px solid rgba(102, 102, 102, 0.1);
				border-top: 9px solid transparent;
				border-left: 9px solid transparent;
				border-right: 10px solid transparent;
				display: block;
				content: '';
				z-index: 10
			}
		}

		.tips {
			position: absolute;
			z-index: 20;
			top: 70rpx;
			right: -10rpx;
			width: 226rpx;
			background: rgba(255, 255, 255, 1);
			box-shadow: 0px 0px 10rpx 0px rgba(102, 102, 102, 0.2);
			opacity: 0.94;
			border-radius: 15rpx;
			display: flex;
			flex-direction: column;

			.tips_pre {
				width: 100%;
				height: 88rpx;
				display: flex;
				align-items: center;
				padding-left: 40rpx;
				box-sizing: border-box;
				border: none;
			}

			button::after {
				border: none;
				border-bottom: 1rpx solid #f1f1f1;
			}

			button[plain] {
				border: none;
			}

			image {
				width: 32rpx;
				height: 32rpx;
				margin-right: 20rpx;
			}

			text {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: rgba(51, 51, 51, 1);
				line-height: 32rpx;
			}
		}
	}

	.icon-you {
		font-size: $font-base;
		color: #888;
	}

	/* 透明遮罩层 */
	.transparent_mask {
		width: 100%;
		height: 100%;
		position: fixed;
		background: rgba(0, 0, 0, 1);
		opacity: 0.4;
		top: 0;
		left: 0;
		z-index: 10;
	}

	.fixed_top_status_bar {
		position: fixed;
		/* #ifdef APP-PLUS */
		height: var(--status-bar-height);
		/* #endif */
		/* #ifndef APP-PLUS */
		height: 0;
		/* #endif */
		top: 0;
		left: 0;
		right: 0;
		z-index: 99;
		background: rgba(250, 250, 250, 0.9);
	}

	.fixed_top_status_bar_no_opcity {
		background: #FFFFFF;
	}

	.nav_list {
		display: flex;
		justify-content: space-between;
		position: fixed;
		width: 750rpx;
		height: 100rpx;
		background: rgba(250, 250, 250, 0.9);
		padding: 0 50rpx 0 20rpx;
		/* #ifdef MP */
		padding-left: 20rpx;
		/* #endif */
		align-items: center;
		z-index: 50;

		.go_back_nav {
			width: 50rpx;
			height: 50rpx;

			image {
				width: 20rpx;
				height: 32rpx;
			}
		}

		.nav_list_pre {
			font-size: 32rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #333333;
			line-height: 32rpx;
			padding-bottom: 5rpx;

		}

		.nav_list_pre_active {
			border-bottom: 5rpx solid #FC1C1C;

		}

		/* 三点更多分享 */
		.more_tips {
			position: relative;
			display: flex;
			align-items: center;

			.more {
				width: 50rpx;
				height: 50rpx;
			}

			.triangle-up {
				position: absolute;
				display: block;
				top: 40rpx;
				left: 25rpx;
				width: 0rpx;
				height: 0rpx;
				background: #FFFFFF;
				border: 1px solid #CCCCCC;

				&::before {
					box-sizing: content-box;
					width: 0;
					height: 0;
					position: absolute;
					top: -2px;
					right: 25rpx;
					padding: 0;
					border-bottom: 8px solid #ffffff;
					border-top: 8px solid transparent;
					border-left: 8px solid transparent;
					border-right: 8px solid transparent;
					display: block;
					content: '';
					z-index: 12;
				}

				&::after {
					box-sizing: content-box;
					width: 0px;
					height: 0px;
					position: absolute;
					top: -5px;
					right: 20rpx;
					padding: 0;
					border-bottom: 9px solid rgba(102, 102, 102, 0.1);
					border-top: 9px solid transparent;
					border-left: 9px solid transparent;
					border-right: 10px solid transparent;
					display: block;
					content: '';
					z-index: 10
				}
			}

			.tips {
				position: absolute;
				z-index: 20;
				top: 70rpx;
				right: -30rpx;
				width: 226rpx;
				background: rgba(255, 255, 255, 1);
				box-shadow: 0px 0px 10rpx 0px rgba(102, 102, 102, 0.2);
				opacity: 0.94;
				border-radius: 15rpx;
				display: flex;
				flex-direction: column;

				.tips_pre {
					width: 100%;
					height: 88rpx;
					display: flex;
					align-items: center;
					padding-left: 40rpx;
					box-sizing: border-box;
				}

				button::after {
					border: none;
					border-bottom: 1rpx solid #f1f1f1;
				}

				button[plain] {
					border: none;
				}

				image {
					width: 32rpx;
					height: 32rpx;
					margin-right: 20rpx;
				}

				text {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: rgba(51, 51, 51, 1);
					line-height: 32rpx;
				}
			}
		}
	}

	.nav_list_no_opcity {
		background: #FFFFFF;
	}

	.carousel {
		height: 750rpx;
		position: relative;
		/* #ifdef APP-PLUS */
		margin-top: var(--status-bar-height);

		/* #endif */
		.swiper-box {
			width: 750rpx;
			height: 750rpx;
		}

		swiper {
			height: 100%;
		}

		.image-wrapper {
			width: 100%;
			height: 100%;
		}

		.swiper-item {
			display: flex;
			justify-content: center;
			align-content: center;
			height: 750rpx;
			overflow: hidden;

			image {
				max-width: 100%;
				max-height: 100%;
			}
		}

	}

	/* 拼团购买按钮start */
	.group_shopping {
		display: flex;
		align-items: center;
	}

	.pinGroup_btn {
		display: flex;
	}

	.group_shopping_alone {
		width: 223rpx;
		height: 70rpx;
		background: linear-gradient(45deg, rgba(255, 121, 24, 1) 0%, rgba(254, 160, 13, 1) 100%);
		border-radius: 34rpx 0 0 34rpx;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.group_alone_price {
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: rgba(255, 255, 255, 1);
		line-height: 30rpx;
	}

	.group_alone_title {
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: rgba(255, 255, 255, 1);
		line-height: 30rpx;
	}

	.go_group {
		width: 197rpx;
		height: 70rpx;
		background: linear-gradient(45deg, rgba(251, 45, 45, 1) 0%, rgba(252, 87, 42, 1) 100%);
		border-radius: 0 34rpx 34rpx 0;
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.go_group_price {
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: rgba(255, 255, 255, 1);
		line-height: 30rpx;
	}

	.go_group_title {
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: rgba(255, 255, 255, 1);
		line-height: 30rpx;
	}

	.make_group {
		display: flex;
		align-items: center;
		width: 100%;
		justify-content: space-between;
	}

	.make_group_num {
		font-size: 26rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: rgba(45, 45, 45, 1);
		line-height: 45rpx;
	}

	.make_groip_more {
		display: flex;
		align-items: center;
	}

	.make_groip_more text {
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: rgba(251, 27, 27, 1);
	}

	.make_groip_more image {
		width: 12rpx;
		height: 20rpx;
	}

	/* 拼团购买按钮end */


	/* 秒杀活动 start */
	.second_kill {
		width: 750rpx;
	}

	.second_kill_con {
		width: 750rpx;
		height: 126rpx;
		padding-left: 114rpx;
		padding-right: 20rpx;
		box-sizing: border-box;
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-top: -2rpx;
	}

	.second_kill_left {
		display: flex;
		flex-direction: column;
		justify-content: center;
	}

	.second_kill_goods_price {
		font-size: 30rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #FFFFFF;
		margin-bottom: 8rpx;
	}

	.second_kill_goods_price text:nth-child(2) {
		font-size: 40rpx;
	}

	.second_kill_price {
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		opacity: 0.8;
	}

	.line_through {
		text-decoration: line-through;
	}

	.second_kill_right {
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}

	.second_kill_text {
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 600;
		color: #FF2930;
		margin-bottom: 20rpx;
	}

	.sec_kill_countdown {
		display: flex;
		align-items: center;
		font-size: 20rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FF333A;
		line-height: 34rpx;
	}

	.sec_kill_countdown .day {
		margin-right: 10rpx;
	}

	.sec_kill_countdown .time {
		background: #FF1F26;
		width: 34rpx;
		height: 34rpx;
		border-radius: 50%;
		line-height: 34rpx;
		text-align: center;
		color: #FFFFFF;
	}

	.sec_kill_countdown .time_tips {
		color: #FF3C42;
		margin: 0 5rpx;
	}

	.sec_kill_preview {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0 20rpx;
		box-sizing: border-box;
		width: 750rpx;
		height: 50rpx;
	}

	.sec_kill_preview_left {
		font-size: 24rpx;
		font-family: PingFang SC;
		font-weight: 500;
		color: #666666;
	}

	.sec_kill_preview_right {
		display: flex;
		align-items: center;
		width: 136px;
		height: 34px;
		background: #FF2B32;
		border-radius: 17px;
		display: flex;
		align-items: center;
		justify-content: center;
		transform: scale(.5);
		margin-right: -34px;
	}

	.sec_kill_preview_right image {
		width: 46rpx;
		height: 48rpx;
		margin: 0 10rpx 0 10rpx;
	}

	.sec_kill_preview_right .tip {
		font-size: 24px;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		line-height: 24px;
		letter-spacing: 2rpx;
	}

	.cancel_preview {
		width: 136px;
		height: 34px;
		background: #999999;
		border-radius: 17px;
		font-size: 22px;
		font-family: PingFang SC;
		font-weight: 500;
		color: #FFFFFF;
		text-align: center;
		line-height: 22px;
		display: flex;
		align-items: center;
		justify-content: center;
		transform: scale(.5);
		margin-right: -34px;
	}

	/* 秒杀活动 end */


	/* 阶梯团活动 */
	.ladder {
		position: relative;
		display: flex;
		align-items: center;
		width: 100%;
		height: 140rpx;
		overflow: hidden;

	}

	/* 阶梯团活动end */

	.addressDefault {
		color: #999999 !important;
	}

	/* 有活动的商品描述详情 start */
	.introduce_section_activity {
		background: #FFFFFF;
		padding: 28rpx 0 30rpx 0;
		margin-bottom: 20rpx;

		.activity_goods_des {
			display: flex;
			justify-content: space-between;
			padding: 0 30rpx 0 21rpx;

			.activity_goods_name {
				width: 533rpx;
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #333333;
				line-height: 48rpx;
				text-overflow: -o-ellipsis-lastline;
				overflow: hidden;
				text-overflow: ellipsis;
				display: -webkit-box;
				-webkit-line-clamp: 2;
				line-clamp: 2;
				-webkit-box-orient: vertical;
			}

			.activity_share_collection {
				display: flex;

				.activity_goods_collection {
					display: flex;
					flex-direction: column;
					align-items: center;
					width: 100rpx;

					.iconfont {
						font-size: 44rpx;
					}

					.iconaixin1 {
						color: #FB1C1C;
					}

					.show_text {
						font-size: 22rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #2D2D2D;
					}
				}

				.activity_goods_share {
					display: flex;
					flex-direction: column;
					align-items: center;
					margin-left: 15rpx;

					.iconfont {
						font-size: 44rpx;
					}

					.show_text {
						font-size: 22rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #2D2D2D;
					}
				}
			}
		}

		.activity_goods_brief {
			width: 681rpx;
			font-size: 28rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #555555;
			line-height: 36rpx;
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
			padding: 0 20rpx;
			box-sizing: border-box;
			margin-top: 8px;
		}
	}

	/* 有活动的商品描述详情 end */

	/* 标题简介 */
	.introduce_section {
		background: #fff;
		padding: 20rpx;
		margin-bottom: 20rpx;

		.price_part {
			.left {
				display: flex;
				flex-direction: column;

				.sell_price {
					color: $main-color;

					.unit {
						font-size: 26rpx;
						font-weight: bold;
					}

					.price_int {
						font-size: 50rpx;
						line-height: 50rpx;
						margin-left: 4rpx;
						font-weight: bold;
					}

					.price_decimal {
						font-size: 26rpx;
						font-weight: bold;
					}
				}

				.original_price {
					color: #949494;
					font-size: 22rpx;
					text-decoration: line-through;
				}
			}

			.right {
				.collection {
					display: flex;
					flex-direction: column;
					width: 72rpx;
					white-space: nowrap;

					.iconaixin1 {
						color: #f80f0c !important;
					}

					.iconaixin {
						color: #2D2D2D;
					}

					text {
						font-size: 22rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #2D2D2D;
					}
				}

				view {
					.iconfont {
						font-size: 50rpx;
						color: #2D2D2D;

						&.active {
							color: $main-color;
						}
					}

					.show_text {
						color: #2D2D2D;
						font-size: 22rpx;

						&.active {
							color: $main-color;
						}
					}

					&:last-child {
						margin-left: 25rpx;
					}
				}
			}
		}

		.goods_name {
			font-size: 32rpx;
			font-weight: 600;
			color: #333;
			line-height: 45rpx;
			overflow: hidden;
			text-overflow: ellipsis;
			display: -webkit-box;
			-webkit-line-clamp: 2;
			-webkit-box-orient: vertical;
			word-break: break-word;
			margin-top: 20rpx;
		}

		.goods_ad {
			color: #666666;
			font-size: 28rpx;
			line-height: 60rpx;
			height: 60rpx;
			overflow: hidden;
			text-overflow: ellipsis;
			white-space: nowrap;
		}


		.coupon-tip {
			align-items: center;
			padding: 4rpx 10rpx;
			background: $uni-color-primary;
			font-size: $font-sm;
			color: #fff;
			border-radius: 6rpx;
			line-height: 1;
			transform: translateY(-4rpx);
		}


	}

	/* 分享 */
	.share-section {
		display: flex;
		align-items: center;
		color: $font-color-base;
		background: linear-gradient(left, #fdf5f6, #fbebf6);
		padding: 12rpx 30rpx;

		.share-icon {
			display: flex;
			align-items: center;
			width: 70rpx;
			height: 30rpx;
			line-height: 1;
			border: 1px solid $uni-color-primary;
			border-radius: 4rpx;
			position: relative;
			overflow: hidden;
			font-size: 22rpx;
			color: $uni-color-primary;

			&:after {
				content: '';
				width: 50rpx;
				height: 50rpx;
				border-radius: 50%;
				left: -20rpx;
				top: -12rpx;
				position: absolute;
				background: $uni-color-primary;
			}
		}

		.icon-xingxing {
			position: relative;
			z-index: 1;
			font-size: 24rpx;
			margin-left: 2rpx;
			margin-right: 10rpx;
			color: #fff;
			line-height: 1;
		}

		.tit {
			font-size: $font-base;
			margin-left: 10rpx;
		}

		.icon-bangzhu1 {
			padding: 10rpx;
			font-size: 30rpx;
			line-height: 1;
		}

		.share-btn {
			flex: 1;
			text-align: right;
			font-size: $font-sm;
			color: $uni-color-primary;
		}

		.icon-you {
			font-size: $font-sm;
			margin-left: 4rpx;
			color: $uni-color-primary;
		}
	}

	.spec_con {
		padding: 20rpx 8rpx 20rpx 20rpx;
		box-sizing: border-box;
		display: flex;
		justify-content: space-between;
		/* align-items: center;
		height: 90rpx; */
		background: #FFFFFF;

		.spec_left {
			display: flex;
			/* align-items: center; */

			.spec_left_title {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #666666;
				line-height: 45rpx;
				margin-right: 35rpx;
			}

			.spec_left_content {
				width: 550rpx;
				/* white-space: nowrap;
				text-overflow: ellipsis;
				overflow: hidden; */
				word-break: break-all;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #343434;
				line-height: 45rpx;
				margin-right: 10rpx;
			}
		}

		.spec_right {
			width: 36rpx;
			height: 36rpx;
		}
	}


	.c-list {
		font-size: $font-sm;
		color: $font-color-base;
		background: #fff;

		.c-row {
			display: flex;
			align-items: center;
			padding: 20rpx 20rpx;
			position: relative;
		}

		.tit {
			color: #666;
			font-size: 26rpx;
			margin-right: 35rpx;
		}

		.con {
			flex: 1;
			color: #333;
			font-size: 28rpx;

			.selected-text {
				margin-right: 10rpx;
			}
		}

		.bz-list {
			height: 40rpx;
			font-size: $font-sm;
			color: $font-color-dark;

			text {
				display: inline-block;
				margin-right: 30rpx;
			}
		}

		.con-list {
			flex: 1;
			display: flex;
			flex-direction: column;
			color: $font-color-dark;
			line-height: 40rpx;
		}

		.red {
			color: $uni-color-primary;
		}
	}

	/* 发货地址及运费 start */
	.deliver_goods {
		background: #FFFFFF;
		border-top: 1rpx solid #f2f2f2;

		.deliver_goods_con {
			margin: 0 20rpx;
			display: flex;
			justify-content: space-between;
			align-items: center;

			.deliver_goods_left {
				display: flex;
				align-items: center;

				.deliver_goods_title {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #666666;
					margin-right: 32rpx;
				}
			}
			
			.deliver_goods_address {
				height: 100rpx;
				display: flex;
				align-items: center;
		
				image {
					width: 34rpx;
					height: 38rpx;
					margin-right: 10rpx;
				}
		
				text {
					display: inline-block;
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
					line-height: 45rpx;
					width: 252rpx;
					overflow: hidden;
					text-overflow: ellipsis;
					white-space: nowrap;
				}
			}
			
			.deliver_goods_right_main {
				width: 610rpx;
				padding-top: 8rpx;
				padding-bottom: 10rpx;
				.deliver_goods_address {
					height: 60rpx;
					margin-bottom: 4rpx;
					text {
						width: 560rpx;
					}
				}
				.deliver_goods_right_bottom {
					display: flex;
					align-items: center;
					justify-content: space-between;
					.deliver_goods_center {
						margin-left: 44rpx;
					}
				}
			}

			.deliver_goods_center {
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #2D2D2D;
				line-height: 45rpx;
			}

			.deliver_goods_right {
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #777777;
				line-height: 45rpx;
			}
		}
	}

	/* 发货地址及运费 end */

	/* 活动 start */
	.activity {
		background: #FFFFFF;
		margin-top: 20rpx;
		padding: 30rpx 0;
		box-sizing: border-box;

		.activity_coupons_tips {
			font-size: 28rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #666666;
			line-height: 45rpx;
			white-space: nowrap;
		}


		/* 领券 start */
		.activity_coupons {
			display: flex;
			justify-content: space-between;
			align-items: center;
			width: 100%;
			padding: 0 8rpx 0 20rpx;

			.activity_coupons_left {
				display: flex;
				align-items: center;


				.activity_coupons_center {
					display: flex;
					align-items: center;

					.activity_coupons_title {
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FC2D2D;
						margin: 0 20rpx 0 35rpx;
					}

					.activity_coupons_list {
						display: flex;
						align-items: center;

						.activity_coupons_pre {
							width: 181rpx;
							height: 42rpx;
							background-size: 100% 100%;
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #FC2D2D;
							line-height: 42rpx;
							text-align: center;
							margin-right: 20rpx;
						}
						
						.activity_coupons_pre_short {
							padding-left: 10rpx;
							overflow: hidden;
							white-space: nowrap;
							text-overflow: ellipsis;
						}
					}
				}
			}

			.activity_conpons_right {
				width: 36rpx;
				height: 36rpx;

				image {
					width: 36rpx;
					height: 36rpx;
				}
			}
		}

		/* 领券 end */
		/* 满优惠 start */
		.full_discount {
			padding-left: 109rpx;
			display: flex;
			align-items: center;
			margin-top: 28rpx;
			padding-right: 20rpx;

			&.padd20 {
				padding-left: 20rpx !important;
				margin-top: 0rpx !important;
			}

			.full_discount_title {
				white-space: nowrap;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FC2D2D;
			}

			.discount_title_no_ma {
				line-height: 46rpx;
				margin-left: 20rpx;
			}

			.full_discount_list {
				/* #ifdef MP-WEIXIN */
				/* display: -webkit-box; */
				display: flex;
				flex-wrap: wrap;
				margin-left: 8rpx;
				overflow: hidden;
				/* #endif */
				/* #ifndef MP-WEIXIN */
				display: flex;
				align-items: flex-start;
				margin-left: 19rpx;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #333333;
				white-space: nowrap;
				word-break: break-all;
				text-overflow: ellipsis;
				overflow: hidden;
				/* #endif */
			}
		}

		/* 满优惠 end */
	}

	/* 活动 end */
	/* .full_discount_list view /deep/ div {
		white-space: nowrap;
		text-overflow: ellipsis;
		overflow: hidden;
		word-break: break-all;
		width: 500rpx;
	} */

	/* #ifdef MP-TOUTIAO */
	.full_discount_list .interlayer {
		white-space: nowrap;
		text-overflow: ellipsis;
		overflow: hidden;
		word-break: break-all;
		width: 500rpx;
	}

	/* #endif */


	/* 积分 start */
	.integral {
		background: #FFFFFF;

		.integral_content {
			border-top: 1rpx solid #f2f2f2;
			display: flex;
			align-items: center;
			height: 100rpx;
			padding: 0 20rpx;

			.integral_title {
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #666666;
			}

			.integral_con {
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #333333;
				margin-left: 35rpx;
			}
		}
	}

	/* 积分 end */

	/* 服务 start */
	.service {
		height: 90rpx;
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 0 8rpx 0 20rpx;
		box-sizing: border-box;
		background: #FFFFFF;
		margin-top: 20rpx;

		.service_left {
			display: flex;
			align-items: center;
			height: 90rpx;

			.service_title {
				font-size: 26rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #666666;
				line-height: 45rpx;
				margin-right: 37rpx;
			}

			.service_con {
				display: flex;
				align-items: center;
				display: inline;
				width: 580rpx;
				overflow: hidden;
				text-overflow: ellipsis;
				word-break: break-all;
				white-space: nowrap;

				.service_pre {
					display: inline-block;
					margin-right: 20rpx;

					.service_pre_tips {
						width: 5rpx;
						height: 5rpx;
						background: #FF0000;
						border-radius: 50%;
						margin-right: 10rpx;
						display: inline-block;
						vertical-align: middle;
					}

					text:nth-child(2) {
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 400;
						color: #555555;
						line-height: 90rpx;
					}
				}
			}
		}

		.service_right {
			display: flex;
			align-items: center;

			image {
				width: 36rpx;
				height: 36rpx;
			}
		}
	}

	/* 服务 end */

	/* 服务弹框 start */
	.service_model {
		width: 100%;
		height: 640rpx;
		background: #FFFFFF;
		border-radius: 15rpx 15rpx 0 0;

		.service_model_top {
			width: 100%;
			height: 100rpx;
			border-radius: 15rpx 15rpx 0 0;
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding: 0 12rpx 0 30rpx;
			box-sizing: border-box;
			z-index: 10;
			border-bottom: 1rpx solid #f2f2f2;

			text {
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #333333;
				line-height: 32rpx;
			}

			image {
				width: 46rpx;
				height: 46rpx;
			}
		}

		.service_model_list {
			box-sizing: border-box;
			height: 540rpx;

			.service_list_pre {
				margin-left: 30rpx;
				border-bottom: 1rpx solid #F5F5F5;
				padding: 30rpx 30rpx 30rpx 0;
				box-sizing: border-box;

				.service_list_title {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #333333;
					line-height: 45rpx;
				}

				.service_list_des {
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 400;
					color: #999999;
					line-height: 45rpx;
					margin-top: 19rpx;
					word-break: break-all;
				}
			}
		}
	}

	/* 服务弹框 end */

	/* 优惠券弹框 start */
	.coupon_model {
		width: 100%;
		height: 900rpx;
		background: #F5F5F5;
		border-radius: 15rpx 15rpx 0 0;

		.coupon_model_title {
			width: 100%;
			height: 100rpx;
			border-radius: 15rpx 15rpx 0 0;
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding: 0 12rpx 0 30rpx;
			box-sizing: border-box;
			position: absolute;
			z-index: 10;
			top: 0;
			background: #FFFFFF;
			border-bottom: 1rpx solid #f2f2f2;

			text {
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #333333;
				line-height: 32rpx;
			}

			image {
				width: 46rpx;
				height: 46rpx;
			}
		}

		.coupon_model_list {
			box-sizing: border-box;
			height: 880rpx;
			width: 750rpx;
			overflow-x: hidden;
			padding: 120rpx 20rpx 0;
			box-sizing: border-box;

			.my_coupon_pre {
				margin-bottom: 20rpx;
				position: relative;

				.coupon_pre_top {
					width: 710rpx;
					height: 190rpx;
					background-size: 100% 100%;
					display: flex;
					align-items: center;

					.coupon_pre_left {
						display: flex;
						flex-direction: column;
						width: 203rpx;
						align-items: center;

						.coupon_pre_price {
							font-size: 20rpx;
							font-family: Source Han Sans CN;
							font-weight: bold;
							color: #F20C06;
							line-height: 31rpx;
							display: flex;
							align-items: baseline;
							text:nth-child(2) {
								font-size: 48rpx;
								font-family: Source Han Sans CN;
								font-weight: bold;
								color: #F30801;
								line-height: 31rpx;
							}
							
							.price_int {
								text-align: center;
								word-break: break-all;
							}
						}
						
						.coupon_pre_price_high {
							position: relative;
							left: 2rpx;
							top: 14rpx;
							margin-top: 8rpx;
							text:nth-child(2){
								line-height: 40rpx;
							}
						}

						.coupon_pre_active {
							font-size: 24rpx;
							font-family: Source Han Sans CN;
							font-weight: 400;
							color: #F6130E;
							line-height: 31rpx;
							text-align: center;
							margin-top: 20rpx;
						}
					}

					.coupon_pre_cen {
						display: felx;
						flex-direction: column;
						flex: 1;
						padding-left: 44rpx;

						.coupon_pre_title {
							font-size: 30rpx;
							font-family: PingFang SC;
							font-weight: bold;
							color: #111111;
							line-height: 31rpx;
						}

						.coupon_pre_time {
							font-size: 24rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #333333;
							line-height: 31rpx;
							margin: 21rpx 0 17rpx;
						}

						.coupon_pre_rules {
							display: flex;
							align-items: center;

							text {
								font-size: 24rpx;
								font-family: PingFang SC;
								font-weight: 500;
								color: #999999;
								line-height: 31rpx;
							}

							image {
								width: 12rpx;
								height: 7rpx;
								margin-left: 20rpx;
							}
						}
					}

					.coupon_pre_right {
						width: 130rpx;
						box-sizing: border-box;
						font-size: 24rpx;
						font-family: Source Han Sans CN;
						font-weight: 400;
						color: #FFFFFF;
						text-align: center;
					}
				}

				.coupon_rules {
					width: 710rpx;
					padding: 20rpx 0 20rpx 43rpx;
					box-sizing: border-box;
					font-size: 22rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #666666;
					line-height: 30rpx;
					background: #FFFFFF;
					border-top: 1rpx solid #f2f2f2;
					border-radius: 0 0 15rpx 15rpx;

					.coupon_rules_title {
						margin-bottom: 10rpx;
					}
				}

				.coupon_type {
					position: absolute;
					top: 0;
					left: 0;
					padding: 0 5rpx;
					height: 30rpx;
					background: linear-gradient(0deg, #FF3000 0%, #FB3E31 0%, #FF3728 0%, #FF142F 100%);
					font-size: 20rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					color: #FFFFFF;
					line-height: 30rpx;
					text-align: center;
					border-radius: 15rpx 0 15rpx 0;
				}

				.coupon_progress {
					position: absolute;
					width: 130rpx;
					top: 10rpx;
					right: 0rpx;
					display: flex;
					flex-direction: column;
					align-items: center;
					font-size: 18rpx;
					font-family: Source Han Sans CN;
					font-weight: 400;
					color: #FFFFFF;
					line-height: 31rpx;

					.progress_con {
						width: 84rpx;
						margin-top: 5rpx;
						border-radius: 5rpx;

						progress {
							border: 1rpx solid #FFFFFF;
							border-radius: 5rpx;
						}
					}
				}
			}
		}
	}

	/* 优惠券弹框 end */

	/* 满优惠弹框 */
	.fulldis_model {
		width: 100%;
		height: 900rpx;
		background: #FFFFFF;
		border-radius: 15rpx 15rpx 0 0;

		.fulldis_model_title {
			width: 100%;
			height: 100rpx;
			border-radius: 15rpx 15rpx 0 0;
			display: flex;
			align-items: center;
			justify-content: space-between;
			padding: 0 12rpx 0 30rpx;
			box-sizing: border-box;
			position: absolute;
			z-index: 10;
			top: 0;
			background: #FFFFFF;
			border-bottom: 1rpx solid #f2f2f2;

			text {
				font-size: 32rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #333333;
				line-height: 32rpx;
			}

			image {
				width: 46rpx;
				height: 46rpx;
			}
		}

		.fulldis_model_list {
			padding-top: 150rpx;
			box-sizing: border-box;
			width: 750rpx;
			height: 720rpx;
			/* background: #FFFFFF; */
			border-radius: 15rpx 15rpx 0 0;

			.fulldis_model_pre {
				display: flex;
				padding-left: 44rpx;
				box-sizing: border-box;
				margin-bottom: 57rpx;
				flex-shrink: 0;

				.fulldis_pre_tips {
					width: 10rpx;
					height: 10rpx;
					background: #FF3636;
					border-radius: 50%;
					margin-top: 15rpx;
				}

				.fulldis_pre_con {
					width: 650rpx;
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: bold;
					color: #333333;
					line-height: 39rpx;
					margin-left: 20rpx;
				}
			}
		}

		.full_dis_tips {
			font-size: 22rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #999999;
			line-height: 38rpx;
			padding: 20rpx 69rpx 60rpx 66rpx;
			box-sizing: border-box;
			background: #FFFFFF;
		}
	}


	/* 评价 start*/
	.eva_section {
		display: flex;
		flex-direction: column;
		padding: 30rpx 0 30rpx;
		background: #fff;
		margin-top: 20rpx;

		.e_header {
			height: 33rpx;
			display: flex;
			align-items: center;
			padding: 0 8rpx 0 20rpx;
			box-sizing: border-box;

			.left {
				color: #333333;

				/* 				display: flex;
				align-items: center; */
				.tit {
					font-size: 30rpx;
				}

				.e_num {
					font-size: 30rpx;
					margin-left: 6rpx;
					padding-bottom: 4rpx;
				}

				.e_rate {
					color: #666;
					font-size: 22rpx;
					margin-left: 19rpx;
				}
			}

			.right {
				color: #666666;

				.view_more {
					font-size: 24rpx;
				}

				.iconfont {
					font-size: 18rpx;
				}
			}
		}

		.eva_box {
			.e_member_info {
				margin-top: 30rpx;
				padding: 0 20rpx;

				.portrait {
					width: 50rpx;
					height: 50rpx;
					border-radius: 50%;
				}

				.name {
					color: #2D2D2D;
					font-size: 26rpx;
					margin: 0 20rpx;
				}
			}

			.con {
				color: #333333;
				font-size: 26rpx;
				line-height: 38rpx;
				overflow: hidden;
				text-overflow: ellipsis;
				display: -webkit-box;
				-webkit-line-clamp: 2;
				-webkit-box-orient: vertical;
				word-break: break-word;
				width: 710rpx;
				margin: 20rpx auto 0;
			}

			.view_more_eva {
				width: 100%;
				color: #2D2D2D;
				font-size: 26rpx;
				margin-top: 22rpx;

				&:before {
					content: ' ';
					width: 160rpx;
					height: 1rpx;
					background: rgba(0, 0, 0, .1);
					margin-right: 20rpx;
				}

				&:after {
					content: ' ';
					width: 160rpx;
					height: 1rpx;
					background: rgba(0, 0, 0, .1);
					margin-left: 20rpx;
				}
			}
		}
	}

	/* 评价 end */

	/* 买家秀 start */
	.buy_show {
		background: #FFFFFF;

		.buy_show_top {
			height: 80rpx;
			border-top: 1rpx solid #f2f2f2;
			margin: 0 20rpx;
			padding: 31rpx 0 20rpx 0;
			display: flex;
			align-items: center;
			justify-content: space-between;

			.buy_show_title {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #2D2D2D;
			}

			.buy_show_more {
				text {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #FC281F;
					line-height: 45rpx;
				}

				image {
					width: 12rpx;
					height: 20rpx;
					margin-left: 18rpx;
				}
			}
		}

		.buy_show_con {
			display: flex;
			align-items: center;
			padding-bottom: 20rpx;

			.buy_show_pre {
				width: 177rpx;
				height: 177rpx;
			}

			.buy_show_pre:nth-child(1) {
				border-radius: 15rpx 0 0 15rpx;
			}

			.buy_show_pre:nth-last-child(1) {
				border-radius: 0 15rpx 15rpx 0;
			}

			.only {
				border-radius: 15rpx;
			}
		}
	}

	/* 买家秀 end */

	/* 店铺 start */
	.shop {
		background-color: #FFFFFF;
		margin-top: 20rpx;
		padding-top: 30rpx;

		.shop_des {
			display: flex;
			align-items: center;

			.shop_des_image {
				width: 100rpx;
				height: 100rpx;
				border-radius: 15rpx;
				margin: 0 20rpx;

				image {
					width: 100rpx;
					height: 100rpx;
					border-radius: 15rpx;
				}
			}

			.shop_des_con {
				display: flex;
				flex-direction: column;
				justify-content: center;

				.shop_con_title {
					font-size: 32rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #2D2D2D;
					line-height: 45rpx;
				}

				.shop_con_type {
					display: flex;
					align-items: center;

					.shop_type {
						width: 60px;
						height: 30px;
						color: #FFFFFF;
						background: #F30300;
						border-radius: 15px;
						font-size: 26px;
						text-align: center;
						line-height: 30px;
						display: flex;
						align-items: center;
						justify-content: center;
						transform: scale(0.5);
						margin-left: -15px;
						margin-right: -15px;
					}

					.shop_follow_num {
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #999999;
						line-height: 45rpx;
						margin-left: 20rpx;
					}
				}
			}
		}

		.shop_des_list {
			display: flex;
			align-items: center;
			padding: 0 20rpx 30rpx 20rpx;
			margin-top: 30rpx;

			.shop_des_pre {
				display: flex;
				align-items: center;
				border-right: 1rpx solid #f2f2f2;
				padding-right: 25rpx;
				margin-right: 25rpx;
				white-space: nowrap;

				&:nth-last-child(1) {
					padding-right: 0;
					margin-right: 0;
					border-right: 0;
				}

				text:nth-of-type(1) {
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #555555;
					line-height: 45rpx;
					white-space: nowrap;
				}

				text:nth-of-type(2) {
					font-size: 24rpx;
					font-family: PingFang SC;
					font-weight: bold;
					color: #F5100D;
					line-height: 45rpx;
					margin: 0 8rpx;
					white-space: nowrap;
				}

				image {
					width: 30rpx;
					height: 30rpx;
				}
			}
		}

		.shop_links {
			height: 108rpx;
			border-top: 1rpx solid #f2f2f2;
			display: flex;
			justify-content: space-between;
			padding: 0 149rpx 0 161rpx;
			box-sizing: border-box;
			align-items: center;

			image {
				width: 172rpx;
				height: 48rpx;
			}
		}
	}

	/* 店铺 end */

	/* 店铺推荐 start */
	.store_recommend {
		background-color: #FFFFFF;
		margin-top: 20rpx;
		padding-top: 30rpx;

		.store_recommend_top {
			display: flex;
			justify-content: space-between;
			align-items: center;
			padding: 0 20rpx;
			margin-bottom: 30rpx;

			.store_recommend_title {
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #333333;
				line-height: 45rpx;
			}

			.store_recommend_more {
				text {
					font-size: 26rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #FC281F;
					line-height: 45rpx;
				}

				image {
					width: 12rpx;
					height: 20rpx;
					margin-left: 18rpx;
				}
			}
		}

		.store_recommend_list {
			display: flex;
			flex-wrap: wrap;
			padding: 0 20rpx;

			.store_recommend_pre {
				margin-right: 20rpx;
				margin-bottom: 30rpx;

				&:nth-of-type(3n) {
					margin-right: 0;
				}

				.store_reco_pre_image {
					position: relative;
					width: 223rpx;
					height: 223rpx;
					border-radius: 15rpx;
					overflow: hidden;

					.image {
						background-position: center center;
						background-repeat: no-repeat;
						background-size: cover;
						width: 223rpx;
						height: 223rpx;
						border-radius: 15rpx;
					}

					.store_reco_pre_price {
						width: 223rpx;
						height: 40rpx;
						background: rgba(0, 0, 0, 0.3);
						border-radius: 0 0 15rpx 15rpx;
						position: absolute;
						bottom: 0;
						left: 0;
						font-size: 20rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #FFFFFF;
						text-align: center;

						text:nth-child(2) {
							font-size: 26rpx;
						}
					}
				}

				.store_reco_pre_name {
					font-size: 28rpx;
					font-family: PingFang SC;
					font-weight: 500;
					color: #2D2D2D;
					line-height: 36rpx;
					width: 223rpx;
					text-overflow: -o-ellipsis-lastline;
					overflow: hidden;
					text-overflow: ellipsis;
					display: -webkit-box;
					-webkit-line-clamp: 2;
					line-clamp: 2;
					-webkit-box-orient: vertical;
					margin-top: 20rpx;
				}
			}
		}
	}

	/* 店铺推荐 end */

	/* 规格参数 start */
	.spec_param {
		background: #FFFFFF;
		margin-top: 20rpx;
		padding-bottom: 30rpx;

		.spec_param_title {
			display: flex;
			flex-direction: column;
			padding: 30rpx 0 0 38rpx;

			text {
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #2D2D2D;
				line-height: 36rpx;
			}

			.image {
				width: 660rpx;
				height: 22rpx;
				background-position: center center;
				background-repeat: no-repeat;
				background-size: cover;
			}

		}

		.spec_param_list {
			padding: 0 20rpx;
			max-height: 350rpx;
			margin-top: 20rpx;
			box-sizing: border-box;
			overflow: hidden;

			.spec_param_pre {
				width: 710rpx;
				display: flex;
				align-items: center;
				font-size: 24rpx;
				font-family: Source Han Sans CN;
				font-weight: 400;
				color: #777777;
				line-height: 36rpx;
				border: 1rpx solid #f2f2f2;
				border-bottom: 0;
				padding: 8rpx 0;

				view:nth-child(1) {
					display: flex;
					align-items: center;
					width: 200rpx;
					display: inline-block;
					justify-content: flex-end;
					/* line-height: 70rpx; */
					text-align: right;
					padding: 0 20rpx;
					height: 100%;
				}

				view:nth-child(2) {
					width: 541rpx;
					/* height: 70rpx; */
					line-height: 72rpx;
					padding-left: 20rpx;
					box-sizing: border-box;
					border-left: 1rpx solid #f2f2f2;
				}
			}

			.spec_param_pre:nth-last-child(1) {
				border-bottom: 1rpx solid #F2F2F2;
			}
		}

		.open_param {
			height: auto;
			max-height: unset;
		}

		.spec_param_fold {
			display: flex;
			align-items: center;
			justify-content: center;
			padding-top: 30rpx;

			text {
				font-size: 24rpx;
				font-family: Source Han Sans CN;
				font-weight: 400;
				color: #777777;
			}

			image {
				width: 20rpx;
				height: 12rpx;
				margin-left: 10rpx;
			}
		}
	}

	/* 规格参数 end */

	/*  详情 */
	.detail-desc {
		background: #fff;
		margin-top: 20rpx;
		overflow-x: hidden;
		padding: 30rpx 20rpx;
		box-sizing: border-box;

		.detail-desc_title {
			margin-bottom: 30rpx;
			display: flex;
			flex-direction: column;

			text {
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: bold;
				color: #2D2D2D;
				line-height: 36rpx;
				text-align: center;
			}

			.image {
				width: 660rpx;
				height: 22rpx;
				background-position: center center;
				background-repeat: no-repeat;
				background-size: contain;
			}

		}
	}

	/*  弹出层 */
	.popup {
		position: fixed;
		left: 0;
		top: 0;
		right: 0;
		bottom: 0;
		z-index: 99;

		&.show {
			display: block;

			.mask {
				animation: showPopup 0.2s linear both;
			}

			.layer {
				animation: showLayer 0.2s linear both;
			}
		}

		&.hide {
			.mask {
				animation: hidePopup 0.2s linear both;
			}

			.layer {
				animation: hideLayer 0.2s linear both;
			}
		}

		&.none {
			display: none;
		}

		.mask {
			position: fixed;
			top: 0;
			width: 100%;
			height: 100%;
			z-index: 1;
			background-color: rgba(0, 0, 0, 0.4);
		}

		.layer {
			position: fixed;
			z-index: 99;
			bottom: 0;
			width: 100%;
			min-height: 40vh;
			border-radius: 10rpx 10rpx 0 0;
			background-color: #fff;

			.btn {
				height: 66rpx;
				line-height: 66rpx;
				border-radius: 100rpx;
				background: $uni-color-primary;
				font-size: $font-base;
				color: #fff;
				margin: 30rpx auto 20rpx;
			}
		}

		.back_view {
			display: flex;
			align-items: center;

			image {
				width: 30rpx;
				height: 30rpx;
			}

			text {
				font-size: 28rpx;
			}
		}

		@keyframes showPopup {
			0% {
				opacity: 0;
			}

			100% {
				opacity: 1;
			}
		}

		@keyframes hidePopup {
			0% {
				opacity: 1;
			}

			100% {
				opacity: 0;
			}
		}

		@keyframes showLayer {
			0% {
				transform: translateY(120%);
			}

			100% {
				transform: translateY(0%);
			}
		}

		@keyframes hideLayer {
			0% {
				transform: translateY(0);
			}

			100% {
				transform: translateY(120%);
			}
		}
	}

	.uni-swiper-dot,
	.swiper-box,
	.video_btn,
	.swiper_item,
	.slide-image {
		width: 100%;
		height: 750rpx;
	}

	.videoImage {
		width: 100%;
		height: 750rpx;
		background-position: center center;
		background-repeat: no-repeat;
		background-size: cover;
	}
	
	.bottom_block {
		width: 750rpx;
		height: calc(100rpx + constant(safe-area-inset-bottom));
		/* 兼容 iOS < 11.2 */
		height: calc(100rpx + env(safe-area-inset-bottom));
		/* 兼容 iOS >= 11.2 */
	}

	/* 底部操作菜单 */
	.page_bottom {
		position: fixed;
		left: 0rpx;
		right: 0rpx;
		margin: 0 auto;
		bottom: 0rpx;
		z-index: 95;
		display: flex;
		justify-content: space-evenly;
		align-items: center;
		width: 750rpx;
		/*height: 98rpx;*/
		background: #fff;
		box-shadow: 0px 0px 20px 0px rgba(86, 86, 86, 0.2);
		padding-bottom: constant(safe-area-inset-bottom);
		/* 兼容 iOS < 11.2 */
		padding-bottom: env(safe-area-inset-bottom);
		/* 兼容 iOS >= 11.2 */
		box-sizing: border-box;

		.p_b_btn {
			display: flex;
			flex-direction: column;
			align-items: center;
			justify-content: center;
			font-size: $font-sm;
			color: $font-color-base;
			width: 96rpx;
			height: 80rpx;
			position: relative;
			margin-top: 12rpx;

			image {
				width: 40rpx;
				height: 40rpx;
				margin-bottom: 10rpx;
			}

			.show_text {
				color: #2D2D2D;
				font-size: 20rpx;
			}


			.cart_num {
				position: absolute;
				width: 30rpx;
				height: 30rpx;
				text-align: center;
				background: rgba(252, 45, 45, 1);
				border-radius: 50%;
				font-size: 18rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: rgba(255, 255, 255, 1);
				line-height: 30rpx;
				right: 10rpx;
				top: -8rpx;
				z-index: 5;
			}

		}

		.ladder_btn {
			width: 420rpx;
			height: 70rpx;
			background: linear-gradient(45deg, rgba(255, 122, 24, 1) 0%, rgba(254, 161, 14, 1) 100%);
			border-radius: 35rpx;
			font-size: 28rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: rgba(255, 255, 255, 1);
			line-height: 70rpx;
			text-align: center;
		}

		.action_btn_group {
			display: flex;
			height: 70rpx;
			overflow: hidden;
			margin-left: 20rpx;

			.action_btn {
				height: 100%;
				font-size: 32rpx;
				color: #fff;

				&::after {
					border: none;
				}
			}

			.add_cart_btn {
				width: 223rpx;
				background: #FF821C;
				border-radius: 35rpx 0 0 35rpx;
			}

			.buy_now_btn {
				width: 197rpx;
				background: #F30300;
				border-radius: 0 35rpx 35rpx 0;
			}

			.virtual_buy {
				width: 420rpx;
				background: #F30300;
				border-radius: 35rpx;
			}

			.not_stock {
				width: 420rpx;
				background: #ADADAD;
				border-radius: 35rpx;
			}

			.instant_second_kill {
				width: 420rpx;
				height: 70rpx;
				background: linear-gradient(45deg, rgba(252, 45, 45, 1) 0%, rgba(253, 87, 43, 1) 100%);
				border-radius: 35rpx;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: rgba(255, 255, 255, 1);
				line-height: 30rpx;
				display: flex;
				align-items: center;
				justify-content: center;
			}

			.instant_pay_deposit {
				width: 420rpx;
				height: 70rpx;
				background: linear-gradient(45deg, #FF7A18 0%, #FEA10E 100%);
				border-radius: 35rpx;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
				line-height: 26rpx;
			}

			.seckill_finished {
				width: 420rpx;
				height: 70rpx;
				background: #999999;
				border-radius: 35rpx;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
				line-height: 30rpx;
			}

			.preSale_btn_deposit {
				width: 420rpx;
				height: 70rpx;
				background: linear-gradient(45deg, #FF7A18 0%, #FEA10E 100%);
				border-radius: 35rpx;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				line-height: 30rpx;
				padding: 0 20rpx;
			}

			.preSale_btn_buy {
				height: 70rpx;
				background: linear-gradient(45deg, rgba(252, 45, 45, 1) 0%, rgba(253, 87, 43, 1) 100%);
				border-radius: 0 35rpx 35rpx 0;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: rgba(255, 255, 255, 1);
				line-height: 30rpx;
				padding: 0 30rpx;
			}
		}
	}

	.share_model {
		width: 750rpx;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		margin: 0 auto;
		background: rgba(0, 0, 0, 0.6);
		z-index: 100;
	}

	.share_model_list {
		display: flex;
		justify-content: space-around;
		padding: 0 50rpx;
		box-sizing: border-box;
		position: fixed;
		bottom: 150rpx;
		/* #ifdef MP */
		bottom: 130rpx;
		/* #endif */
		z-index: 110;
		width: 750rpx;

		.share_model_pre {
			display: flex;
			flex-direction: column;
			align-items: center;
			background: transparent;
			border-radius: 0;
			height: auto;
			line-height: auto;

			&::after {
				border-width: 0;
			}

			image {
				width: 105rpx;
				height: 105rpx;
			}

			text {
				font-size: 24rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
				line-height: 36rpx;
				margin-top: 30rpx;
			}
		}
	}

	.share_model_close {
		width: 46rpx;
		height: 46rpx;
		bottom: 60rpx;
		/* #ifdef MP */
		bottom: 40rpx;
		/* #endif */
		position: fixed;
		z-index: 110;
		left: 0;
		right: 0;
		margin: 0 auto;

		image {
			width: 46rpx;
			height: 46rpx;
		}
	}

	button {
		padding: 0;
		margin: 0;
	}

	.poster {
		width: 750rpx;
		height: 100%;
		position: fixed;
		top: 0;
		left: 0;
		right: 0;
		margin: 0 auto;
		background: rgba(0, 0, 0, 0.6);
		z-index: 100;

		.poster_image {
			width: 541rpx;
			height: 837rpx;
			background: #FFFFFF;
			border-radius: 20rpx;
			position: absolute;
			left: 105rpx;
			/* #ifdef H5 */
			bottom: 360rpx;
			/* #endif */
			/* #ifdef APP-PLUS */
			bottom: 380rpx;
			/* #endif */
			/* #ifdef MP */
			bottom: 320rpx;
			/* #endif */
		}

		.poster_share_img {
			width: 390rpx;
			height: 90rpx;
			/* left: 179rpx; */
			position: absolute;
			bottom: 177rpx;
			margin: 72rpx 0 22rpx;
		}

		.poster_share_close {
			width: 49rpx;
			height: 49rpx;
			position: absolute;
			/* left: 351rpx; */
			bottom: 105rpx;
		}

		/* #ifdef H5 */
		.poster_share_model {
			width: 750rpx;
			height: 100%;
			position: fixed;
			display: flex;
			flex-direction: column;
			justify-content: center;
			align-items: center;

			.poster_image {
				width: 541rpx;
				height: 837rpx;
				background: #FFFFFF;
				border-radius: 20rpx;
			}

			.poster_share_img {
				width: 390rpx;
				height: 90rpx;
				margin: 72rpx 0 22rpx;
			}

			.poster_share_close {
				width: 49rpx;
				height: 49rpx;
			}
		}

		/* #endif */
	}


	.spec_model_con {
		width: 750rpx;
		height: 900rpx;
		background: #FFFFFF;
		border-radius: 10rpx 10rpx 0;
		position: fixed;
		bottom: 0;
		left: 0;
		right: 0;
		margin: 0 auto;
		z-index: 150;

		.spec_model_content {
			padding-bottom: 115rpx;

			.spec_model_top {
				display: flex;
				justify-content: space-between;
				padding: 30rpx 22rpx 0 30rpx;
				box-sizing: border-box;

				.spec_model_goods {
					display: flex;
					height: 151rpx;
					/* align-items: center; */

					.spec_goods_image {
						width: 151rpx;
						height: 151rpx;
						background: #EEEEEE;
						border-radius: 15rpx;

						image {
							width: 151rpx;
							height: 151rpx;
							border-radius: 15rpx;
						}
					}

					.spec_goods_right {
						margin-left: 30rpx;
						flex-shrink: 0;

						.spec_goods_price_con {
							display: flex;
							align-items: center;

							.spec_prices {
								.spec_goods_price {
									display: inline-block;

									text {
										font-size: 24rpx;
										font-family: PingFang SC;
										font-weight: 500;
										color: #FC1C1C;
									}

									text:nth-child(2) {
										font-size: 50rpx;
									}
								}
							}

							.sec_kill_tips {
								width: 130rpx;
								height: 40rpx;
								background: linear-gradient(90deg, #FFAA06 0%, #FF8323 0%, #FC5300 0%, #FF1353 100%);
								border-radius: 20rpx;
								font-size: 24rpx;
								font-family: PingFang SC;
								font-weight: 500;
								color: #FFFFFF;
								text-align: center;
								line-height: 40rpx;
								margin-left: 20px;
							}

							.pre_sale_tips {
								width: 76rpx;
								height: 38rpx;
								background: linear-gradient(90deg, #891ff7, #da01e8);
								border-radius: 18rpx;
								font-size: 22rpx;
								font-family: PingFang SC;
								font-weight: 500;
								color: #fff;
								display: flex;
								align-items: center;
								justify-content: center;
								margin-left: 20px;
							}

							.ladder_regiment_tips {
								width: 100rpx;
								height: 40rpx;
								background: linear-gradient(90deg, #FF7A18 0%, #FEA10E 100%);
								border-radius: 20rpx;
								font-size: 24rpx;
								font-family: PingFang SC;
								font-weight: 500;
								color: #FFFFFF;
								display: flex;
								align-items: center;
								justify-content: center;
								margin-left: 20rpx;
							}

							.pin_tips {
								width: 80rpx;
								height: 40rpx;
								background: linear-gradient(90deg, #FC1C1C 0%, #FF6C00 100%);
								border-radius: 20rpx;
								font-size: 24rpx;
								font-family: PingFang SC;
								font-weight: 500;
								color: #FFFFFF;
								display: flex;
								align-items: center;
								justify-content: center;
								margin-left: 20rpx;
							}
						}

						.spec_goods_des {
							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #343434;
							margin-top: 19rpx;
							width: 520rpx;
							/* white-space: nowrap;
							text-overflow: ellipsis;
							overflow: hidden; */
							word-break: break-all;
						}
					}
				}

				.close_spec {
					position: absolute;
					top: 14rpx;
					right: 14rpx;
					z-index: 9;
					width: 46rpx;
					height: 46rpx;
				}
			}

			.spec_content {
				height: 620rpx;

				.spec_list {
					margin: 0 30rpx;
					padding-top: 34rpx;

					.spec_list_pre {
						border-bottom: 1rpx solid #F5F5F5;

						.spec_list_pre_name {
							font-size: 28rpx;
							font-family: PingFang SC;
							font-weight: 500;
							color: #666666;
							margin-bottom: 30rpx;
						}

						.spec_list_pre_desc {
							display: inline-table;
							padding: 13rpx 25rpx;
							box-sizing: border-box;
							box-sizing: border-box;
							background: #F5F5F5;
							border-radius: 50rpx;
							margin-bottom: 30rpx;
							margin-right: 30rpx;
							border: 1rpx solid #F5F5F5;

							.spec_list_pre_con {
								display: flex;
								align-items: center;

								text {
									font-size: 26rpx;
									font-family: PingFang SC;
									font-weight: 500;
									color: #343434;
									text-align: center;
								}

								image {
									width: 36rpx;
									height: 36rpx;
									margin-right: 20rpx;
								}
							}
						}

						.spec_list_pre_desc_active {
							background: #FFFFFF;
							border: 1rpx solid #FC1C1C;

							.spec_list_pre_con {
								text {
									color: #FC1C1C;
								}
							}
						}

						.spec_list_pre_desc_disabled {
							background: #F5F5F5;
							opacity: 0.2;

							.spec_list_pre_con {
								text {
									color: #2D2D2D;
								}
							}
						}
					}
				}

				.spec_num {
					height: 50rpx;
					display: flex;
					justify-content: space-between;
					align-items: center;
					padding: 0 20rpx 0 30rpx;
					box-sizing: border-box;
					margin-top: 16rpx;

					.spec_num_left {
						font-size: 28rpx;
						font-family: PingFang SC;
						font-weight: 500;
						color: #666666;

						text {
							color: #949494;
						}
					}

					.spec_num_right {
						width: 182rpx;
						height: 50rpx;
						border: 1rpx solid #EDEDED;
						border-radius: 6rpx;
						display: flex;
						justify-content: center;
						align-items: center;
						font-size: 24rpx;
						font-family: PingFang SC;
						font-weight: bold;
						color: #A6A6A6;
						line-height: 30rpx;

						text {
							width: 51rpx;
							height: 50rpx;
							text-align: center;
							line-height: 50rpx;
							border-left: 1rpx solid #EDEDED;

							&.no_edit {
								background: #F8F8F8;
								opacity: 0.5;
								color: #949494;
							}
						}

						text:nth-child(1) {
							color: #949494;
							border-right: 1rpx solid #EDEDED;
							border-left: none;
						}

						input {
							width: 78rpx;
							height: 50rpx;
							line-height: 50rpx;
							text-align: center;
							font-size: 24rpx;
							/* #ifdef MP-ALIPAY */
							border-top: 1rpx solid #EDEDED;
							border-bottom: 1rpx solid #EDEDED;
							/* #endif */
						}
					}
				}
			}
		}

		.spec_btn {
			width: 750rpx;
			height: 98rpx;
			background: #FFFFFF;
			box-shadow: 0rpx 0rpx 20rpx 0rpx rgba(86, 86, 86, 0.08);
			display: flex;
			align-items: center;
			justify-content: center;
			position: fixed;
			bottom: 0;
			/* #ifdef MP */
			height: calc(98rpx + env(safe-area-inset-top));
			padding-bottom: constant(safe-area-inset-bottom);
			/*兼容 IOS<11.2*/
			padding-bottom: env(safe-area-inset-bottom);
			/*兼容 IOS>11.2*/
			/* #endif */
			color: #fff;

			.spec_add_cart_btn {
				width: 345rpx;
				height: 70rpx;
				background: #FF821C;
				border-radius: 35rpx 0 0 35rpx;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
				text-align: center;
				line-height: 70rpx;
			}

			.spec_buy_btn {
				width: 345rpx;
				height: 70rpx;
				background: #F30300;
				border-radius: 0 35rpx 35rpx 0;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
				text-align: center;
				line-height: 70rpx;
			}

			.spec_not_stock {
				background: #ADADAD;
				border-radius: 35rpx;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
				text-align: center;
				line-height: 70rpx;
			}

			.spec_seckill_btn {
				background: linear-gradient(45deg, #fc2d2d 0%, #fd572b 100%);
				border-radius: 35rpx;
				font-size: 30rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
				text-align: center;
				line-height: 70rpx;
			}

			.spec_btn_only {
				width: 690rpx;
				height: 70rpx;
				border-radius: 35rpx;
				text-align: center;
				line-height: 70rpx;
			}

			.specifications_btn2 {
				width: 690rpx;
				height: 70rpx;
				background: linear-gradient(45deg, #FF5C00 0%, #FCE000 0%, #FE8300 0%, #FB9721 100%);
				border-radius: 35rpx;
				display: flex;
				align-items: center;
				justify-content: center;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
				line-height: 32rpx;
			}

			.specifications_bottom_btn3 {
				width: 690rpx;
				height: 70rpx;
				background: linear-gradient(45deg, #FF5D00 0%, #FCE000 0%, #FE8400 0%, #FB9721 100%);
				border-radius: 35rpx;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
				line-height: 30rpx;
				display: flex;
				align-items: center;
				justify-content: center;
			}

			.specifications_bottom_btn4 {
				width: 690rpx;
				height: 70rpx;
				background: linear-gradient(45deg, #FB2D2D 0%, #FC572A 100%);
				border-radius: 35rpx;
				font-size: 28rpx;
				font-family: PingFang SC;
				font-weight: 500;
				color: #FFFFFF;
				line-height: 30rpx;
				display: flex;
				align-items: center;
				justify-content: center;
			}

			.specification_add {
				width: 347rpx;
				height: 70rpx;
				background: linear-gradient(45deg, #FF7918 0%, #FEA00D 100%);
				border-radius: 34rpx 0 0 34rpx;
				display: flex;
				align-items: center;
				justify-content: center;
				color: #fff;
				font-size: 28rpx;
			}

			.specification_add text:nth-of-type(1),
			.specification_buy text:nth-of-type(1) {
				margin-right: 20rpx;
			}

			.spec_deposit_btn {
				color: #fff;
				background: linear-gradient(45deg, #FF7A18 0%, #FEA10E 100%);
			}

			.specification_buy {
				width: 343rpx;
				height: 70rpx;
				background: linear-gradient(45deg, #FB2D2D 0%, #FC572A 100%);
				border-radius: 0 34rpx 34rpx 0;
				display: flex;
				align-items: center;
				justify-content: center;
				color: #fff;
				font-size: 28rpx;
			}
		}
	}


	/* //sdasdasd */
	.right_down {
		width: 36rpx;
		height: 36rpx;
	}

	.play_btn {
		width: 90rpx;
		height: 90rpx;
		position: absolute;
		left: 50%; //起始是在body中，横向距左50%的位置
		top: 50%; //起始是在body中，纵向距上50%的位置，这个点相当于body的中心点，div的左上角的定位
		transform: translate(-50%, -50%); //水平、垂直都居中,也可以写成下面的方式
	}

	.uni-transition {
		width: 750rpx;
		margin: 0 auto;
	}

	.address_list {
		width: 750rpx;
		height: 680rpx;
		margin: 0 auto;
		z-index: 150;
		background-color: #fff;
	}

	.address_list_con {
		border-radius: 5px 5px 0;
	}

	.other_address {
		width: 100%;
		display: flex;
		align-items: center;
		justify-content: center;
		height: 130rpx;
		background: #fff;

		.other_btn {
			width: 668rpx;
			height: 80rpx;
			background: linear-gradient(-90deg, #FC1D1C 0%, #FF7A18 100%);
			border-radius: 44rpx;
			display: flex;
			align-items: center;
			justify-content: center;
			font-size: 34rpx;
			font-family: PingFang SC;
			font-weight: 500;
			color: #FEFEFE;
		}
	}

	.address_top {
		padding: 20rpx 30rpx;
		border-radius: 5px 5px 0 0;
		font-size: 32rpx;
		font-family: PingFang SC;
		font-weight: bold;
		color: #333333;
		display: flex;
		justify-content: space-between;
		align-items: center;
		background: #fff;
		border-bottom: 0.5px solid #f2f2f2;

		image {
			width: 50rpx;
			height: 50rpx;
		}
	}

	.list {
		display: flex;
		/* flex-direction: column; */
		align-items: center;
		justify-content: flex-start;
		padding: 24rpx 30rpx;
		background: #fff;
		position: relative;

		&.b-b {
			/* &:after {
				position: absolute;
				z-index: 3;
				left: 20rpx;
				right: 0;
				height: 0;
				content: '';
				-webkit-transform: scaleY(0.5);
				transform: scaleY(0.5);
				border-bottom: 1px solid rgba(0, 0, 0, .1);
			} */
		}
	}

	.wrapper {
		flex: 1;
		background: #fff;

		.iconfont {
			color: $main-color;
			font-size: 32rpx;
			margin-right: 30rpx;
		}

		image {
			width: 36rpx;
			height: 38rpx;
			margin-right: 22rpx;
		}
	}

	.wrapper_right {
		.checkedIcon {
			width: 32rpx;
			height: 24rpx;
			margin-left: 30rpx;
		}
	}

	.address-box {
		display: flex;
		align-items: center;

		.address {
			font-size: 28rpx;
			color: #333;
			line-height: 38rpx;
			margin-top: 5rpx;
			word-break: break-all;
			max-width: 570rpx;
		}

		.tag {
			width: 63rpx;
			height: 30rpx;
			margin-left: 20rpx;
			margin-right: 0rpx;
		}
	}

	.address_on {
		color: #FB4444 !important;
	}

	.u-box {
		font-size: 30rpx;
		color: $font-color-light;
		color: $main-font-color;
		font-weight: bold;

		.name {
			margin-right: 70rpx;
		}
	}
	
	.fulldis_pre_con /deep/ #top>div div {
		overflow: unset;
		white-space: normal;
		text-overflow: unset;
	}
</style>
