//封装的关于统计的方法
import request from './request'
import {base64Encode,isWeiXinBrower} from './base.js'
// #ifdef MP-WEIXIN
var amapFile = require('../static/MP-WEIXIN/libs/amap-wx.js');
// #endif
// #ifdef H5
var jweixin = require('../jweixin'); //引入微信浏览器分享的jssdk
// #endif 
/** 
 * 初始化统计
 * @params showDebug Boolean 是否开启统计日志，默认false 不开启
 * @zjf-2021-06-27
 */
export async function initStat(showDebug = false, initStatCommonProperty) {
	uni.setStorage({
		key: 'sldStatShowDebug',
		data: showDebug,
	});
	let uuid = null
	//获取udid
	if(uni.getStorageSync('sldStatCommonProperty').uuid){
		uuid = uni.getStorageSync('sldStatCommonProperty').uuid
	}else{
		uuid = getUUID();
	}
	// #ifdef MP-WEIXIN
	//获取openid
	let code = await uniLogin();
	let openid = await getOpenid(code)
	uuid = openid;
	// #endif

	//获取位置信息
	initStatCommonProperty = {
		...initStatCommonProperty,
		uuid: uuid,
	}
	updateStatCommonProperty(initStatCommonProperty)
}

/** 
 * 获取微信小程序的code
 * @zjf-2021-06-28
 */
export function uniLogin() {
	let code = '';
	return new Promise(func => {
		uni.login({
			provider: 'weixin',
			success: res => {
				func(res.code)
			},
			fail() {
				func(code)
			}
		})
	})
}

/** 
 * 获取微信小程序的openid
 * @params code String uni.login获取到的code
 * @zjf-2021-06-27
 */
export async function getOpenid(code) {
	let openId = '';
	if (!code) {
		return openId;
	}
	let params = {
		url: 'v3/member/front/login/wechat/getOpenId',
		method: 'POST',
		data: {
			code: code,
			source: 2
		}
	}
	await request(params).then(res => {
		if (res.state == 200) {
			openId = res.data;
		}
	})
	return openId;
}

/** 
 * 设置/更新统计的公共属性
 * @params data Object 要更新的属性数据
 * @zjf-2021-06-27
 */
export function updateStatCommonProperty(data) {
	let target = {};
	try {
		const value = uni.getStorageSync('sldStatCommonProperty');
		if (value) {
			target = value;
		}
	} catch (e) {}
	target = {
		...target,
		...data
	}; //更新或者新增统计的公共属性
	uni.setStorageSync('sldStatCommonProperty', target);
}

/** 
 * 同步获取指定key对应的内容
 * @params key 指定的缓存key
 * @zjf-2021-06-27
 */
export function getStatStorage(key) {
	let target = {};
	try {
		const value = uni.getStorageSync(key);
		if (value) {
			target = value;
		}
	} catch (e) {}
	return target;
}

/** 
 * 获取uuid
 * 如：1624819897644-1389918-0ed8161319cedb-22991203
 * Math.random().toString(16).replace('.', '')：0～1的随机数以十六进制显示，并去掉小数点，如：0.f03fb618bf531，并去掉小数点
 * @zjf-2021-06-27
 */
export function getUUID() {
	return "" + Date.now() + '-' + Math.floor(1e7 * Math.random()) + '-' + Math.random().toString(16).replace('.', '') +
		'-' + String(Math.random() * 31242).replace('.', '').slice(0, 8);
}

/** 
 * 获取地理位置信息,各个终端分别获取
 * @zjf-2021-06-27
 */
export async function getLocation() {
	let locationData = {
		cityCode: '', //城市编码
		cityName: '', //城市名称
		location: '', //经纬度，英文逗号分隔
		provinceCode: '', //	省份编码
		provinceName: '', //	省份名称
	};
	// #ifdef H5
	locationData = await getH5Location(locationData);
	// #endif 

	// #ifdef APP-PLUS
	locationData = await getAppLocation(locationData);
	// #endif 

	// #ifdef MP-WEIXIN
	locationData = await getWxXcxLocation(locationData);
	// #endif 

	return locationData;
}

/** 
 * 获取H5的地理位置
 * @zjf-2021-06-28
 */
export function getH5Location(locationData) {
	return new Promise(func => {
		if (!isWeiXinBrower()) {
			//普通h5获取定位
			var script = document.createElement('script');
			script.src = "https://webapi.amap.com/maps?v=1.4.15&key=" + getApp().globalData.h5GdKey +
				"&callback=mapInit";
			document.body.appendChild(script);
			//这里要加window., loadScrpit的callback才会执行
			window.mapInit = function() {
				let mapObj = new AMap.Map('iCenter');
				mapObj.plugin('AMap.Geolocation', function() {
					let geolocation = new AMap.Geolocation({
						enableHighAccuracy: false, //是否使用高精度定位，默认:true
						timeout: 5000, //超过5秒后停止定位，默认：无穷大
					});
					geolocation.getCurrentPosition();
					//返回定位信息
					AMap.event.addListener(geolocation, 'complete', function(res) {
						locationData.location = res.position.lng + ',' + res.position.lat;
						if (res.addressComponent&&res.addressComponent.city == '') {
							locationData.provinceName = res.addressComponent.province
								.substring(0, res.addressComponent.province.length - 1);
							locationData.cityName = res.addressComponent.province;
						}
						func(locationData);
					});
					//返回定位出错信息
					AMap.event.addListener(geolocation, 'error', function(err) {
						console.info('获取地理位置信息出错，出错信息为：', err);
						func(locationData);
					});
				});
			}
		} else {
			//微信h5获取位置信息
			var script = document.createElement('script');
			script.src = "https://webapi.amap.com/maps?v=1.4.15&key=" + getApp().globalData.h5GdKey;
			document.body.appendChild(script);
			let tar_url = getApp().globalData.apiUrl + 'v3/member/front/login/wxjsConf?source=1';
			uni.request({
				url: tar_url,
				method: 'GET',
				data: {
					url: location.href
				},
				success(res) {
					let data = res.data;
					// #ifdef H5
					jweixin.config({
						debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
						appId: data.data.appId, // 必填，公众号的唯一标识
						timestamp: data.data.timestamp, // 必填，生成签名的时间戳
						nonceStr: data.data.nonceStr, // 必填，生成签名的随机串
						signature: data.data.signature, // 必填，签名
						jsApiList: ["getLocation"] // 必填，需要使用的JS接口列表
					});
					jweixin.ready(function() {
						jweixin.getLocation({
							type: 'wgs84', // 默认为wgs84的gps坐标，如果要返回直接给openLocation用的火星坐标，可传入'gcj02'
							success: function(res) {
								locationData.location = res.longitude + ',' + res
									.latitude;
								//根据经纬度获取详细地址信息
								AMap.plugin('AMap.Geocoder', function() {
									var geocoder = new AMap.Geocoder({
										city: '全国'
									})
									var lnglat = [res.longitude, res
										.latitude
									];
									geocoder.getAddress(lnglat, function(
										status, result) {
										if (status === 'complete' &&
											result.info === 'OK') {
											if (result.regeocode
												.addressComponent
												.city == '') {
												locationData
													.provinceName =
													result.regeocode
													.addressComponent
													.province
													.substring(0,
														result
														.regeocode
														.addressComponent
														.province
														.length - 1
														);
												locationData
													.cityName =
													result.regeocode
													.addressComponent
													.province;
											}
											func(locationData);
										} else {
											func(locationData);
										}
									})
								})
							}
						});
					})
					//#endif
				}
			})
		}
	})
}

/** 
 * 获取APP的地理位置
 * @zjf-2021-06-28
 */
export function getAppLocation(locationData) {
	return new Promise(func => {
		uni.getLocation({
			geocode: true,
			success: function(res) {
				locationData.location = res.longitude + ',' + res.latitude;
				locationData.cityName = res.address.city;
				if (res.address.city == res.address.province) {
					locationData.provinceName = res.address.city.substring(0, res.address.city
						.length - 1);
				}
				func(locationData);
			},
			fail: function(err) {
				console.log('获取位置失败', err)
				func(locationData);
			}
		})
	})
}

/** 
 * 获取微信小程序的地理位置
 * @zjf-2021-06-28
 */
export function getWxXcxLocation(locationData) {
	return new Promise(func => {
		var myAmapFun = new amapFile.AMapWX({
			key: getApp().globalData.WxXcxGdKey
		});
		uni.getSetting({
			success: function(res) {
				if (res.authSetting['scope.userLocation']) {
					myAmapFun.getRegeo({
						success: function(data) {
							let temp = data[0].regeocodeData.addressComponent;
							locationData.location = data[0].regeocodeData.aois[0]
								.location;
							if (temp.city.length != undefined && temp.city.length ==
								0) {
								locationData.provinceName = temp.province.substring(0,
									temp.province.length - 1);
								locationData.cityName = temp.province;
							} else {
								locationData.provinceName = temp.province;
								locationData.cityName = temp.city;
							}
							func(locationData)
						}
					})

				} else {
					uni.showModal({
						title: '提示',
						content: '您好,需要开启地理位置信息才能为您推荐更多的好物',
						showCancel: false,
						success(res) {
							if (res.confirm) {
								uni.authorize({
									scope: 'scope.userLocation',
									success() {
										myAmapFun.getRegeo({
											success: function(data) {
												let temp = data[0]
													.regeocodeData
													.addressComponent;
												locationData.location =
													data[0]
													.regeocodeData.aois[
														0].location;
												if (temp.city.length !=
													undefined &&
													temp.city.length ==
													0) {
													locationData
														.provinceName =
														temp
														.province
														.substring(0,
															temp
															.province
															.length - 1
														);
													locationData
														.cityName = temp
														.province;
												} else {
													locationData
														.provinceName =
														temp
														.province;
													locationData
														.cityName = temp
														.city;
												}
												func(locationData);
											}
										})
									},
									fail() {
										func(locationData);
									}

								});
							}
						}

					});
				}
			},
			complete: function(res) {}
		})
	})
}

/** 
 * 获取设备信息，各个设备分别获取
 * @zjf-2021-06-27
 */
export function getSystemInfo() {
	uni.getSystemInfo({
		"success": function(t) {
			console.info('设备信息：', t);
		},
	})
}

/** 
 * 统计事件
 * @params params Object 参数
 * @zjf-2021-06-27
 */
export async function sldStatEvent(data) {
	//将data和公共属性合并得到最终要发送的数据
	let sldStatCommonProperty = getStatStorage('sldStatCommonProperty');
	let targetParams = {
		...sldStatCommonProperty,
		...data
	};
	//没有位置信息的话 要获取位置信息
	if (!targetParams.location) {
		//获取位置信息
		let location = await getLocation();
		targetParams = {
			...targetParams,
			...location
		};
		updateStatCommonProperty(location)
	}
	//日志开启的话需要打印数据
	const sldStatShowDebug = uni.getStorageSync('sldStatShowDebug');
	if (sldStatShowDebug) {
		console.info('统计传输数据: ', targetParams);
	}
	//发送请求
	let params = {
		url: 'v3/statistics/front/member/behavior/save',
		method: 'POST',
		data: {
			u: base64Encode(JSON.stringify(targetParams))
		}
	}
	request(params).then(res => {})
}
