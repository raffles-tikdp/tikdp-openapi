module.exports = {
  apiUrl:'http://8.142.26.129:9003/',
  chatUrl:'ws://8.142.26.129:9004/',
  imgUrl:'https://8.142.26.129:9006/java/bbc/mobile/',//静态资源地址——线上开发
  // imgUrl: '/static/local/',//静态资源地址——本地开发
  h5AppId:'wx9019a5f5fb0a0844',//微商城appid 
  cateId: '', //首页分类更多跳转分类页对应分类参数
  
  uploadMaxSize: 20, //上传最大限制，以M为单位
  curLang: 'zh', //当前语言,zh:中文，若为其他语言，需要对应/static/language下面的文件名
  h5GdKey: '', //高德web-js key
  WxXcxGdKey: '', //高德小程序key
  statShowDebug: false, //是否开启统计的调试
};
/** copyright *** slodon *** version-v3.9 *** date-2022-03-25 ***主版本v3.9**/

 