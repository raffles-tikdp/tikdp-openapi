// #ifdef H5
var jweixin = require('../jweixin'); //引入微信浏览器分享的jssdk
// #endif 

import Router from '../router.js'
import request from '@/utils/request'


/*
 * 判断分页是否还有数据
 */
export function checkPaginationHasMore({
	current,
	pageSize,
	total
}) {
	return current * pageSize < total * 1;
}

// 检查字符串是否全是空格
export function checkSpace(str) {
	return str.trim() == "" ? true : false;
}

/* 
 * 替换指定位置的字符
 * str 
 * startIndex 要替换的字符串的开始位置
 * stopIndex  要替换的字符串的结束位置
 * replacetext  指定位置要替换成的内容
 */
export function replaceConByPosition(str, startIndex, stopIndex, replacetext) {
	let target_str = str.substring(0, startIndex - 1) + replacetext + str.substring(stopIndex + 1);
	return target_str;
}

/*
 * 返回一个数字的整数和小数
 * number 需要处理的数据
 * type: 要获取的数据 int 整数  decimal 小数
 */
export function getPartNumber(number, type) {
	let target = '';
	if (number == undefined) {
		return false;
	}

	number = number.toString();
	if (type == 'int') {
		target = number.split('.')[0];
	} else if (type == 'decimal') {
		target = number.split('.')[1] != undefined ? ('.' + number.split('.')[1]) : '.00';
		if (target.length < 3) {
			target += '0';
		}
	}
	return target;
}

// 手机号的验证
export function checkMobile(mobile, name) {
	let regMobile = /(1[3-9]\d{9}$)/;
	if (!mobile) {
		this.$api.msg(name ? `请输入${name}!` : '请输入手机号!');
		return false;
	} else if (!regMobile.test(mobile)) {
		this.$api.msg(name ? `请输入正确的${name}!` : '请输入正确的手机号!');
		return false;
	} else {
		return true;
	}
}

//座机和移动手机号码的验证
export function checkTel(mobile, name) {
	let regMobile = /(1[3-9]\d{9}$)/;
	let regTel = /(\d{4}-)\d{6,8}/
	if (!mobile) {
		this.$api.msg(name ? `请输入${name}!` : '请输入电话号码!');
		return false;
	} else if (!regMobile.test(mobile) && !regTel.test(mobile)) {
		this.$api.msg(name ? `请输入正确的${name}!` : '请输入正确的电话号码!');
		return false;
	} else {
		return true;
	}
}

// 6～20位，由英文、数字或符号组成的验证
export function checkPwd(pwd) {
	if (pwd.length < 6) {
		this.$api.msg('密码最少6位哦～');
		return false;
	} else if (pwd.length > 20) {
		this.$api.msg('密码最多20位哦～');
		return false;
	} else if (/[\u4E00-\u9FA5]/g.test(pwd)) {
		this.$api.msg('密码不可以有中文哦～');
		return false;
	} else if (!(/^\S*$/.test(pwd))) {
		this.$api.msg('密码中不可以有空格哦～');
		return false;
	} else {
		return true;
	}
}

//设置cookie，判断首页是否弹出开屏
export function setCookie() {
	uni.setStorage({
		key: 'cookie',
		data: 'cookie'
	});
}
//设置cookie，判断店铺首页是否弹出开屏
export function setStoreIsCookie(vid) {
	uni.setStorage({
		key: 'storeIsCookie' + vid,
		data: 'storeIsCookie' + vid
	});
}
//设置cookie，判断积分商城首页是否弹出开屏
export function setPointIsCookie() {
	uni.setStorage({
		key: 'pointIsCookie',
		data: 'pointIsCookie'
	});
}

// 登录成功的页面跳转
export function loginGoPage() {
	const pages = getCurrentPages();
	let fromurl = uni.getStorageSync('fromurl');
	if (fromurl && fromurl.url) {
		uni.removeStorage({
			key: 'fromurl',
			success: function(res) {}
		});

		//#ifdef H5||MP-WEIXIN
		Router.replaceAll({
			path: fromurl.url,
			query: fromurl.query
		})
		return;
		//#endif

		if (fromurl.url.indexOf("pages/user/user") > -1) {
			Router.pushTab(fromurl.url)
		} else {
			if (pages.length > 1) {
				Router.back(1)
			} else {
				Router.replace({
					path: fromurl.url,
					query: fromurl.query
				})
			}
		}
		return
	}
	//#ifdef H5
	// Router.replaceAll('/pages/user/user')
	// return;
	//#endif
	if (pages.length > 1) {
		Router.back(1)
	} else {
		Router.pushTab(`/pages/user/user`)
	}
}

// 数字格式化为以w为单位，保留2为小数
export function formatW(num) {
	return num > 10000 ? (num / 10000).toFixed(1) * 1 + 'w' : num;
}

// 邮箱的验证
export function checkEmail(email, name) {
	let reg = /^([a-zA-Z0-9]+[-_.]?)*[a-zA-Z0-9]+@([a-zA-Z0-9]+[-_.]?)*[a-zA-Z0-9]+\.[a-zA-Z]{2,6}$/;
	if (!email) {
		this.$api.msg(name ? `请输入${name}!` : '请输入邮箱!');
		return false;
	} else if (!reg.test(email)) {
		this.$api.msg(name ? `请输入正确的${name}!` : '请输入正确的邮箱!');
		return false;
	} else {
		return true;
	}
}

export function checkIdentity(value, name) {
	let reg18 = /^[1-9][0-9]{5}(18|19|20)[0-9]{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)[0-9]{3}([0-9]|(X|x))/
	let reg15 = /^[1-9][0-9]{5}[0-9]{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)[0-9]{2}[0-9]/
	if (!value) {
		this.$api.msg(name ? `请输入${name}!` : '请输入身份证号')
		return false
	} else if (reg18.test(value) || reg15.test(value)) {
		return true;
	} else {
		this.$api.msg(name ? `请输入正确的${name}!` : '请输入正确的身份证号')
		return false;
	}
}

// 装修地址跳转
export function diyNavTo(val, HorS) {
	console.log(val, 'sssss')
	if (val.link_type == 'url') {
		//链接地址,只有h5可以跳转外部链接，其他端都不可以
		//ifdef H5
		window.location.href = val.link_value;
		//endif
		// #ifdef APP-PLUS
		plus.runtime.openURL(val.link_value) //这里默认使用外部浏览器打开而不是内部web-view组件打开
		// #endif

		// #ifdef MP
		Router.push({
			path: '/pages/index/skip_to',
			query: {
				url: val.link_value
			}
		})
		// #endif
	} else if (val.link_type == 'keyword') {
		//关键词
		let query = {
			keyword: encodeURIComponent(val.link_value),
			source: 'search'
		}
		if (HorS != 'home') {
			query.storeId = HorS
		}
		Router.push({
			path: '/standard/product/list',
			query
		})
	} else if (val.link_type == 'goods') {
		//商品
		Router.push({
			path: '/standard/product/detail',
			query: {
				productId: val.info.defaultProductId,
				goodsId: val.info.goodsId
			}
		})
	} else if (val.link_type == 'category') {
		//商品分类
		let query = {
			categoryId: val.info.categoryId
		}
		if (val.info.grade == 3) {
			query.pid = val.info.pid
		}
		Router.push({
			path: '/standard/product/list',
			query
		})
	} else if (val.link_type == 'topic') {
		//专题
		Router.push({
			path: '/pages/index/topic',
			query: {
				id: val.info.decoId ? val.info.decoId : val.info.id
			}
		})
	} else if (val.link_type == 'voucher_center') {
		this.$Router.push('/pages/coupon/couponCenter')
	} else if (val.link_type == 'brand_home') {
		this.$Router.push('/pages/public/brand')
	} else if (val.link_type == 'seckill') {
		this.$Router.push({
			path: '/pages/seckill/seckill',
			query: {
				seckillId: val.info.seckillId
			}
		})
	} else if (val.link_type == 'rank') {
		this.$Router.push({
			path: '/standard/rank/aggr'
		})
	} else if (val.link_type == 'spell_group') {
		this.$Router.push('/standard/pinGroup/index/index')
	} else if (val.link_type == 'ladder_group') { //阶梯团
		this.$Router.push('/standard/ladder/index/index')
	} else if (val.link_type == 'presale') { //预售入口页
		this.$Router.push('/standard/presale/index/list')
	} else if (val.link_type == 'point') { //积分商城首页
		this.$Router.push('/standard/point/index/index')
	} else if (val.link_type == 'svideo_center') { //短视频列表
		this.$Router.push('/extra/svideo/svideoList')
	} else if (val.link_type == 'live_center') { //直播列表
		this.$Router.push('/extra/live/liveList')
	} else if (val.link_type == 'spreader_center') { //推手中心
		if (!this.hasLogin) {
			uni.showToast({
				title: '请登录～',
				icon: 'none',
				duration: 700
			})
		} else {
			this.$Router.push('/extra/tshou/index/index')
		}

	} else if (val.link_type == 'live') { //直播播放页面
		this.$Router.push({
			path: '/extra/live/livePlay',
			query: {
				live_id: val.link_value
			}
		})
	} else if (val.link_type == 'svideo') { //短视频播放页面
		this.$Router.push({
			path: '/extra/svideo/svideoPlay',
			query: {
				video_id: val.info.videoId,
				label_id: val.info.labelId,
				author_id: val.info.authorId
			}
		})
	} else if (val.link_type == 'draw') {
		if (!this.hasLogin) {
			uni.showToast({
				title: '请登录～',
				icon: 'none',
				duration: 700
			})
		} else {
			this.$Router.push({
				path: '/standard/lottery/detail',
				query: {
					drawId: val.info.drawId
				}
			})
		}
	} else if (val.link_type == 'rank') {
		this.$Router.push('/standard/rank/aggr')
	} else if (val.link_type == 'sign_center') {
		if (!this.hasLogin) {
			uni.showToast({
				title: '请登录～',
				icon: 'none',
				duration: 700
			})
		} else {
			this.$Router.push('/standard/signIn/signIn')
		}
	}
}

// 装修类型判断
export function decoType(info) {
	let deco_obj = {}
	deco_obj.tupianzuhe = []
	// deco_obj.gonggao = []
	info.map(item => {
		if (item.type == 'more_tab') { //tab切换
			deco_obj.more_tab = {
				border_radius: item.border_radius,
				data: item.data,
			}
		} else if (item.type == 'lunbo') { //轮播图
			deco_obj.lunbo = {
				is_show: item.is_show,
				data: item.data
			}
		} else if (item.type == 'gonggao') { //公告
			if (item.show_style == 'one') {
				deco_obj.gonggao1 = {
					show_style: item.show_style,
					text: item.text,
					is_show: item.is_show,
				}
			} else {
				deco_obj.gonggao2 = {
					show_style: item.show_style,
					text: item.text,
					is_show: item.is_show,
				}
			}
		} else if (item.type == 'top_cat_nav') { //顶部轮播图
			deco_obj.top_cat_nav = {
				swiper_bg_style: item.swiper_bg_style,
				data: item.data
			}
		} else if (item.type == 'nav') { //导航
			deco_obj.nav = {
				is_show: item.is_show,
				data: item.data,
				icon_set: item.icon_set
			}
		} else if (item.type == 'kefu') { //客服
			deco_obj.kefu = {
				is_show: item.is_show,
				tel: item.tel,
				text: item.text
			}
		} else if (item.type == 'fuwenben') { //富文本
			deco_obj.fuwenben = {
				is_show: item.is_show,
				text: item.text
			}
		} else if (item.type == 'tupianzuhe') { //图片组合
			deco_obj.tupianzuhe.push({
				is_show: item.is_show,
				sele_style: item.sele_style,
				width: item.width,
				height: item.height,
				data: item.data,
			})
		} else if (item.type == 'dapei') { //搭配
			deco_obj.dapei = {
				is_show: item.is_show,
				dapei_desc: item.dapei_desc,
				dapei_img: item.dapei_img,
				data: item.data,
				width: item.width,
				height: item.height
			}
		} else if (item.type == 'fzx') { //辅助线
			deco_obj.fzx = {
				color: item.color,
				is_show: item.is_show,
				lrmargin: item.lrmargin,
				tbmargin: item.tbmargin,
				type: item.val
			}
		} else if (item.type == 'tuijianshangpin') { //推荐商品
			deco_obj.recommond_goods = {
				border_style: item.border_style,
				data: item.data,
				goods_margin: item.goods_margin,
				is_show: item.is_show,
				page_margin: item.page_margin,
				show_style: item.small,
				text_align: item.text_align,
				text_style: item.normal,
				isshow_sales: item.isshow_sales
			}
		} else if (item.type == 'fzkb') { //辅助空白
			deco_obj.fzkb = {
				color: item.color,
				is_show: item.is_show,
				text: item.text,
			}
		}
	})
	return deco_obj
}

/** 
 * 微信浏览器里面的分享功能
 * type 分享类型  1 为微信好友分享 2为微信朋友圈分享
 * shareData  分享数据数组 里面的参数分别如下：
 * 		title: '', // 分享标题
 * 		desc: '', // 分享描述
 * 		link: '', // 分享链接
 * 		imgUrl: '', // 分享图片
 * 		type: '', // 分享类型,music、video或link，不填默认为link
 * 		dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
 * isTs 是否推手模块，默认false
 * @zjf-2020-11-06
 */
export function weiXinBrowerShare(type, shareData) {
	let tar_url = getApp().globalData.apiUrl + 'v3/member/front/login/wxjsConf?source=1';

	uni.request({
		url: tar_url,
		method: 'GET',
		data: {
			url: location.href
		},
		success(res) {
			let data = res.data;
			// #ifdef H5
			jweixin.config({
				debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
				appId: data.data.appId, // 必填，公众号的唯一标识
				timestamp: data.data.timestamp, // 必填，生成签名的时间戳
				nonceStr: data.data.nonceStr, // 必填，生成签名的随机串
				signature: data.data.signature, // 必填，签名
				jsApiList: ["updateAppMessageShareData", "updateTimelineShareData"] // 必填，需要使用的JS接口列表
			});
			jweixin.ready(function() {
				if (type == 1) {
					//获取“分享给朋友”按钮点击状态及自定义分享内容接口
					jweixin.updateAppMessageShareData({
						title: shareData.title != undefined ? shareData.title : '', // 分享标题
						desc: shareData.desc != undefined ? shareData.desc : '', // 分享描述
						link: shareData.link != undefined ? shareData.link :
						'', // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
						imgUrl: shareData.imgUrl, // 分享图标
						type: '', // 分享类型,music、video或link，不填默认为link
						dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
						success: function() {

						}
					})
				} else if (type == 2) {
					//获取“分享到朋友圈”按钮点击状态及自定义分享内容接口
					jweixin.updateTimelineShareData({
						title: shareData.title != undefined ? shareData.title : '', // 分享标题
						link: shareData.link != undefined ? shareData.link :
						'', // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
						imgUrl: shareData.imgUrl, // 分享图标
						success: function() {
							// 设置成功
						}
					})

				}
			})
			//#endif
		}
	})
}

export function WXBrowserShareStart() {

	let tar_url = getApp().globalData.apiUrl + 'v3/member/front/login/wxjsConf?source=1';
	let hrefUrl = location.href
	console.log(hrefUrl, 'ssss')
	uni.request({
		url: tar_url,
		method: 'GET',
		data: {
			url: hrefUrl
		},
		success(res) {
			let data = res.data;
			// #ifdef H5
			jweixin.config({
				debug:false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
				appId: data.data.appId, // 必填，公众号的唯一标识
				timestamp: data.data.timestamp, // 必填，生成签名的时间戳
				nonceStr: data.data.nonceStr, // 必填，生成签名的随机串
				signature: data.data.signature, // 必填，签名
				jsApiList: ["updateAppMessageShareData", "updateTimelineShareData"] // 必填，需要使用的JS接口列表
			});

			//#endif
		}
	})
}


export function WXBrowserShareThen(type, shareData) {
	jweixin.ready(function() {
		if (type == 1) {
			//获取“分享给朋友”按钮点击状态及自定义分享内容接口
			jweixin.updateAppMessageShareData({
				title: shareData.title != undefined ? shareData.title : '', // 分享标题
				desc: shareData.desc != undefined ? shareData.desc : '', // 分享描述
				link: shareData.link != undefined ? shareData.link :
				'', // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
				imgUrl: shareData.imgUrl ? shareData.imgUrl : '123.png', // 分享图标
				type: '', // 分享类型,music、video或link，不填默认为link
				dataUrl: '', // 如果type是music或video，则要提供数据链接，默认为空
				success: function() {

				}
			})
		} else if (type == 2) {
			//获取“分享到朋友圈”按钮点击状态及自定义分享内容接口
			jweixin.updateTimelineShareData({
				title: shareData.title != undefined ? shareData.title : '', // 分享标题
				link: shareData.link != undefined ? shareData.link :
				'', // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
				imgUrl: shareData.imgUrl ? shareData.imgUrl : '123.png', // 分享图标
				success: function() {
					// 设置成功
				}
			})

		}
	})
}




/** 
 * 获取浏览器地址参数
 * variable 为参数名，存在的话返回具体值，否则返回false
 * 
 * @zjf-2020-11-17
 */
export function getQueryVariable(variable) {
	let query = window.location.search.substring(1);
	let vars = query.split("&");
	for (let i = 0; i < vars.length; i++) {
		let pair = vars[i].split("=");
		if (pair[0] == variable) {
			return pair[1];
		}
	}
	return false;
}

/** 
 * 微信浏览器里面的支付
 * payData  支付数据数组 里面的参数分别如下：
 * 		timestamp: '',  // 支付签名时间戳，注意微信jssdk中的所有使用timestamp字段均为小写。但最新版的支付后台生成签名使用的timeStamp字段名需大写其中的S字符
 * 		nonceStr: '', // 支付签名随机串，不长于 32 位
 * 		package: '', // 统一支付接口返回的prepay_id参数值，提交格式如：prepay_id=***）
 * 		signType: '', // 签名方式，默认为'SHA1'，使用新版支付需传入'MD5'
 * 		paySign: '', // 支付签名
 * 		appId: '', 
 * 		success: function (res) { // 支付成功后的回调函数 }
 *		fail: function (res) { // 失败时执行的回调函数 }
 * 		complete: function (res) { // 接口调用完成时执行的回调函数，无论成功或失败都会执行 }
 * 		cancel: function (res) { // 用户点击取消时的回调函数，仅部分有用户取消操作的api才会用到 }
 * 		trigger: function (res) { // 监听Menu中的按钮点击时触发的方法，该方法仅支持Menu中的相关接口 }
 * 
 * @zjf-2020-11-06
 */
export function weiXinBrowerPay(payData) {
	let tar_url = getApp().globalData.apiUrl + 'v3/member/front/login/wxjsConf?source=1';
	uni.request({
		url: tar_url,
		method: 'GET',
		data: {
			url: location.href
		},
		success(res) {
			let data = res.data;
			// #ifdef H5
			jweixin.config({
				debug: false, // 开启调试模式,调用的所有api的返回值会在客户端alert出来，若要查看传入的参数，可以在pc端打开，参数信息会通过log打出，仅在pc端时才会打印。
				appId: data.data.appId, // 必填，公众号的唯一标识
				timestamp: data.data.timestamp, // 必填，生成签名的时间戳
				nonceStr: data.data.nonceStr, // 必填，生成签名的随机串
				signature: data.data.signature, // 必填，签名
				jsApiList: ['chooseWXPay', 'scanQRCode'] // 必填，需要使用的JS接口列表
			});
			jweixin.ready(function() {
				jweixin.chooseWXPay(payData);
			})
			//#endif
		}
	})
}

/** 
 * 通用提示
 * con  String  提示的内容,无特殊要求的话可不传
 * 
 * @zjf-2020-11-18
 */
export function sldCommonTip(con = '该功能在升级中～') {
	uni.showToast({
		title: con,
		icon: 'none',
	});
}
export function formatPercent(val) {
	return val.substring(0, val.length - 1)
}
/** 
 * 获取用户登录模块的终端类型
 * 
 * @zjf-2020-11-23
 */
export function getLoginClient() {
	let client = 1; //终端类型， 1、H5(微信内部浏览器) 2、H5(微信小程序)；3、app
	//#ifdef APP-PLUS
	client = 3;
	//#endif
	//#ifdef MP-WEIXIN
	client = 2;
	//#endif
	//#ifdef H5
	client = 1;
	//#endif
	return client;
}

/**
 * 防止用户多此点击触发事件
 * @ljp - 2021-2-7
 * */
export function frequentyleClick(fn) {
	let that = this;
	if (that.onOff) {
		that.onOff = false;
		fn();
		setTimeout(() => {
			that.onOff = true;
		}, 1500)
	} else {
		//如果一直走else，可能是你没有页面的data下面挂载onOff = true; 不然一直会走else
	}
}
/**
 * h5端页面返回处理，刷新后返回到首页
 * @ww - 2021-2-21
 * */
export function back(fn) {
	// #ifdef H5
	const pages = getCurrentPages()

	if (pages.length > 1) {
		// uni.navigateBack(1)
		Router.back(1)
		return;
	} else {
		//重新定向跳转页面
		// uni.reLaunch({
		// 	url: '/pages/index/index'
		// })
		Router.replaceAll('/pages/index/index')
	}
	return;
	// #endif
	// #ifndef H5
	const pages = getCurrentPages()
	if (pages.length > 1) {
		// uni.navigateBack(1)
		Router.back(1)
		return;
	} else {
		// uni.reLaunch({
		// 	url: '/pages/index/index'
		// })
		Router.replaceAll('/pages/index/index')
	}
	// #endif
}

/*
 * 判断是否显示聊天页面的时间,2条消息之间间隔超过3分钟显示
 * 返回Boolean类型
 * preMsgTime 上一条消息的发送时间，curMsgTime该条消息的发送时间
 * @zjf-2021-03-05
 * */
export function isShowTime(preMsgTime, curMsgTime) {
	let res = false;

	// #ifdef APP-PLUS
	if (uni.getSystemInfoSync().platform === 'ios' && preMsgTime != undefined && curMsgTime !=
		undefined) { //ios系统不识别该时间格式，进行专门格式化
		let arr = [preMsgTime, curMsgTime].map(item => item.toString().split(/[- :]/))
		let newDate = arr.map(item => item = new Date(item[0], item[1] - 1, item[2], item[3], item[4], item[5]))
		if (Date.parse(newDate[1]) * 1 - Date.parse(newDate[0]) * 1 > 3 * 60 * 1000) {
			res = true;
		}
	} else if (uni.getSystemInfoSync().platform === 'android' && preMsgTime != undefined && curMsgTime != undefined) {
		if (Date.parse(new Date(curMsgTime.toString().replace(/-/g, '/'))) * 1 - Date.parse(new Date(preMsgTime
				.toString().replace(/-/g, '/'))) * 1 > 3 * 60 * 1000) {
			res = true;
		}
	}
	// #endif

	// #ifndef APP-PLUS
	if (Date.parse(new Date(curMsgTime.toString().replace(/-/g, '/'))) * 1 - Date.parse(new Date(preMsgTime.toString()
			.replace(/-/g, '/'))) * 1 > 3 * 60 * 1000) {
		res = true;
	}
	// #endif

	return res;
}

/*
 * 格式化聊天时间
 * 返回格式化后的数据，字符串类型
 * time 时间戳 13位
 * @zjf-2021-03-05
 * */
export function formatChatTime(time) {
	// #ifdef APP-PLUS
	if (uni.getSystemInfoSync().platform === 'ios') { //ios系统不识别该时间格式，进行专门格式化
		let arr = time.split(/[- :]/)
		let newDate = new Date(
			arr[0],
			arr[1] - 1,
			arr[2],
			arr[3],
			arr[4],
			arr[5]
		)
		return format(newDate, 'yyyy年MM月dd日 hh:mm')
	} else {
		return format(new Date(time), 'yyyy年MM月dd日 hh:mm');
	}
	// #endif

	// #ifndef APP-PLUS
	if(time.toString().indexOf('-') == -1 && typeof(time)=='number'){
		 return formatNorm(time);
	}else{
		return format(new Date(time.toString().replace(/-/g, '/')), 'yyyy年MM月dd日 hh:mm');
	}
	// #endif
}

export function formAdd0(m){
	return m<10 ? '0'+m : m;
}
export function formatNorm(timeStep){ //时间戳转标准时间
	let time = new Date(parseInt(timeStep));
	let y = time.getFullYear();
	let m = time.getMonth()+1;
	let d = time.getDate();
	let h = time.getHours();
	let mm = time.getMinutes();
	let s = time.getSeconds();
	let newTime = y+'-'+formAdd0(m)+'-'+formAdd0(d)+' '+formAdd0(h)+':'+formAdd0(mm)+':'+formAdd0(s);
	return format(new Date(newTime.toString().replace(/-/g, '/')), 'yyyy年MM月dd日 hh:mm');
}

export function format(date, fmt) {
	let o = {
		"y+": date.getFullYear(), //年
		"M+": date.getMonth() + 1, //月份
		"d+": date.getDate(), //日
		"h+": date.getHours(), //小时
		"m+": date.getMinutes(), //分
		"s+": date.getSeconds(), //秒
		"q+": Math.floor((date.getMonth() + 3) / 3), //季度
		"S": date.getMilliseconds() //毫秒
	};
	if (/(y+)/.test(fmt)) {
		fmt = fmt.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
	}
	for (let k in o) {
		if (new RegExp("(" + k + ")").test(fmt)) {
			fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
		}
	}
	return fmt;
}

/** 
 * 基于uniapp.uploadFile的多文件上传，支持 跨端
 * fileArray:Array
 * params:Object
 * success:Function
 * @lijm-2021-06-15
 */
export function multifileUpload({
	fileArray,
	params,
	success,
	fail
}) {
	if (!fileArray || !params) {
		return '';
	}
	let promiseArray = [];
	fileArray.forEach((item, index) => {
		params.filePath = item;
		// params.formData.file = item;
		//将每个请求封装成promise
		promiseArray[index] = uni.uploadFile(params)
	})
	if (success && typeof success === 'function') {
		//当所有请求完成后，调用success回调，返回请求后的reponse
		Promise.all(promiseArray).then((res) => {
			let data = []
			res.forEach((item, index) => {
				// #ifndef MP-BAIDU||MP-ALIPAY
				if (JSON.parse(item[1].data).state === 200) {
					data.push(JSON.parse(item[1].data))
				}
				// #endif
				// #ifdef MP-BAIDU||MP-ALIPAY
				if (item[1].data.state === 200) {
					data.push(item[1].data)
				}
				// #endif

			})
			if (data.length) {
				success(data);
			}
			//如果有失败回调，则返回失败信息
			if (fail && typeof fail === 'function') {
				let errData = '';
				let tempStatus = res.some((item) => {
					// #ifdef MP-BAIDU||MP-ALIPAY
					if (item[1].data.state != 200) {
						errData = item[1].data
						return true;
					}
					// #endif

					// #ifndef MP-BAIDU||MP-ALIPAY
					if (JSON.parse(item[1].data).state != 200) {
						errData = JSON.parse(item[1].data);
						return true;
					}
					// #endif

					return false;
				})
				fail(errData || {
					status: 200,
					msg: 'no errors'
				})
			}
		})
	}

}


export function checkUpdate() {
	// #ifdef APP-PLUS
	let cur_edition = plus.runtime;
	// #endif

	let cur_platform = uni.getSystemInfoSync().platform;
	let paramArr = ['app_android_hot_edition',
		'app_android_hot_link',
		'app_android_hot_tip',
		'app_android_package_edition',
		'app_android_package_link',
		'app_ios_hot_edition',
		'app_ios_hot_link',
		'app_ios_hot_tip',
		'app_ios_package_edition',
		'app_ios_package_link'
	]

	request({
		url: 'v3/system/front/setting/getSettings',
		data: {
			names: paramArr.join(',')
		}
	}).then(res => {
		if (res.state == 200) {
			let updateObj = {}
			paramArr.forEach((item, index) => {
				updateObj[item] = res.data[index]
			})

			if (updateObj[`app_${cur_platform}_package_edition`] && updateObj[
					`app_${cur_platform}_package_link`]) {
				if (cur_edition.version * 1 < updateObj[`app_${cur_platform}_package_edition`] * 1) {
					//需要整包升级
					console.log('package', updateObj[`app_${cur_platform}_package_edition`])
					uni.showModal({ //提醒用户更新   
						title: "更新提示",
						content: updateObj[`app_${cur_platform}_hot_tip`],
						success: (result) => {
							if (result.confirm) {
								plus.runtime.openURL(updateObj[`app_${cur_platform}_package_link`]);
							}
						}
					})
					return;
				}
			}



			if (updateObj[`app_${cur_platform}_package_edition`] && updateObj[
				`app_${cur_platform}_hot_edition`] && updateObj[`app_${cur_platform}_hot_link`]) {
				if (cur_edition.version * 1 == updateObj[`app_${cur_platform}_package_edition`] * 1 &&
					cur_edition.versionCode * 1 < updateObj[`app_${cur_platform}_hot_edition`] * 1) {
					let curVersinCode = uni.getStorageSync('curVersionCode');
					if (curVersinCode && curVersinCode * 1 >= updateObj[`app_${cur_platform}_hot_edition`] *
						1) {
						return false;
					}
					console.log('hot')
					//热更新
					uni.showModal({ //提醒用户更新
						title: "更新提示",
						content: updateObj[`app_${cur_platform}_hot_tip`],
						success: (result) => {
							if (result.confirm) {
								uni.downloadFile({
									url: updateObj[`app_${cur_platform}_hot_link`],
									success: (downloadResult) => {
										if (downloadResult.statusCode === 200) {
											plus.runtime.install(downloadResult
												.tempFilePath, {
													force: true
												},
												function() {
													uni.setStorageSync(
														'curVersionCode',
														updateObj[
															`app_${cur_platform}_hot_edition`
															]);
													console.log(
														'install success...');
													plus.runtime.restart();
												},
												function(e) {
													console.error('install fail...',
														e);
												});
										}
									}
								});
							}
						}
					})
					return;
				}
			}

		}

	})

}

/*
* 富文本内容反转义（接口返回的富文本内容经过了转义，导致内容无法展示，所以需要反转义）
* @param {String} str 富文本内容
* @zjf-2022-01-07
* */
export function quillEscapeToHtml(str) {
    if (str != undefined) {
        const arrEntities = { 'lt': '<', 'gt': '>', 'nbsp': ' ', 'amp': '&', 'quot': '"' }
        return str.replace(/&(lt|gt|nbsp|amp|quot);/ig, function (all, t) {
            return arrEntities[t]
        }).replace(/\<img/g,"<img class='rich_text_image'")
    } else {
        return '';
    }
}
