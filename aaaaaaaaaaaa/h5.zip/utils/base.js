
import { lang_en } from "../static/language/en.js";

export function weBtoa(string){
	var b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
	b64re = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/;
	string = String(string);
	var bitmap, a, b, c,
		result = "",
		i = 0,
		rest = string.length % 3; // To determine the final padding
	
	for (; i < string.length;) {
		if ((a = string.charCodeAt(i++)) > 255 ||
			(b = string.charCodeAt(i++)) > 255 ||
			(c = string.charCodeAt(i++)) > 255)
			throw new TypeError("Failed to execute 'btoa' on 'Window': The string to be encoded contains characters outside of the Latin1 range.");
	
		bitmap = (a << 16) | (b << 8) | c;
		result += b64.charAt(bitmap >> 18 & 63) + b64.charAt(bitmap >> 12 & 63) +
			b64.charAt(bitmap >> 6 & 63) + b64.charAt(bitmap & 63);
	}
	
	// If there's need of padding, replace the last 'A's with equal signs
	return rest ? result.slice(0, rest - 3) + "===".substring(rest) : result;
}
	
export function weAtob(string){
	// atob can work with strings with whitespaces, even inside the encoded part,
	// but only \t, \n, \f, \r and ' ', which can be stripped.
	var b64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
	b64re = /^(?:[A-Za-z\d+\/]{4})*?(?:[A-Za-z\d+\/]{2}(?:==)?|[A-Za-z\d+\/]{3}=?)?$/;
	string = String(string).replace(/[\t\n\f\r ]+/g, "");
	if (!b64re.test(string))
		throw new TypeError("Failed to execute 'atob' on 'Window': The string to be decoded is not correctly encoded.");
	
	// Adding the padding if missing, for semplicity
	string += "==".slice(2 - (string.length & 3));
	var bitmap, result = "",
		r1, r2, i = 0;
	for (; i < string.length;) {
		bitmap = b64.indexOf(string.charAt(i++)) << 18 | b64.indexOf(string.charAt(i++)) << 12 |
			(r1 = b64.indexOf(string.charAt(i++))) << 6 | (r2 = b64.indexOf(string.charAt(i++)));
	
		result += r1 === 64 ? String.fromCharCode(bitmap >> 16 & 255) :
			r2 === 64 ? String.fromCharCode(bitmap >> 16 & 255, bitmap >> 8 & 255) :
			String.fromCharCode(bitmap >> 16 & 255, bitmap >> 8 & 255, bitmap & 255);
	}
	return result;
}


/*
 * 获取当前语言下的数据 —— Object类型
 * 返回对象  语言数据对象
 * @zjf-2020-12-28
 * */
export function getCurLanguage(key) {
	let curLang = getApp().globalData.curLang;
	if (curLang == 'zh') {
		return key;
	} else {
		const language = {
			'en': lang_en,
		}
		let curData = language[curLang][key];
		return curData != undefined && curData ? curData : '语言包中缺少该数据'; //此处不要翻译
	}
}

/** 
 * APP微信分享功能
 * type 分享类型  0 图文 2 图片
 * scene 场景  WXSceneSession 分享朋友   WXSenceTimeline 分享朋友圈
 * shareData  分享数据数组 里面的参数分别如下：
 * 	  1、图文数据
 * 		href: '', // 分享链接
 * 		title: '', // 分享标题
 * 		summary: '', // 分享描述
 * 		imageUrl: '', // 分享图片
 * 	  2、图片数据
 * 		imageUrl: '', // 分享图片
 * 
 * @zjf-2020-11-12
 */
export function weiXinAppShare(type, scene, shareData) {
	console.log(type, scene, shareData,'type, scene, shareData')
	if (type == 0) {
		//分享图文
		uni.share({
			provider: "weixin",
			scene: scene,
			type: type, //0为图文
			href: shareData.href,
			title: shareData.title,
			summary: shareData.summary,
			imageUrl: shareData.imageUrl, //图片,图片过大的话不展示，建议小于20kb
			success: function(res) {},
			fail: function(err) {},
			complete: (com) => {
				console.log(com)
			}
		});
	} else if (type == 2) {
		//分享图片
		uni.share({
			provider: "weixin",
			scene: scene,
			type: type, //2为图片
			imageUrl: shareData.imageUrl, //图片,图片过大的话不展示，建议小于20kb
			success: function(res) {},
			fail: function(err) {},
			complete: (com) => {
				console.log(com)
			}
		});
	}
}

/** 
 * base64加密
 * @params data String 要加密的字符串
 * @zjf-2021-06-28
 */
export function base64Encode(data) {
	let b64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
	let o1,
		o2,
		o3,
		h1,
		h2,
		h3,
		h4,
		bits,
		i = 0,
		ac = 0,
		enc = '',
		tmp_arr = [];
	if (!data) {
		return data;
	}
	data = utf8Encode(data);
	do {
		o1 = data.charCodeAt(i++);
		o2 = data.charCodeAt(i++);
		o3 = data.charCodeAt(i++);

		bits = o1 << 16 | o2 << 8 | o3;

		h1 = bits >> 18 & 0x3f;
		h2 = bits >> 12 & 0x3f;
		h3 = bits >> 6 & 0x3f;
		h4 = bits & 0x3f;
		tmp_arr[ac++] = b64.charAt(h1) + b64.charAt(h2) + b64.charAt(h3) + b64.charAt(h4);
	} while (i < data.length);

	enc = tmp_arr.join('');

	switch (data.length % 3) {
		case 1:
			enc = enc.slice(0, -2) + '==';
			break;
		case 2:
			enc = enc.slice(0, -1) + '=';
			break;
	}

	return enc;
}

export function utf8Encode(string) {
	string = (string + '').replace(/\r\n/g, '\n').replace(/\r/g, '\n');

	let utftext = '',
		start,
		end;
	let stringl = 0,
		n;

	start = end = 0;
	stringl = string.length;

	for (n = 0; n < stringl; n++) {
		let c1 = string.charCodeAt(n);
		let enc = null;

		if (c1 < 128) {
			end++;
		} else if ((c1 > 127) && (c1 < 2048)) {
			enc = String.fromCharCode((c1 >> 6) | 192, (c1 & 63) | 128);
		} else {
			enc = String.fromCharCode((c1 >> 12) | 224, ((c1 >> 6) & 63) | 128, (c1 & 63) | 128);
		}
		if (enc !== null) {
			if (end > start) {
				utftext += string.substring(start, end);
			}
			utftext += enc;
			start = end = n + 1;
		}
	}

	if (end > start) {
		utftext += string.substring(start, string.length);
	}

	return utftext;
}


export function arrCom(source, target, key) {

	let res = []

	if (source.length == 0 && target.length > 0) {
		return target
	} else if (target.length == 0 && source.length > 0) {
		return []
	} else {
		target.forEach(item => {
			let idx = source.findIndex(d => d[key] == item[key])
			if (idx < 0) res.push(item)
		})

		return res
	}




	target.forEach
}

/** 
 * 判断是否是微信浏览器
 * 
 * @zjf-2020-11-06
 */
export function isWeiXinBrower() {
	//#ifdef H5
	let ua = window.navigator.userAgent.toLowerCase();
	if (ua.match(/MicroMessenger/i) == 'micromessenger') {
		return true; // 微信中打开
	} else {
		return false; // 普通浏览器中打开
	}
	//#endif
	//#ifndef H5
	return false;
	//#endif
}