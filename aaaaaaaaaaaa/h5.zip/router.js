import Vue from 'vue'
import Router from 'uni-simple-router'
import {sldStatEvent,updateStatCommonProperty} from "./utils/stat.js";


Vue.use(Router)
//初始化
const router = new Router({
	encodeURI:false,  //默认为true
    routes:ROUTES //路由表
});

//全局路由前置守卫
router.beforeEach((to, from, next) => {
	next();
})
// 全局路由后置守卫
router.afterEach((to, from) => {
	let url = getApp().globalData.apiUrl.substring(0,getApp().globalData.apiUrl.length-1);
	//商品详情页、店铺的页面需要单独统计，但是需要把pageUrl和referrerPageUrl先存进去
	let specialPages = [
		'/standard/product/detail',//商品详情页
		'/standard/store/shopHomePage',//店铺首页
		'/standard/store/storeIntroduction',//店铺信息页
		'/standard/store/productSearch',//店铺商品列表页
		'/extra/tshou/goods/detail',//推手商品详情页
	];
	let statPvFlag = true;
	for(let i in specialPages){
		if(specialPages[i].indexOf(to.path)>-1){
			statPvFlag = false;
			break;
		}
	}
	if(!statPvFlag){
		//不需要pv类型的统计
		updateStatCommonProperty({pageUrl:url+to.path,referrerPageUrl:url+from.path});
	}else{
		setTimeout(() => {
			//#ifdef MP-WEIXIN
			if(to.path!=='/pages/index/index'){
				sldStatEvent({behaviorType:'pv',pageUrl:url+to.path,referrerPageUrl:url+from.path});
			}
			//#endif
			//#ifndef MP-WEIXIN
			sldStatEvent({behaviorType:'pv',pageUrl:url+to.path,referrerPageUrl:url+from.path});
			//#endif
		}, 3000)
	}
})
export default router;