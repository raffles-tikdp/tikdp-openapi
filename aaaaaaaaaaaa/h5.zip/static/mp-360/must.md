#### ##### 1、android包名：com.slodonapp.javabbc
#### ##### 2、ios bundleid：com.slodon.javabbc





###### build文件夹下存放正式版ios证书（包含profile文件和私钥证书）
###### dev文件夹下存放开发版ios证书（包含profile文件和私钥证书）