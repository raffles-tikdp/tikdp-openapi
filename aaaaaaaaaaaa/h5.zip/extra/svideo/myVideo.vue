<!-- 我的视频 -->
<template>
	<view class="author_info" :style="'background-image:url('+authorInfo.backgroundImage+');'">
		<!-- <image @tap="goBack" class="go_back" :src="imgUrl+'white_arrow_l.png'"></image> -->
		<view class="info">
			<!-- #ifdef MP -->
			<image class="author_avator" :src="authorInfo.memberAvatar" mode="aspectFill"
				v-if="authorInfo && authorInfo.memberAvatar"></image>
			<!-- #endif -->
			<!-- #ifdef H5 -->
			<view class="author_avator" :style="'background-image:url('+authorInfo.memberAvatar+');' + bgStyle">
			</view>
			<!-- #endif -->
			<!-- #ifdef APP-PLUS -->
			<view class="author_avator" :style="'background-image:url('+authorInfo.memberAvatar+');' + bgStyle">
			</view>
			<!-- #endif -->
			<view class="right_info">
				<view class="member_info">
					<text class="author_name">{{authorInfo.memberNickname ? authorInfo.memberNickname :
						authorInfo.memberName}}
					</text>

					<view v-if="JSON.stringify(authorInfo)!='{}'&&authorInfo.isSelf" @tap="editMemInfo"
						class="edit_mem_info">
						<text>{{$L('编辑资料')}}</text>
						<image :src="imgUrl+'svideo/edit_mem_info.png'"></image>
					</view>

					<view v-if="JSON.stringify(authorInfo)!='{}'&&!authorInfo.isSelf" class="fav_info"
						:style="'background:' + (authorInfo.isFollow ? '#999999' : '#FC1C1C')" @tap="collect">
						<image v-if="!authorInfo.isFollow" :src="imgUrl+'svideo/fav_a.png'"></image>
						<text>{{!authorInfo.isFollow?'关注':'已关注'}}</text>
					</view>

					<block v-if="setting.video_switch == 1&&authorInfo.isSelf">
						<view class="msg_wrap" @tap="goComments">
							<image :src="imgUrl+'svideo/msg.png'"></image>
							<text v-if="authorInfo.msgNum > 0"></text>
						</view>
					</block>

					<!-- 	<block v-if="authorInfo.isSelf">
						<navigator :url="'/pages/shopHomePage/shopHomePage?vid=' + authorInfo.vid">
							<view class="go_vendor">
								<text>进店</text>
							</view>
						</navigator>
					</block> -->
				</view>
				<block v-if="authorInfo.isSelf">
					<!-- 发布权限状态:0-默认，1-待审核，2-审核通过(正常发布)，3-审核拒绝，4-禁止发布 -->
					<text v-if="authorInfo.permissionState == 0" @tap="applicationTip('是否立即申请发布权限')"
						class="check_tip">{{authorInfo.permissionStateValue}}></text>
					<text v-if="authorInfo.permissionState == 1" @tap="applicationShowTip('审核中，请耐心等待')"
						class="check_tip">{{authorInfo.permissionStateValue}}></text>
					<text v-if="authorInfo.permissionState == 3"
						@tap="applicationTip(authorInfo.permissionStateValue + '：' + authorInfo.remark)"
						class="check_tip">{{authorInfo.permissionStateValue}}></text>
					<text
						v-if="(authorInfo.permissionState == 4) || (authorInfo.roleType == 2 && authorInfo.liveState == 0)"
						@tap="applicationShowTip(authorInfo.permissionStateValue + '：' + authorInfo.remark ? authorInfo.remark :  authorInfo.forbidReason)"
						class="check_tip">{{authorInfo.permissionStateValue}}</text>
					<!-- 禁止直播 -->
					<!-- <text v-if="authorInfo.roleType == 2 && authorInfo.liveState == 0" @tap="applicationShowTip('禁止发布' + '：' + authorInfo.remark)" class="check_tip">{{authorInfo.permissionStateValue}}</text> -->
				</block>
			</view>

		</view>
		<view class="author_desc" @tap="editMemInfo">{{ authorInfo.introduction ? authorInfo.introduction :
			(!authorInfo.isSelf ? '这个人很懒，什么都没有写' : '请设置个人简介~') }}</view>
		<view class="stat_num">
			<view data-index="follow"
				:data-title="authorInfo.memberNickname ? authorInfo.memberNickname : authorInfo.memberName">
				<text class="num">{{authorInfo&&authorInfo.likeNum ? authorInfo.likeNum : '0'}}</text>
				<text class="desc">{{$L('获赞')}}</text>
			</view>
			<view @click="goAttention(1,authorInfo.memberNickname ? authorInfo.memberNickname : authorInfo.memberName)">
				<text class="num">{{authorInfo&&authorInfo.followNum ? authorInfo.followNum : '0'}}</text>
				<text class="desc">{{$L('关注')}}</text>
			</view>
			<view @click="goAttention(2,authorInfo.memberNickname ? authorInfo.memberNickname : authorInfo.memberName)">
				<text class="num">{{authorInfo&&authorInfo.fansNum ? authorInfo.fansNum : '0'}}</text>
				<text class="desc">{{$L('粉丝')}}</text>
			</view>
		</view>

		<view class="tab"
			:style="'justify-content:' + (((memberInfo.is_own != 1&&!(setting.live_switch == 1 && authorInfo.role_type == 2))||settingData.video_switch !=1)?'space-around':'space-between')">
			<block v-if="true">
				<text :class="curTab=='video'?'sel':''" @tap="changeTab('video')">{{$L('动态')}}({{
					authorInfo&&authorInfo.videoNum ? (authorInfo.videoNum * 1 > 99 ? '99+' : authorInfo.videoNum)
					: '0'
					}})</text>
			</block>
			<block v-if="setting.live_switch == 1 && authorInfo.roleType == 2">
				<text :class="curTab=='live'?'sel':''" @tap="changeTab('live')" data-index="live">{{$L('直播')}}({{
					authorInfo&&authorInfo.liveNum ? (authorInfo.liveNum * 1 > 99 ? '99+' : authorInfo.liveNum) :
					'0'
					}})</text>
			</block>
			<text :class="curTab=='goods'?'sel':''" @tap="changeTab('goods')" data-index="goods">{{$L('商品')}}({{authorInfo&&authorInfo.goodsNum ? (authorInfo.goodsNum * 1 > 99 ? '99+' : authorInfo.goodsNum) : 0}})</text>
			<block v-if="authorInfo.isSelf">
				<text :class="curTab=='favorite'?'sel':''" @tap="changeTab('favorite')"
					data-index="favorite">{{$L('喜欢')}}({{ authorInfo&&authorInfo.likeVideoNum ?
					(authorInfo.likeVideoNum
					* 1 > 99 ? '99+' : authorInfo.likeVideoNum) : '0' }})</text>
			</block>
		</view>
		<view class="live_user_tab_content_main">
			<!-- 动态模块 -->
			<svideoUserVideo v-if="curTab=='video'" :memberInfo="memberInfo"
				:author_id="author_id" ref='video' :settingData="settingData" :authorInfo="authorInfo"
				@liveEvent="liveEvent" @getAuthorInfo="getAuthorInfo"></svideoUserVideo>

			<!-- 直播模块 -->
			<svideoUserLive v-if="curTab=='live'&&setting.live_switch == 1" :memberInfo="memberInfo"
				:author_id="author_id" :settingData="settingData" ref="live" :authorInfo="authorInfo"
				@liveEvent="liveEvent"></svideoUserLive>

			<!-- 商品模块 -->
			<svideoUserGoods v-if="curTab=='goods'" :memberInfo="memberInfo" :author_id="author_id"
				:settingData="settingData" ref="goods" :authorInfo="authorInfo"></svideoUserGoods>

			<!-- 喜欢模块 -->
			<svideoUserFavorite v-if="curTab=='favorite'" :memberInfo="memberInfo" :settingData="settingData"
				:authorInfo="authorInfo" ref="favorite"></svideoUserFavorite>
		</view>
		<!-- 发布按钮，目前只有发布直播 -->
		<block v-if="authorInfo.isSelf">
			<view class="release">
				<image :src="imgUrl+'svideo/release.png'" data-flag="true" @tap="release"></image>
				<view class="release_bot">
				</view>
			</view>
		</block>
		<!-- 发布按钮弹层 start -->
		<view class="release_mask" v-if="showReleaseType">
			<view class="content">
				<view class="detail">
					<view
						v-if="setting.video_switch == 1 && (authorInfo.permissionState == 0 || authorInfo.permissionState == 2)"
						@tap="releaseLive('video')" class="item">
						<image :src="imgUrl+'svideo/release_video_icon.png'"></image>
						<text>{{$L('短视频')}}</text>
					</view>
					<view
						v-if="(authorInfo.permissionState == 0 || authorInfo.permissionState == 2)"
						@tap="releaseLive('graphic')" class="item">
						<image :src="imgUrl+'svideo/createhb.png'"></image>
						<text>{{('图文')}}</text>
					</view>
					<!-- #ifdef MP-WEIXIN -->
					<view @tap="releaseLive('live')" class="item"
						v-if="authorInfo.roleType == 2 && authorInfo.liveState == 1 && setting.live_switch == 1">
						<image :src="imgUrl+'svideo/release_live_icon.png'"></image>
						<text>{{$L('直播')}}</text>
					</view>
					<!-- #endif -->

				</view>
				<image class="colse" :data-flag="false" @tap="showReleaseTypeFun"
					:src="imgUrl+'svideo/release_close.png'"></image>
			</view>
		</view>
		<!-- 发布按钮弹层 end -->
	</view>
</template>

<script>
	// import request from "@/utils/request";
	const bus = getApp().globalData.bus;
	import svideoUserGoods from "../component/svideoUserGoods/svideoUserGoods";
	import svideoUserFavorite from "../component/svideoUserFavorite/svideoUserFavorite";
	import svideoUserLive from "../component/svideoUserLive/svideoUserLive";
	import svideoUserVideo from "../component/svideoUserVideo/svideoUserVideo";
	import {
		mapState,
		mapMutations
	} from 'vuex';

	export default {
		data() {
			return {
				author_id: '',
				//作者id
				settingData: {},
				//平台设置信息
				authorInfo: {},
				//作者信息
				memberInfo: {},
				//用户相关信息
				imgUrl: getApp().globalData.imgUrl,
				//图片地址
				curTab: 'video',
				//当前tab
				showReleaseType: false //是否展示发布类型
					,
				role_type: "",
				publish_live_can: "",
				//店铺信息
				store_info: '',
				setting: {}, //平台设置信息
				bgStyle: 'background-size:cover;background-position:center center;background-repeat: no-repeat;',
				routeCurTab: '',
				contentTop: 0,
				showState: false
			};
		},

		components: {
			svideoUserGoods,
			svideoUserFavorite,
			svideoUserLive,
			svideoUserVideo
		},
		props: {},
		computed: {
			...mapState(['hasLogin'])
		},
		mounted() {
			this.initData();

		},
		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			if (this.$Route.query.author_id) {
				this.author_id = this.$Route.query.author_id.toString();
			}
			if (this.$Route.query.curTab) {
				this.routeCurTab = this.$Route.query.curTab
			}
			this.getSetting();
		},
		onShow: function() {
			if(this.curTab == 'favorite'){
				//从视频播放页返回后刷新列表
				this.$refs.favorite.getFavoriteList();
			}

			if (this.showState) {
				this.showState = false
				if (this.curTab == 'video' && this.$refs.video) {
					this.$refs[this.curTab].pn = 1
					this.$refs.video.getVideoList();
				} else if (this.curTab == 'goods' && this.$refs.goods) {
					this.$refs[this.curTab].pn = 1
					this.$refs.goods.getGoods();
				} else if (this.curTab == 'favorite' && this.$refs.favorite) {
					this.$refs[this.curTab].pn = 1
					this.$refs.favorite.getFavoriteList();
				} else if (this.curTab == 'live' && this.$refs.live) {
					this.$refs[this.curTab].pn = 1
					this.$refs.live.getLiveList();
				}
			}

			this.initData();
		},


		onReady() {
			let query = uni.createSelectorQuery().in(this);
			query.select('.author_info').boundingClientRect((res) => {
				if (res) {
					this.contentTop = res.height + 42
				}
				console.log(res, 'ssss')
			}).exec()
		},

		onHide() {
			this.showReleaseType = false;
		},

		methods: {
			//初始化数据
			initData() {
				this.getAuthorInfo();
			},
			//获取作者信息
			getAuthorInfo() {
				let {
					author_id
				} = this;
				let param = {}
				param.data = {};
				if (author_id != '') {
					param.data.authorId = author_id
				}
				param.url = 'v3/video/front/video/author/personPage'
				param.method = 'GET'
				this.$request(param).then(res => {
					if (res.state == 200) {
						this.authorInfo = res.data;
						if (!this.authorInfo.isSelf) {
							uni.setNavigationBarTitle({
								// title:'ta的视频'
								title: this.authorInfo.memberNickname
							})
						}
					}
				})
			},

			// 获取设置信息
			getSetting() {
				let param = {};
				param.url = 'v3/video/front/video/setting/getSettingList';
				param.method = 'GET';
				param.data = {};
				param.data.str = 'video_switch,live_switch';

				this.$request(param).then(res => {
					if (res.state == 200) {
						let result = res.data;
						result.map(settingItem => {
							if (settingItem.name == 'video_switch') { //绑定商品数
								this.setting.video_switch = settingItem.value;
							}
							if (settingItem.name == 'live_switch') { //绑定商品数
								this.setting.live_switch = settingItem.value;
							}
							this.setting = JSON.parse(JSON.stringify(this.setting))
						})
						// if(this.routeCurTab){
						// 	this.curTab = this.routeCurTab
						// }
						this.curTab = 'video'
					}
				})
			},
			// 返回上级页面
			goBack() {
				this.$Route.back(1)
			},

			//关注、取消关注事件
			collect() {
				if (this.hasLogin) {
					let param = {}
					param.data = {};
					param.method = 'POST';
					param.data.authorId = this.author_id;
					if (this.authorInfo.isFollow) {
						//取消关注
						param.url = 'v3/video/front/video/cancelFollow'
					} else {
						//关注作者
						param.url = 'v3/video/front/video/followAuthor'
					}
					this.$request(param).then(res => {
						if (res.state == 200) {
							uni.showToast({
								title: res.msg,
								icon: 'none',
								duration: 500
							})
							this.getAuthorInfo();
						}
					})
				} else {
					getApp().globalData.goLogin();
				}

			},

			//查看粉丝
			goAttention(index, title) {
				if (this.authorInfo.isSelf) {
					this.$Router.push({
						path: '/extra/svideo/liveAttention',
						query: {
							type: index
						}
					})
				}
			},

			//编辑资料
			editMemInfo() {
				if (this.authorInfo.isSelf) {
					this.$Router.push('/extra/svideo/liveAuthorInfo')
				}
			},

			//tab切换
			changeTab(targetTab) {
				this.curTab = targetTab
				// console.log(this.$Route,'ssss')
				this.$Route.query.curTab = targetTab
				// this.$Router.push({
				// 	path:this.$Route.path,
				// 	query:{
				// 		...this.$Route.query,
				// 		curTab:targetTab
				// 	}
				// })
			},

			//进入评论列表
			goComments() {
				this.$Router.push('/extra/svideo/svideoComments')
			},

			//点击底部加号事件
			release(e) {
				if (this.memberInfo.is_own != 1) { //短视频

					if (this.authorInfo.permissionState == 0) {
						this.applicationTip('是否立即申请发布权限');
					} else if (this.authorInfo.permissionState == 1) {
						if (!(this.authorInfo.remark && this.authorInfo.forbidReason)) {
							this.applicationShowTip('审核中，请耐心等待');
						}
					} else if (this.authorInfo.permissionState == 3) {
						this.applicationTip(this.authorInfo.remark);
					} else if (this.authorInfo.permissionState == 4) {
						if (!(this.authorInfo.remark && this.authorInfo.forbidReason)) {
							this.applicationShowTip(this.authorInfo.remark);
						}
					} else {
						this.showReleaseTypeFun(e);
					}
				}
				// #ifdef MP-WEIXIN
				if (this.setting.live_switch == 1 && this.authorInfo.roleType == 2) { //直播
					if (this.authorInfo.liveState == 0) {
						this.applicationShowTip(this.authorInfo.forbidReason)
					} else {
						this.showReleaseTypeFun(e);
					}
				}
				// #endif

			},

			// 发布直播
			releaseLive(type) {
				let {
					author_id,
					authorInfo,
					memberInfo
				} = this;
				this.showState = true
				if (type == 'live') {
					this.$Router.push({
						path: '/extra/svideo/liveReleaseLive',
						query: {
							roleType: this.authorInfo.roleType,
							storeId: this.authorInfo.storeId
						}
					})
				} else if (type == 'video') {
					this.$Router.push({
						path: '/extra/svideo/svideoRelease',
					})
				} else if (type == 'graphic') {
					this.$Router.push({
						path: '/extra/graphic/graphicRelease',
					})
				}
			},

			applicationShowTip(tip) {
				let tips = tip;
				if (this.authorInfo.remark && this.authorInfo.forbidReason) {
					tips = '禁止发布：' + this.authorInfo.remark + ',' + this.authorInfo.forbidReason
				}
				uni.showModal({
					title: '提示',
					content: tips,
					showCancel: false
				})
			},
			applicationTip(tips) {
				this.applicationFb(tips);
			},

			applicationFb(tip) {
				uni.showModal({
					title: '提示',
					content: tip,
					confirmText: this.authorInfo.permissionState == 3 ? '再次申请' : '确定',
					success: res => {
						if (res.confirm) {
							let param = {}
							param.data = {};
							param.method = 'POST';
							param.url = 'v3/video/front/video/author/apply'
							this.$request(param).then(res => {
								if (res.state == 200) {
									uni.showToast({
										title: res.msg,
										icon: 'none'
									})
									this.getAuthorInfo();
								}
							})
						}
					}
				});
			},

			liveEvent(e) {
				this.getAuthorInfo();
			},

			showReleaseTypeFun(e) {
				this.showReleaseType = e.currentTarget.dataset.flag;
			}

		}
	};
</script>
<style lang="scss">
	page {
		background: #f8f8f8;
		width: 750rpx;
		margin: 0 auto;
	}

	.author_info {
		width: 750rpx;
		height: 380rpx;
		background-size: cover;
		background-position: center;
		background-repeat: no-repeat;
		display: flex;
		flex-direction: column;
		align-items: flex-start;
		padding: 20rpx 20rpx 0rpx 0rpx;
		box-sizing: border-box;
		overflow: hidden;
		position: relative;
		top: 0;

		.go_back {
			width: 45rpx;
			height: 47rpx;
		}

		.info {
			display: flex;
			flex-direction: row;
			justify-content: flex-start;
			align-items: center;
			width: 100%;
			height: 130rpx;
			margin-top: 5rpx;
			margin-left: 20rpx;

			.right_info {
				display: flex;
				flex-direction: column;
				justify-content: center;
				align-items: flex-start
			}

			.right_info .check_tip {
				color: #fff;
				font-size: 24rpx;
				margin-left: 20rpx;
				margin-top: 10rpx
			}

			.right_info .member_info {
				display: flex;
				flex-direction: row;
				justify-content: flex-start;
			}

			.author_avator {
				width: 130rpx;
				height: 130rpx;
				border-radius: 65rpx;
				display: flex;
				flex-direction: row;
				justify-content: center;
				align-items: center;

			}

			.author_name {
				max-width: 310rpx;
				color: #fff;
				font-size: 36rpx;
				white-space: nowrap;
				overflow: hidden;
				text-overflow: ellipsis;
				margin-left: 20rpx;
			}

			.edit_mem_info {
				width: 155rpx;
				height: 40rpx;
				background: #fc1c1c;
				border-radius: 6rpx;
				display: flex;
				flex-direction: row;
				justify-content: center;
				align-items: center;
				margin-left: 20rpx;

				text {
					color: #f9e9e9;
					font-size: 24rpx;
					margin-right: 5rpx;
				}

				image {
					width: 40rpx;
					height: 40rpx;
					margin-left: -4rpx;
				}
			}

			.fav_info {
				display: flex;
				flex-direction: row;
				justify-content: center;
				align-items: center;
				border-radius: 8rpx;
				background: #fc1c1c;
				padding: 8rpx 10rpx;
				margin-left: 20rpx;

				image {
					width: 30rpx;
					height: 30rpx;
				}

				text {
					color: #f9e9e9;
					font-size: 24rpx;
					margin-left: 5rpx;
					margin-right: 5rpx;
				}
			}

			.go_vendor {
				background: linear-gradient(to left, #fc1c1c, #ffa300);
				width: 73rpx;
				height: 40rpx;
				display: flex;
				flex-direction: row;
				justify-content: center;
				align-items: center;
				border-radius: 20rpx;
				margin-left: 20rpx;

				text {
					color: #fff;
					font-size: 22rpx;
				}
			}
		}

		.author_desc {
			color: #fff;
			width: 670rpx;
			margin-top: 25rpx;
			font-size: 26rpx;
			margin-left: 20rpx;
			line-height: 32rpx;
			text-overflow: ellipsis;
			overflow: hidden;
			word-break: break-all;
		}

		.stat_num {
			color: #fff;
			margin-top: 10rpx;
			display: flex;
			flex-direction: row;
			justify-content: flex-start;
			align-items: center;
			margin-left: 20rpx;

			view {
				margin-right: 30rpx;

				.num {
					font-size: 30rpx;
					font-weight: bold;
					margin-right: 10rpx;

					.desc {
						font-size: 22rpx;
					}
				}
			}
		}

		.tab {
			display: flex;
			flex-direction: row;
			justify-content: space-between;
			align-items: center;
			padding: 10rpx 20rpx;
			width: 750rpx;
			margin-top: 10rpx;
			/* #ifdef MP */
			width: 710rpx;
			/* #endif */
			position: absolute;
			bottom: 16rpx;
			text {
				font-size: 32rpx;
				color: #fff;
				padding-bottom: 8rpx;

				&.sel {
					font-weight: bold;
					border-bottom: 2px solid #fff;
				}
			}
		}
	}


	.live_user_tab_content_main {
		width: 750rpx;
		position: fixed;
		top: 467rpx;
		left: 0;
		bottom: 0;
		right: 0;
		margin: 0 auto;
		/* #ifdef APP-PLUS */
		top: 407rpx;
		/* #endif */
		/* #ifdef MP-WEIXIN */
		top: 407rpx;
		/* #endif */

	}

	/* #ifdef MP*/
	.live_user_tab_content {
		width: 750rpx;
		position: fixed;
		top: 390rpx;
		left: 0;
		bottom: 0;
	}

	/* #endif */
	/* #ifdef H5  */
	.live_user_tab_content {
		width: 750rpx;
		position: fixed;
		top: 448rpx;
		/* left: 0; */
		bottom: 0;
	}

	/* #endif */

	.author_info .info .msg_wrap {
		width: 34rpx;
		height: 34rpx;
		position: relative;
		margin-left: 20rpx;
	}

	.author_info .info .msg_wrap image {
		width: 34rpx;
		height: 34rpx;
	}

	.author_info .info .msg_wrap text {
		position: absolute;
		z-index: 2;
		top: -2rpx;
		left: 11px;
		color: #fff;
		background: #fc1c1c;
		width: 15rpx;
		height: 15rpx;
		border-radius: 50%;
	}

	.release {
		position: fixed;
		left: 0;
		right: 0;
		bottom: 0;
		z-index: 2;
		width: 750rpx;
		height: 100rpx;
		background: transparent;
		display: flex;
		flex-direction: column;
		justify-content: flex-start;
		align-items: center;
		margin: 0 auto;
	}

	.release image {
		position: absolute;
		bottom: 40rpx;
		z-index: 3;
		width: 120rpx;
		height: 120rpx;
	}

	.release .release_bot {
		position: absolute;
		left: 0;
		right: 0;
		bottom: 0;
		height: 100rpx;
		background: #fff;
	}

	.release_mask {
		width: 750rpx;
		position: fixed;
		z-index: 99;
		top: 0;
		left: 0;
		right: 0;
		bottom: 0;
		background: rgba(0, 0, 0, 0.6);
		margin: 0 auto;
	}

	.release_mask .content {
		position: absolute;
		bottom: 35rpx;
		left: 0;
		right: 0;
		display: flex;
		flex-direction: column;
		justify-content: flex-start;
		align-items: center;
		width: 100%;
	}

	.release_mask .content .colse {
		width: 47rpx;
		height: 47rpx;
		margin-top: 38rpx
	}

	.release_mask .content .detail {
		display: flex;
		justify-content: space-around;
		align-items: center;
		width: 100%;
	}

	.release_mask .content .detail .item {
		display: flex;
		flex-direction: column;
		justify-content: flex-start;
		align-items: center;
	}

	.release_mask .content .detail .item image {
		width: 110rpx;
		height: 110rpx;
	}

	.release_mask .content .detail .item text {
		color: #fff;
		font-size: 34rpx;
		margin-top: 28rpx
	}
</style>
