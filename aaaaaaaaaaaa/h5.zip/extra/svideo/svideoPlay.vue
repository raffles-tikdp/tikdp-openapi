<template>
	<view>
		<view style="width:750rpx;height:100vh;overflow-y: hidden;">
			<videoPlay @showVideoInfo='showVideoInfo' :id="'sldVideo_'" :video_id="video_id" :activeIndex="activeIndex"
				:author_id="author_id" :prevIndex="prevIndex" :nextIndex="nextIndex" :showHide="ShowHide" :preUpdateIndex="preUpdateIndex"></videoPlay>
		</view>

		<!-- 回放视频暂停/播放的弹层展示 -->
		<view class="video_control" v-if="playFlag&&showPauseBtn||!playFlag" @tap="videoPlayControl">
			<image :src="showBtnIcn" :video_id="video_id"></image>
		</view>
	</view>
</template>

<script>
	import {
		checkPageHasMore
	} from "@/utils/live";
	import request from "@/utils/request";
	import videoPlay from "../component/videoPlay/videoPlay";

	export default {
		data() {
			return {
				label_id: 0,
				//label_id: 该标签下的所有视频
				theme_id: 0,
				//theme_id: 该主题下的所有视频
				author_id: 0,
				//author_id: 该作者下的所有视频
				type: '',
				//type: 我喜欢的视频
				video_id: 0,
				//当前短视频id
				playFlag: true,
				//视频是否播放
				showPauseBtn: false,
				//是否显示暂停按钮
				showBtnIcn: '',
				//视频播放控制层按钮图片
				activeIndex: 0,
				//当前播放的视频id
				videoUrl: [ // 视频列表
					{
						now: ''
					}
				],
				videoId: [],
				// 所有视频id
				prevIndex: '',
				// 上个视频的id
				nextIndex: '', // 下个视频的id
				videoInfo: '',
				ShowHide: 'hide',
				preUpdateIndex: '', //是否需要更新上一个页面的数据 -- 取操作的列表下标
			};
		},

		components: {
			videoPlay
		},
		props: {},
		//继续播放按钮图片

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad(options) {
			if(options.index) {
				this.preUpdateIndex = options.index;
				uni.$emit('updateView', options.index); //更新浏览次数
			}
			if (options && options.scene) {
				let url = decodeURIComponent(options.scene);
				this.video_id = url.split('=')[1];
			}
			this.activeIndex = Number(this.$Route.query.video_id)
			this.video_id = Number(this.$Route.query.video_id)
			this.label_id = Number(this.$Route.query.label_id)
			this.author_id = Number(this.$Route.query.author_id)
			uni.createVideoContext('sldVideo_child').pause();
		},
		onShow() {
			this.ShowHide = 'show'
		},
		onHide() {
			this.ShowHide = 'hide'
		},
		onUnload(){
			uni.getSubNVueById('vidoePlayAppCon').hide();
			// 移除监听事件    
			uni.$off('goBack');
			uni.$off('forbidenHide'); 
			uni.$off('goGoodsDetail'); 
			uni.$off('goLiveUserCenter'); 
		},
		onShareAppMessage: function() {
			return {
				title: this.videoInfo.videoName,
				path: '/extra/svideo/svideoPlay?video_id=' + this.video_id,
				imageUrl: this.videoInfo.videoThemeImage
			};
		},
		onShareTimeline: function() {
			return {
				title: this.videoInfo.videoName,
				query: 'video_id=' + this.video_id,
				imageUrl: this.videoInfo.videoThemeImage
			};
		},
		methods: {
			showVideoInfo(videoInfo) {
				this.videoInfo = videoInfo
			},
			
			//视频暂停/继续播放事件
			videoPlayControl() {
				let {
					playFlag,
					showPauseBtn
				} = this;
				this.videoContext = uni.createVideoContext('sldVideo');

				if (playFlag) {
					if (!showPauseBtn) {
						this.setData({
							showPauseBtn: true,
							showBtnIcn: this.pauseBtnIcon
						}); //3s后自动消失

						setTimeout(() => {
							this.setData({
								showPauseBtn: false
							});
						}, 3000);
					} else {
						this.videoContext.pause(); //暂停播放

						this.setData({
							showPauseBtn: false,
							playFlag: false,
							showBtnIcn: this.playBtnIcon
						});
					}
				} else {
					this.videoContext.play(); //开始播放

					this.setData({
						playFlag: true,
						showPauseBtn: false
					});
				}
			}

		}
	};
</script>
<style>
	page {
		width: 750rpx;
		margin: 0 auto;
		position: relative;
	}
</style>
