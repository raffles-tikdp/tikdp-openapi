<template>
	<view>
		<view class="sele_goods">
			<view class="header"
				:style="'background:url('+imgUrl+'svideo/sel_goods_bg.png'+') no-repeat center;background-size:cover;'">
				<!-- #ifndef MP -->
				<view class="header_nav">
					<view class="go_back_wrap" @tap="goBack">
						<image class="go_back" :src="imgUrl+'svideo/white_arrow_l.png'"></image>
					</view>
					<text class="title">{{$L('商品选择')}}</text>
				</view>
				<!-- #endif -->
				<view class="search">
					<view class="left">
						<image :src="imgUrl+'svideo/search_icon.png'" mode="aspectFit"></image>
						<input confirm-type="search" class="sea_input" type="text" :value="goods_name"
						:placeholder="$L('请输入关键词')" placeholder-style="font-size:24rpx;color:#fff;"
						@input="inConfirm"></input>
					</view>
					<text v-if="!goods_name" class="search_text">{{$L('搜索')}}</text>
					<text v-if="goods_name" class="search_text" @tap="cancleSearch">{{$L('取消')}}</text>
				</view>
			</view>
			<scroll-view class="main mainh" scroll-y @scrolltolower="getMoreData">
				<view class="main_wrap" v-if="list.length">
					<view v-for="(item, index) in list" :key="index" class="sel_goods_item" @tap="operateGoods(item)">
						<view class="goods_image"
							:style="'background-image:url('+item.goodsImage+')'"></view>
						<view class="goods_name">
							<jyfParser :html="item.goodsName"></jyfParser>
						</view>
						<view class="goods_detail">
							<view class="goods_price">
								<text class="unit">¥</text>
								<text class="price_num">{{item.goodsPrice?item.goodsPrice:item.productPrice}}</text>
							</view>
							<image class="goods_sele" v-if="item.isSel" :src="imgUrl+ 'svideo/goods_sel.png'"></image>
							<image class="goods_sele" :src="imgUrl+ 'svideo/goods_unsel.png'" v-else></image>
							<!-- <image class="goods_sele" :src="imgUrl+(item.isSel!=undefined&&item.isSel?'shortVideo/goods_sel.png':'shortVideo/goods_unsel.png')"></image> -->
						</view>
					</view>
				</view>
				<!-- 数据加载完毕 -->
				<dataLoaded :showFlag="!hasmore&&list.length>0" />

				<!-- 数据加载中 -->
				<dataLoading :showFlag="!firstLoading&&hasmore&&loading" />

				<!-- 页面loading -->
				<pageLoading :firstLoading="firstLoading" :loadingIcon="imgUrl + 'svideo/page_loading_icon.gif'" />

				<!-- 页面空数据 -->
				<emptyData :showFlag="!firstLoading&&!list.length"
					:emptyIcon="imgUrl+'svideo/live_list_empty_icon.png'" />

				<view class="empty_h" v-if="selGoods.length"></view>
			</scroll-view>

			<view class="footer" v-if="selGoods.length > 0">
				<view class="total_tip">
					<text class="total_tip_text">{{$L('已选')}}</text>
					<text class="total_tip_text total_num">{{selGoods.length}}</text>
					<text class="total_tip_text">{{$L('件商品')}}</text>
					<text v-if="bindGoodsNum > 0 && selGoods.length >= 10"
						class="total_tip_text">{{$L('(最多可选')}}{{bindGoodsNum}}{{$L('件商品)')}}</text>
				</view>
				<text class="confirm_btn" @tap="confirmSelGoods">{{$L('确认')}}</text>
			</view>
		</view>
	</view>
</template>

<script>
	import request from "@/utils/request";
	import {
		checkPageHasMore,
		initNum
	} from "@/utils/live";
	import pageLoading from "../templates/live/pageLoading.vue";
	import emptyData from "../templates/live/emptyData.vue";
	import dataLoading from "../templates/live/dataLoading.vue";
	import dataLoaded from "../templates/live/dataLoaded.vue";
	import jyfParser from '@/components/jyf-parser/jyf-parser.vue'
	const bus = getApp().globalData.bus;

	export default {
		components: {
			pageLoading,
			emptyData,
			dataLoading,
			dataLoaded,
			jyfParser
		},
		data() {
			return {
				imgUrl: getApp().globalData.imgUrl,
				//图片地址
				bgStyle: 'background-size:contain;background-position:center center;background-repeat: no-repeat;',
				//背景图片样式
				hasmore: true,
				//是否还有数据，用于页面展示
				loading: false,
				firstLoading: true,
				//是否初次加载，是的话展示页面居中的loading效果，
				list: [],
				goods_name: '',
				// 搜索关键词
				goodsList: [],
				// 已选择的商品
				goods_ids: [],
				// 已选择的商品id
				maxNum: '',
				pn: 1,
				roleType: 1, //默认会员1 商家2
				storeId: '',	// roleType==2 商家id
				pageSize: 10,
				selGoods: [], //选中的商品信息
				bindGoodsNum: 10, //最多可选择商品数量
			};
		},

		/**
		 * 生命周期函数--监听页面加载
		 */
		onLoad: function(options) {
			if (this.$Route.query.roleType && this.$Route.query.roleType != undefined && this.$Route.query.roleType != 'undefined') {
				this.roleType = this.$Route.query.roleType;
				this.storeId = this.$Route.query.storeId?this.$Route.query.storeId:'';
			}
			
			if(uni.getStorageSync('selGoods')){
				this.selGoods = uni.getStorageSync('selGoods')
			}

			this.bindGoodsNum = this.$Route.query.bindGoodsNum;
			this.getList();
		},
		methods: {
			//获取商品列表
			getList() {
				this.loading = true;
				let {
					list,
					hasmore,
					goods_name,
					firstLoading,
					goods_ids,
					goodsList,
					roleType,
					storeId
				} = this;
				let param = {};
				if (roleType == 1) {
					//会员账号
					param.url = "v3/member/front/productLookLog/goodsList";
					param.data = {
						pageSize: this.pageSize,
						current: this.pn,
						goodsName: goods_name,
					}
				} else if (roleType == 2) {
					//商家账号
					param.url = 'v3/goods/front/goods/goodsList';
					param.method = 'GET';
					param.data = {
						pageSize: this.pageSize,
						current: this.pn,
						sort: 0,
						storeId: storeId
					}
					if (goods_name) {
						param.data.keyword = goods_name
					}
				}
				this.$request(param).then(res => {
					if (res.state == 200) {
						let tmp_list = res.data.list;
						if (this.pn == 1) {
							this.list = tmp_list;
						} else {
							this.list = list.concat(tmp_list);
						}
						if (this.selGoods && this.selGoods.length > 0) {
							this.list.map(listItem => {
								let listPid = listItem.defaultProductId?listItem.defaultProductId:listItem.productId
								this.selGoods.map(selGoodsItem => {
									let selPid = selGoodsItem.defaultProductId?selGoodsItem.defaultProductId:selGoodsItem.productId
									if (listPid == selPid) {
										listItem.isSel = true;
									}
								})
							})
						}
						if (checkPageHasMore(res.data.pagination)) {
							this.pn++;
						} else {
							this.hasmore = false;
							this.hasmore = false;
						}
					}
					if (this.firstLoading) {
						this.firstLoading = false;
					}
				})
			},

			getMoreData: function() {
				if (this.hasmore) {
					this.getList();
				}
			},

			//点击弹起的键盘按钮时触发
			inConfirm: function(e) {
				this.goods_name = e ? e.detail.value : this.goods_name;
				this.pn = 1;
				this.hasmore = true;
				this.firstLoading = true;
				this.getList();
			},

			//取消搜索
			cancleSearch() {
				uni.hideKeyboard()
				this.goods_name = '';
				this.inConfirm();
			},

			// 选择商品
			operateGoods(item) {
				let that = this;
				if (that.bindGoodsNum > 0 && that.selGoods.length >= that.bindGoodsNum && !item.isSel) {
					uni.showToast({
						title: '最多能选择' + that.bindGoodsNum + '件商品',
						icon: 'none'
					})
					return;
				} else {
					this.list && this.list.map((listItem, listIndex) => {
						let tartPid = item.defaultProductId ? item.defaultProductId : item.productId
						let listPid = listItem.defaultProductId ? listItem.defaultProductId : listItem.productId
						if (tartPid == listPid) {
							listItem.isSel = !listItem.isSel;
							if (listItem.isSel) {
								this.selGoods.push(listItem);
							} else {
								this.selGoods = this.selGoods.filter(subItem => {
									let subPid = subItem.defaultProductId ? subItem.defaultProductId :
										subItem.productId
									return subPid != listPid
								});
							}
						}
					})
					this.$forceUpdate();
				}
			},

			//确认选择商品
			confirmSelGoods() {
				let that = this;
				let tmp = that.selGoods
				let pages = getCurrentPages();
				let prevPage = pages[pages.length - 2]; //上一个页面
				tmp.map(item => {
					item.goodsName = item.goodsName.replace(/<\/?font>|<font color=\"red\">/g, '')
				})
				if (prevPage) {
					prevPage.$vm.selGoods = tmp;
				}
				uni.setStorageSync('selGoods', tmp)
				this.$Router.back(1)
			},

			// 返回上级页面
			goBack() {
				this.$Router.back(1)
			}

		}
	};
</script>
<style>
	page {
		background: #f8f8f8;
		width: 750rpx;
		margin: 0 auto;
	}

	.sele_goods {
		width: 750rpx;
		height: 100vh;
		position: relative;
	}

	.sele_goods .header {
		position: absolute;
		z-index: 2;
		width: 750rpx;
		/* #ifdef MP */
		height:150rpx;
		/* #endif */
		
		/* #ifdef APP-PLUS || h5*/
		height: calc(var(--status-bar-height) + 200rpx);
		padding-top: var(--status-bar-height);
		/* #endif */
	}

	.header_nav {
		padding: 0 20rpx;
		left: 20rpx;
		right: 0;
		z-index: 2;
		display: flex;
		flex-direction: row;
		align-items: center;
		justify-content: center;
		height: 80rpx;
	}

	.header_nav .go_back_wrap {
		position: absolute;
		left: 0;
		width: 80rpx;
		height: 47rpx;
	}

	.header_nav .go_back {
		width: 45rpx;
		height: 47rpx;
	}

	.header_nav .title {
		color: #fff;
		font-size: 34rpx;
		font-weight: bold;
	}

	.search {
		
		left: 0;
		width: 710rpx;
		height: 60rpx;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		margin: 20rpx;
		background: transpanrent;
	}

	.search .left {
		width: 639rpx;
		height: 60rpx;
		border-radius: 30rpx;
		background: rgba(255, 255, 255, 0.2);
		display: flex;
		flex-direction: row;
		justify-content: flex-start;
		align-items: center;
	}

	.search .left image {
		width: 50rpx;
		height: 50rpx;
		margin-top: 2rpx;
		margin-left: 10rpx;
	}

	.search .left .sea_input {
		color: #fff;
		font-size: 24rpx;
		margin-top: -2rpx;
		width: 540rpx;
		background: transparent;
	}

	.search .search_text {
		font-size: 26rpx;
		color: #fff;
	}

	.main {
		position: fixed;
		z-index: 2;
		/* #ifdef H5 */
		top: 200rpx;
		/* #endif */
		/* #ifdef MP*/
		top: 150rpx;
		/* #endif */
		/* #ifdef APP-PLUS */
		top: 280rpx;
		/* #endif */
		padding: 0 20rpx;
	}

	.mainh {
		/* #ifdef H5 */
		height: calc(100vh - 260rpx);
		/* #endif */
		/* #ifdef MP || APP-PLUS */
		height: calc(100vh - 152rpx);
		/* #endif */
	}

	.main .main_wrap {
		width: 710rpx;
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		flex-wrap: wrap;
	}

	.main .sel_goods_item {
		width: 345rpx;
		height: 474rpx;
		background: #fff;
		border-radius: 14rpx;
		display: flex;
		flex-direction: column;
		justify-content: flex-start;
		align-items: flex-start;
		margin-top: 20rpx;
		padding-bottom: 20rpx;
	}

	.main .sel_goods_item .goods_image {
		width: 345rpx;
		height: 345rpx;
		border-radius: 14rpx 14rpx 0 0;
		background-position: center center;
		background-repeat: no-repeat;
		background-size: cover;
	}

	.main .sel_goods_item .goods_name {
		color: #2d2d2d;
		font-size: 26rpx;
		line-height: 36rpx;
		padding: 0 20rpx;
		width: 305rpx;
		height: 72rpx;
		margin-top: 10rpx;
		overflow: hidden;
		text-overflow: ellipsis;
		display: -webkit-box;
		-webkit-line-clamp: 2;
		-webkit-box-orient: vertical;
		word-break: break-word;
	}

	.main .sel_goods_item .goods_detail {
		display: flex;
		flex-direction: row;
		justify-content: space-between;
		align-items: center;
		padding: 0 10rpx 0 20rpx;
		width: 335rpx;
	}

	.main .sel_goods_item .goods_detail .goods_price {
		color: #e1251b;
		display: flex;
		flex-direction: row;
		justify-content: flex-start;
		align-items: center;
		letter-spacing: 2rpx;
	}

	.main .sel_goods_item .goods_detail .goods_price .unit {
		font-size: 24rpx;
	}

	.main .sel_goods_item .goods_detail .goods_price .price_num {
		font-weight: bold;
		font-size: 34rpx;
	}

	.main .sel_goods_item .goods_detail .goods_sele {
		width: 50rpx;
		height: 50rpx;
	}

	.sele_goods .footer {
		width: 750rpx;
		height: 205rpx;
		position: absolute;
		/* position: fixed; */
		z-index: 3;
		left: 0;
		right: 0;
		bottom: 0;
		box-shadow: 0px 0px 9px 1px rgba(86, 86, 86, 0.2);
		border-radius: 15rpx 15px 0 0;
		display: flex;
		flex-direction: column;
		justify-content: flex-start;
		align-items: center;
		background: #fff;
	}

	.sele_goods .footer .total_tip {
		width: 690rpx;
		height: 110rpx;
		padding: 0 30rpx;
		display: flex;
		flex-direction: row;
		justify-content: flex-start;
		align-items: center;
	}

	.sele_goods .footer .total_tip .total_tip_text {
		color: #2D2D2D;
		font-size: 28rpx;
	}

	.sele_goods .footer .total_tip .total_tip_text.total_num {
		color: #FC1C1C;
	}

	.sele_goods .footer .confirm_btn {
		letter-spacing: 5rpx;
		width: 580rpx;
		height: 70rpx;
		background: linear-gradient(90deg, rgba(255, 36, 67, 1) 0%, rgba(255, 122, 0, 1) 100%);
		box-shadow: 0px 3rpx 10rpx 0px rgba(255, 13, 0, 0.26);
		border-radius: 35rpx;
		display: flex;
		flex-direction: row;
		justify-content: center;
		align-items: center;
		color: #fff;
	}

	.empty_h {
		height: 185rpx;
		width: 100%;
		background-color: 'transpanrent';
	}
</style>
