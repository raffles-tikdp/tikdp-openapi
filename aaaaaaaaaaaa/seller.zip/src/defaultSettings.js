module.exports = {
	"navTheme": "dark",
	"primaryColor": "#FF711E",
	"layout": "sidemenu",
	"contentWidth": "Fluid",
	"fixedHeader": true,
	"autoHideHeader": false,
	"fixSiderbar": true,
	"collapse": true,
	"menu": {
		disableLocal:true
	}
};
