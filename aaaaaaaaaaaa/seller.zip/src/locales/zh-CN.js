import menu from './zh-CN/menu';
import content from './zh-CN/content';

export default {
  ...menu,
  ...content,
};
