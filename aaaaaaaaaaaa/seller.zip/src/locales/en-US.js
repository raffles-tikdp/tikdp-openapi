import menu from './en-US/menu';
import content from './en-US/content';

export default {
  ...menu,
  ...content,
};
