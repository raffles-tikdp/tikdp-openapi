import menu from './zh-TW/menu';

export default {
  ...menu,
};
